#Clear the memory
#rm(list=ls())
# Input Parameters:

# Start the clock plyr!
plyr_op <- proc.time()

library(doParallel)

start_aqsn_window = "01-JAN-2012"
window_dt = format(seq(as.Date(start_aqsn_window, "%d-%b-%Y"), by = "month", length.out = 12), format = "%Y%m")

cl <- makeCluster(length(window_dt))
registerDoParallel(cl)


#SQL Query
sql_stmt = 
"select
 ptp.CA,
 ptp.FL,
 ptp.NewEngland,
 ptp.MidAtlantic,
 ptp.SouthAtlantic,
 ptp.EastNorthCentral,
 ptp.EastSouthCentral,
 ptp.WestNorthCentral,
 ptp.WestSouthCentral,
 ptp.Mountain,
 ptp.Pacific,
 ptp.fnma_ln,
 ptp.aq_actdt,
 ptp.fico,
 ptp.cd_12,
 ACIS.newacip
 from
 ((select
 case when a.state = 'CA' then 1 else 0 end as CA,
 case when a.state = 'FL' then 1 else 0 end as FL,
 case when a.state in ('ME', 'MA', 'RI', 'CT', 'VT', 'NH') then 1 else 0 end as NewEngland,
 case when a.state in ('NY', 'PA', 'NJ') then 1 else 0 end as MidAtlantic,
 case when a.state in ('DE', 'MD', 'DC', 'VA', 'WV', 'NC', 'SC', 'GA') then 1 else 0 end as SouthAtlantic,
 case when a.state in ('WI', 'MI', 'IL', 'IN', 'OH') then 1 else 0 end as EastNorthCentral, 
 case when a.state in ('KY', 'TN', 'AL', 'MS') then 1 else 0 end as EastSouthCentral,
 case when a.state in ('ND', 'SD', 'NE', 'KS', 'MO', 'IA', 'MN') then 1 else 0 end as WestNorthCentral,
 case when a.state in ('OK', 'AR', 'TX', 'LA') then 1 else 0 end as WestSouthCentral,
 case when a.state in ('MT', 'ID', 'WY', 'CO', 'NM', 'AZ', 'UT', 'NV') then 1 else 0 end as Mountain, 
 case when a.state in ('WA', 'OR', 'AK', 'HI') then 1 else 0 end as Pacific,
 a.fnma_ln,
 a.aq_actdt,
 a.fico,
 b.cd_12
 from puma..NZ_PUMA_TAB_POP a
 left join puma..NZ_totalperformance b
 on a.fnma_ln=b.fnma_ln
 where a.aq_actdt = to_date(ENTERDATE,'YYYYMM')
 and a.z_conventional_acq = 1 and a.seasoned <> 'Y' and a.harp_cde NOT in ('1', '2')) ptp
 left outer join
 (select fnma_ln, newacip
 from puma..NZ_ALLNEWACIS) ACIS using (fnma_ln))
 order by ptp.aq_actdt, ACIS.newacip"

reg_file = tempfile("sql_stmt.txt")
writeChar(sql_stmt, reg_file, nchar(sql_stmt), eos = "")

parallel_data <- foreach(i=window_dt, .inorder=FALSE,
                         .packages=c("RJDBC", "stringr", "data.table", "stargazer", "rms", "texreg")) %dopar% {
                          
                           # Netezza UserId and Password
                           #DBuserid <- 'r3ujprjc'
                           #DBPassword <- '********'
                           
                           
                           .jinit()
                           .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar")
                           
                           drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
                           
                           host <- "psysadm-unz01"
                           port <- "5480"
                           dbName <- "PUMA"
                           
                           connect.string <- paste("jdbc:netezza://", host, ":", port, "/", dbName, sep = "")
                           
                           con <- dbConnect(drv, connect.string, DBuserid, DBPassword)
                           
                           query = readChar(reg_file, nchar(sql_stmt))
                           query = gsub("\n", "", query)
                           query = gsub("ENTERDATE", i, query)
                           
                           nz.rs<-dbSendQuery(con, query)
                           nz.ts<-fetch(nz.rs, n = -1)
                           dbDisconnect(con)
                           as.data.frame(nz.ts)
                           
                           # Create a variable called ACIP_LOGIT
                           
                           nz.ts$ACIP_LOG = log(nz.ts$NEWACIP/(1-nz.ts$NEWACIP))
                           
                           sig.coef = data.frame(variables = (colnames(nz.ts)))
                           sig.coef = subset(sig.coef, variables %in% c("CA", "FL", "NEWENGLAND", "SOUTHATLANTIC", "EASTNORTHCENTRAL", "EASTSOUTHCENTRAL", "WESTNORTHCENTRAL", "WESTSOUTHCENTRAL", "MOUNTAIN", "PACIFIC"))
                           row.names(sig.coef) = sig.coef$variables
                           insig = data.frame()
                           coefs2 = rbind(sig.coef, insig)
                           formul = as.formula(paste("CD_12 ~ offset(ACIP_LOG)", paste(row.names(coefs2), collapse = "+"), sep = "+"))
                           
                          keeplooping = TRUE
                          
                          while(keeplooping) {
                           
                           glm_reg = glm(formula = formul, data = nz.ts, family = binomial(link="logit"), na.action="na.exclude")
                           
                             summar = as.data.frame(summary(glm_reg)$coef)
                             coefs = as.data.frame(summar[-1,])
                             sig.coef = subset(coefs, coefs[,4]<=0.05)
                             insig.coef = subset(coefs, coefs[,4]>0.05)
                             insig.coef = insig.coef[order(-insig.coef[,4]),]
                             insig = 0
                             insig = as.data.frame(insig.coef[-1,])
                             coefs2 = rbind(sig.coef, insig)
                           
                           if (nrow(coefs2)>0) {
                             
                             #formul = reformulate(termlabels = row.names(coefs2), response = 'CD_12')
                             formul = as.formula(paste("CD_12 ~ offset(ACIP_LOG)", paste(row.names(coefs2), collapse = "+"), sep = "+"))
                           }
                           
                           else {
                             formul = as.formula("CD_12 ~ offset(ACIP_LOG)")
                           }
                             if (nrow(sig.coef) == 0){
                               
                               if (nrow(insig) == 0) {
                                 glm_reg = glm(formula = formul, data = nz.ts, family = binomial(link="logit"), na.action="na.exclude")
                                 keeplooping = FALSE
                               }
                             }
              
                              else if (nrow(sig.coef) == 10) {
                                
                                keeplooping = FALSE
                                
                              }

                              
                           
                           else if (nrow(insig.coef) == 10) {
                             
                             keeplooping = FALSE
                           } 
                             
                           
                           else if (nrow(insig.coef) == 0) {
                             keeplooping = FALSE
                           }
                             
                          }

                           # add comp values as column to original table
                           nz.ts$COMP = predict(glm_reg, type = "response")
                             
                           nz.ts$ss_cd_12 = (nz.ts$COMP)*(1-nz.ts$COMP)
                             
                           
                           nz.ts$FICO_Bckts = as.character(cut(nz.ts$FICO, breaks = c(-Inf, 0, 679, 719, 759, Inf), labels = c('Missing FICO', '[0-680)', '[680-720)',
                                                                                                                            '[720-760)', '[760+]')))
                           
                           nz.ts = subset(nz.ts, !is.na(NEWACIP), select = c(CD_12, AQ_ACTDT, NEWACIP, COMP, ss_cd_12, FICO_Bckts))
                           
                           file_location = paste(getwd(), paste("/Comping_Results", Sys.Date(), sep = "_"), sep = "")
                           
                           Comping_Dir = dir.create(file_location)
                           
                           Coef_file = as.character(paste(file_location, paste(i, "txt", sep="."), sep = "/"))
                           
                           #texreg(glm_reg, file = Coef_file)
                           
                           stargazer(glm_reg, type="latex", out = Coef_file)
                           
                           
                           rm(query, Coef_file)
                           
                           as.data.frame(nz.ts)
                         }
                           
  
stopCluster(cl)

#covnvert the data into a table

df <- do.call(rbind, parallel_data)

#str(df); summary(df)

rm(DBPassword, DBuserid)

source("Functions/stat_sig_function.R")

test_mean = stat_sig_90in12_OneWay(df, df$FICO_Bckts)

#save(df,file="data.Rda")
#load("data.Rda")

# Stop the clock
proc.time() - plyr_op



