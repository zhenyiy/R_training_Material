#Read the loan data
loanData<-read.table("/home/g1usid/R/data/BookSample_StressIR_2007Weights/LoanInputOutput_subset.dat",header=TRUE,sep="|")
# Select the variables you want to examine
myvars<-c("GFeebps","Losses","StressLosses","Capital")
# Print summary of these variables
print(summary(loanData[myvars]))
#Print the data whose stresss losses are less than 0
print(nrow(loanData[loanData$StressLosses<0,]))

# Simple analysis looking abnormal data.
print(nrow(loanData[loanData$Losses<0,]))
print(nrow(loanData[loanData$Losses<0 & loanData$StressLosses<0,]))

print(nrow(loanData[loanData$Losses>0 & loanData$StressLosses<0,]))

#Print records whose expected losses less than 0 and Gfee is more than 100
print(summary(loanData[loanData$Losses<0,][myvars]))

print(summary(loanData[loanData$StressLosses<0,][myvars]))

# Get maximum stress losses for loans that has expected losses less than zero
maxStressLoss<-max(loanData[loanData$Losses<0,]$StressLosses)

# Print 
print(loanData[loanData$Losses<0 & loanData$StressLosses==maxStressLoss,][myvars])

print(loanData[loanData$Losses>0 & loanData$StressLosses<0,][myvars])

library(psych)

describe(loanData[myvars])

x<-loanData$Capital
#Let us see whether description justifies actual distribution
h<-hist(x,breaks=100,col="red",xlab="Capital distribution in Bps",main="Capital Distribution")

#Grouping data to different MLTV buckets
loanData$MLTV_BUCKET<-"0"
loanData[loanData$COMBINED_MTMLTV_RATE<=0.6,]$MLTV_BUCKET<-"<=0.6"
loanData[loanData$COMBINED_MTMLTV_RATE>0.6 & loanData$COMBINED_MTMLTV_RATE<=0.65,]$MLTV_BUCKET<-"(0.6-0.65]"
loanData[loanData$COMBINED_MTMLTV_RATE>0.65 & loanData$COMBINED_MTMLTV_RATE<=0.70,]$MLTV_BUCKET<-"(0.65-0.70]"
loanData[loanData$COMBINED_MTMLTV_RATE>0.70 & loanData$COMBINED_MTMLTV_RATE<=0.75,]$MLTV_BUCKET<-"(0.70-0.75]"
loanData[loanData$COMBINED_MTMLTV_RATE>0.75 & loanData$COMBINED_MTMLTV_RATE<=0.80,]$MLTV_BUCKET<-"(0.70-0.75]"
loanData[loanData$COMBINED_MTMLTV_RATE>0.80 & loanData$COMBINED_MTMLTV_RATE<=0.85,]$MLTV_BUCKET<-"(0.80-0.85]"
loanData[loanData$COMBINED_MTMLTV_RATE>0.85 & loanData$COMBINED_MTMLTV_RATE<=0.90,]$MLTV_BUCKET<-"(0.85-0.90]"
loanData[loanData$COMBINED_MTMLTV_RATE>0.90 & loanData$COMBINED_MTMLTV_RATE<=0.95,]$MLTV_BUCKET<-"(0.90-0.95]"
loanData[loanData$COMBINED_MTMLTV_RATE>0.95 & loanData$COMBINED_MTMLTV_RATE<=0.97,]$MLTV_BUCKET<-"(0.95-0.97]"
loanData[loanData$COMBINED_MTMLTV_RATE>0.97,]$MLTV_BUCKET<-">0.97"

#Grouping data to different FICO buckets
loanData$FICO_BUCKET<-"0"
loanData[loanData$CBD_CURRENT_FICO<=620,]$FICO_BUCKET<-"<=620"
loanData[loanData$CBD_CURRENT_FICO>620 & loanData$CBD_CURRENT_FICO<=640,]$FICO_BUCKET<-"(620-640]"
loanData[loanData$CBD_CURRENT_FICO>640 & loanData$CBD_CURRENT_FICO<=660,]$FICO_BUCKET<-"(640-660]"
loanData[loanData$CBD_CURRENT_FICO>660 & loanData$CBD_CURRENT_FICO<=680,]$FICO_BUCKET<-"(660-680]"
loanData[loanData$CBD_CURRENT_FICO>680 & loanData$CBD_CURRENT_FICO<=700,]$FICO_BUCKET<-"(680-700]"
loanData[loanData$CBD_CURRENT_FICO>700 & loanData$CBD_CURRENT_FICO<=720,]$FICO_BUCKET<-"(700-720]"
loanData[loanData$CBD_CURRENT_FICO>720 & loanData$CBD_CURRENT_FICO<=740,]$FICO_BUCKET<-"(720-740]"
loanData[loanData$CBD_CURRENT_FICO>740,]$FICO_BUCKET<-">740"


#aggregate upb by MLTV bucket
aggregate(loanData$CURRENT_UPB_DOLLAR,by=list(MLTV=loanData$MLTV_BUCKET),sum)
aggregate(loanData$CURRENT_UPB_DOLLAR,by=list(MLTV=loanData$MLTV_BUCKET),mean)

#Using describe fucntion for selected loanData variables
dstats<-function(x) sapply(x,describe)
by(loanData[myvars],loanData$MLTV_BUCKET,dstats)

#Table freequencies
table(loanData$FICO_BUCKET,loanData$MLTV_BUCKET)
xtabs(loanData$CURRENT_UPB_DOLLAR~loanData$FICO_BUCKET+loanData$MLTV_BUCKET)
#Create long format of grid tables
aggData<-aggregate(loanData$CURRENT_UPB_DOLLAR,by=list(MLTV=loanData$MLTV_BUCKET,FICO=loanData$FICO_BUCKET),sum)
colnames(aggData)[3]<-"UPB"
library(reshape2)

# Convert them to wide format of grid tables
dcast(aggData,MLTV~FICO,value.var="UPB")

loanData$WtGfeeBps<-loanData$GFeebps*loanData$CURRENT_UPB_DOLLAR*loanData$PVMTsy
loanData$GfeeWeight<-loanData$CURRENT_UPB_DOLLAR*loanData$PVMTsy
# Creating Gfee grid table.
aggData<-aggregate(data.frame(loanData$WtGfeeBps,loanData$GfeeWeight),by=list(MLTV=loanData$MLTV_BUCKET,FICO=loanData$FICO_BUCKET),sum)

#GfeeGrid[,c(names(GfeeGrid[1]),rev(names(GfeeGrid)[-1]))]

colnames(aggData)[3]<-"WeightedGfeeBps"
colnames(aggData)[4]<-"GfeeWeight"
aggData$GfeeBps<-aggData$WeightedGfeeBps/aggData$GfeeWeight

# Convert long forwat to wide format
GfeeGrid<-dcast(aggData,FICO~MLTV,value.var="GfeeBps")
print(GfeeGrid)
# Reverse row names to create LLPA matrix type of grid
print(GfeeGrid[rev(rownames(GfeeGrid)),])

#Alternative way using xtabs
WtGfee<-xtabs(WtGfeeBps~FICO_BUCKET+MLTV_BUCKET,data=loanData)
GfeeWeight<-xtabs(GfeeWeight~FICO_BUCKET+MLTV_BUCKET, data=loanData)
altGfeeGrid<-WtGfee/GfeeWeight
print(altGfeeGrid[rev(rownames(altGfeeGrid)),])

# Correlation testing
testvars<-c("CURRENT_UPB_DOLLAR","COMBINED_MTMLTV_RATE","CBD_CURRENT_FICO","BACKEND_RATIO_RATE","GFeebps")
corr.test(loanData[testvars],use="complete")

# Testing correlation between capital and Gfee
cor(loanData$Capital,loanData$GFeebps)
# Plot capital and Gfee. See any relationship exist
plot(loanData$Capital,loanData$GFeebps,main="Basic scatter plot of Capital vs GFee",xlab="Capital",ylab="Gfee",pch=19)

library(car)
# Drow scatter plot between Gfee vs Losses. Observe correlations between Gfee and losses
scatterplotMatrix(~loanData$GFeebps+loanData$Losses+loanData$StressLosses,main="Basic Scallter plot matrix")

# Linear regression fit between Gaurantee fees and losses
fit<-lm(loanData$GFeebps ~ loanData$Losses + loanData$StressLosses)
par(mfrow=c(2,2))
plot(fit)
summary(fit)
confint(fit)
#Linear regression fit between Gfee with losses and stress losses
fit<-lm(I(GFeebps *PVM) ~ Losses + StressLosses,data=loanData)
summary(fit)
confint(fit)

# When I use I function some how plot don't plot scale location and residula vs leverage plots. So I am avoiding them.
fit<-lm(GFeePVbps ~ Losses + StressLosses,data=loanData)
par(mfrow=c(2,2))
plot(fit)

