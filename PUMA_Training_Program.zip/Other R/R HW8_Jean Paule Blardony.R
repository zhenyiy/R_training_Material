#############################################################################
### Problem 1 - Reformat dates of LPPub acquisition and performance data  ###
### from character to date as file is being read into global environment  ###
#############################################################################

# Load required packages

require(data.table)
require(doParallel)
require(foreach)
require(stringr)

# Indicate which files are being read, using grep to separate acquisition and performance file paths into respective vectors

file_list <- c("/home/d1uhak/LPPub/Data//Performance_2014Q4.txt", "/home/d1uhak/LPPub/Data//Performance_2014Q3.txt", "/home/d1uhak/LPPub/Data//Acquisition_2014Q4.txt", "/home/d1uhak/LPPub/Data//Acquisition_2014Q3.txt")
acqui_files <- grep("Acquisition", file_list, value = TRUE)
acqui_files
perf_files <- grep("Performance", file_list, value = TRUE)
perf_files
num_files = as.numeric(length(file_list))

# Use foreach loop in parallel to read two acquisition and performance files while converting dates from characters to date type

cl <- makeCluster(4)
registerDoParallel(cl)

parallel_readtable_withDateConversion <- foreach(i = 1:2, .inorder = FALSE) %dopar% {
  
  require(data.table)
  
  # Set variable names and classes using the custom date class in place of the given classes
  
  perf_colclasses = c("character", "myDate1", "character", "numeric", "numeric", "numeric", "numeric", "numeric", "myDate2", "character", "character", "character", "character", "myDate2", "myDate1", "myDate1", "myDate1", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric")
  perf_varnames = c("LOAN_IDENTIFIER", "MONTHLY_REPORTING_PERIOD", "SERVICER_NAME",	"CURRENT_INTEREST_RATE",	"CURRENT_ACTUAL_UNPAID_PRINCIPAL_BALANCE_(UPB)",	"LOAN_AGE",	"REMAINING_MONTHS_TO_LEGAL_MATURITY",	"ADJUSTED_REMAINING_MONTHS_TO_MATURITY",	"MATURITY_DATE",	"METROPOLITAN_STATISTICAL_AREA_(MSA)",	"CURRENT_LOAN_DELINQUENCY_STATUS",	"MODIFICATION_FLAG",	"ZERO_BALANCE_CODE",	"ZERO_BALANCE_EFFECTIVE_DATE",	"LAST_PAID_INSTALLMENT_DATE",	"FORECLOSURE_DATE",	"DISPOSITION_DATE",	"FORECLOSURE_COSTS",	"PROPERTY_PRESERVATION_AND_REPAIR_COSTS",	"ASSET_RECOVERY_COSTS",	"MISCELLANEOUS_HOLDING_EXPENSES_AND_CREDITS",	"ASSOCIATED_TAXES_FOR_HOLDING_PROPERTY",	"NET_SALE_PROCEEDS",	"CREDIT_ENHANCEMENT_PROCEEDS",	"REPURCHASE_MAKE_WHOLE_PROCEEDS",	"OTHER_FORECLOSURE_PROCEEDS",	"NON_INTEREST_BEARING_UPB",	"PRINCIPAL_FORGIVENESS_UPB")
  
  acqui_colclasses = c("character",	"character",	"character",	"numeric",	"numeric",	"numeric",	"myDate2",	"myDate2",	"numeric",	"numeric",	"numeric",	"numeric",	"numeric",	"character",	"character",	"character",	"character",	"character",	"character",	"character",	"numeric", "character", "numeric")
  acqui_varnames = c("LOAN_IDENTIFIER",	"CHANNEL",	"SELLER_NAME",	"ORIGINAL_INTEREST_RATE", "ORIGINAL_UNPAID_PRINCIPAL_BALANCE_(UPB)",	"ORIGINAL_LOAN_TERM",	"ORIGINATION_DATE",	"FIRST_PAYMENT_DATE",	"ORIGINAL_LOAN-TO-VALUE_(LTV)",	"ORIGINAL_COMBINED_LOAN-TO-VALUE_(CLTV)",	"NUMBER_OF_BORROWERS",	"DEBT-TO-INCOME_RATIO_(DTI)",	"BORROWER_CREDIT_SCORE", "FIRST-TIME_HOME_BUYER_INDICATOR",	"LOAN_PURPOSE",	"PROPERTY_TYPE",	"NUMBER_OF_UNITS",	"OCCUPANCY_STATUS",	"PROPERTY_STATE",	"ZIP_(3-DIGIT)",	"MORTGAGE_INSURANCE_PERCENTAGE", "PRODUCT_TYPE", "CO-BORROWER_CREDIT_SCORE")
  
  # Use fread to read performance and acquisition data into respective lists and convert dates from character type to date
  
  perf_data <- fread(perf_files[i], sep = "|", colClasses = perf_colclasses)
  setnames(perf_data, perf_varnames)
  perf_data$MONTHLY_REPORTING_PERIOD <- as.Date(perf_data$MONTHLY_REPORTING_PERIOD, "%m/%d/%Y") 
  perf_data$MATURITY_DATE <- as.Date(perf_data$MATURITY_DATE, "%m/%d/%Y")
  perf_data$ZERO_BALANCE_EFFECTIVE_DATE <- as.Date(perf_data$ZERO_BALANCE_EFFECTIVE_DATE, "%m/%d/%Y")
  perf_data$LAST_PAID_INSTALLMENT_DATE <- as.Date(perf_data$LAST_PAID_INSTALLMENT_DATE, "%m/%d/%Y")
  perf_data$FORECLOSURE_DATE <- as.Date(perf_data$FORECLOSURE_DATE, "%m/%d/%Y")
  perf_data$DISPOSITION_DATE <- as.Date(perf_data$DISPOSITION_DATE, "%m/%d/%Y")
  
  acqui_data <- fread(acqui_files[i], sep = "|", colClasses = acqui_colclasses)
  setnames(acqui_data, acqui_varnames)
  acqui_data$ORIGINATION_DATE <- as.Date(acqui_data$ORIGINATION_DATE, "%m/%d/%Y")
  acqui_data$FIRST_PAYMENT_DATE <- as.Date(acqui_data$FIRST_PAYMENT_DATE, "%m/%d/%Y")
  
  data_list <- list(perf_data, acqui_data)
  
}

stopCluster(cl)

str(parallel_readtable_withDateConversion[1])


############################################################################
### Problem 2 - Create parallel process to create tables of FICO and LTV ###
### from five conseuctive months of acquisition data from Neteeza        ###
############################################################################

cl <- makeCluster(num_months)
registerDoParallel(cl)

parallel_acquisition_risk_table <- foreach(i = query_dates, .packages = c("RJDBC", "stringr", "rJava", "RSQLite"), .inorder = FALSE) %dopar% {
  
  # Create list of query dates
  
  query_dates <- c("'01-AUG-2015'", "'01-SEP-2015'", "'01-OCT-2015'", "'01-NOV-2015'", "'01-DEC-2015'")
  num_months = as.numeric(length(query_dates))
  
  # Create query with dates using sprintf()
  
  query <- sprintf("SELECT FNMA_LN, FICO, LTV, AQ_ACTDT 
                   FROM NZ_PUMA_TAB_POP 
                   WHERE AQ_ACTDT = %s", i)
  
  # Connect to Neteeza query in loss data
  
  .jinit(classpath="myClasses.jar", parameters="-Xmx512m")
  .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
  .jclassPath()
  
  drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
  con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
  netres <- dbSendQuery(con, query) #query instruction
  my.data <- data.frame(fetch(netres, n = -1))
  attach(my.data)
  dbDisconnect(con)

  # Create buckets for FICO: 'Missing FICO', '[0-680)', '[680-720)','[720-760)', '[760+)'
  
FICO_dist <- cut(my.data$FICO, breaks = c(0, 680, 720, 760, Inf), labels = c('[0-680)', '[680-720)','[720-760)', '[760+)'), include.lowest = TRUE, right = FALSE)
FICO_table <- table(FICO_dist)
FICO_table
  
# Create buckets for LTV: 'Missing LTV', '[0-60)', '[60-70)', '[70-80)', '[80-90)', '[90-95)', '(95+)'
  
LTV_dist <- cut(my.data$LTV, breaks = c(0, .60, .70, .80, .90, .95, Inf), labels = c('[0-60)', '[60-70)', '[70-80)', '[80-90)', '[90-95)', '(95+)'), include.lowest = TRUE, right = FALSE)
LTV_table <- table(LTV_dist)
LTV_table

output <- list(FICO_table, LTV_table)

}  

stopCluster(cl)

str(parallel_acquisition_risk_table)


#################################################################
### Problem 3 - Create a random number using parallel process ###
#################################################################

# Load packages
library(foreach)
library(doParallel)

# Define number of iterations for rnorm
iters <- 50

# Setup parallel backend to use 50 processors
cl <-makeCluster(10)
registerDoParallel(cl)

# Loop
random_number_generator <- foreach(icount(iters)) %dopar% {
  
  vector <- vector()
  vector <-rnorm(1)
  summary(vector)
  vector
  
}

stopCluster(cl)

random_number <- sample(random_number_generator, 1)
random_number


###########################################################################
### Problem 4 - Use cluster and single process to calculate NPV and IRR ###
###########################################################################

# Calculate NPV and IRR of 1 millions investment on single processor

# Define number of periods (360)
time_periods <- as.vector(replicate(1000, seq(1, 360, 1)))

# Create path
paths <- as.vector(sapply(c(1:1000), function(x) replicate(360, x)))

# Create random cash flows; min 1000, max 20000
cash_flow <- as.vector(replicate(1000, runif(360, min = 1000, max = 20000)))

# Create random forward rate vector; min .001, max .10
fwd_rates <- as.vector(replicate(1000, runif(360, min = .001, max = .10)))

# Populate data.frame
tvm_schedule <- data.frame(time_periods, paths, cash_flow, fwd_rates)
colnames(tvm_schedule) <- c("Month", "Path", "Cash_Flow", "Forward_Rate")
str(tvm_schedule)

# Aggregate data and calculate mean of cash flow and forward rates along each path; create single data.frame and add discount factor column
agg_cash_mean <- aggregate(Cash_Flow ~ Month, tvm_schedule, mean)
agg_fwdrates_mean <- aggregate(Forward_Rate ~ Month, tvm_schedule, mean)
agg_tvm_schedule <- data.frame(seq(1, 360, 1), agg_cash_mean$Cash_Flow, agg_fwdrates_mean$Forward_Rate)
colnames(agg_tvm_schedule) <- c("Month", "Cash_Flow", "Forward_Rate")
agg_tvm_schedule$Discount_Factor <- cumprod(1 / (1 + (agg_tvm_schedule$Forward_Rate / 12)))

# Calculate NPV of aggregate mean cash flows based on aggregate mean fwd rates
NPV <- function(investment, tvm_schedule) { # Where investment is $1 million
  
  crossprod(tvm_schedule[ ,2], tvm_schedule[ ,4]) - investment
  
}

# NPV of average cash flows and forward rates over 1000 uniformly random paths
NPV(1000000, agg_tvm_schedule) 

# IRR of average cash flows 
IRR <- function(investment, cash_flows) {
  
  cf <- c(-investment, cash_flows) # define cash flows
  npv <- function(i, cf, t=seq(along=cf)) { sum(cf/(1+i)^t) } 
  irr <- function(cf) { uniroot(npv, c(0,1), cf=cf)$root }
  return (irr(cf)*12*100)
  
}

# IRR of average uniformly random cash flows given $1 million investment
IRR(1000000, agg_tvm_schedule$Cash_Flow)

# Use for each loop and parallel processing to implement 1000000 paths

require(foreach)
require(doParallel)

# Number of iterations/paths
iters <- 1000000

# Number of clusters
n = 20

# Setup parallel backend
cl <- makeCluster(n)
registerDoParallel(cl)

# Implement for loop
parallel_tvm_simulation <- foreach(i = 1:n, .inorder = FALSE) %dopar% {
  
  time_periods_par <- as.vector(replicate(iters/n, seq(1, 360, 1)))
  paths_par <- as.vector(sapply(c(1:iters), function(x) replicate(360, x)))
  cash_flow_par <- as.vector(replicate(iters/n, runif(360, min = 1000, max = 20000)))
  fwd_rates_par <- as.vector(replicate(iters/n, runif(360, min = .001, max = .10)))

}

stopCluster(cl)

tvm_schedule_par <- data.frame(time_periods_par, paths_par, cash_flow_par, fwd_rates_par)
colnames(tvm_schedule_par) <- c("Month", "Path", "Cash_Flow", "Forward_Rate")
agg_cash_mean_par <- aggregate(Cash_Flow ~ Month, tvm_schedule_par, mean)
agg_fwdrates_mean_par <- aggregate(Forward_Rate ~ Month, tvm_schedule_par, mean)
agg_tvm_schedule_par <- data.frame(seq(1, 360, 1), agg_cash_mean_par$Cash_Flow, agg_fwdrates_mean_par$Forward_Rate)
colnames(agg_tvm_schedule_par) <- c("Month", "Cash_Flow", "Forward_Rate")
agg_tvm_schedule_par$Discount_Factor <- cumprod(1 / (1 + (agg_tvm_schedule_par$Forward_Rate / 12)))

NPV(1000000, agg_tvm_schedule_par) 
IRR(1000000, agg_tvm_schedule_par$Cash_Flow)
