
###################################################################################
### CAS HW: Evaluating the relationship between net loss and home price decline ###
###################################################################################

# Connect to Neteeza query in loss data

data_query <- function(query_instruct) {
    
    library(RSQLite)
    library(RJDBC)
    library(stringr)
    
    .jinit(classpath="myClasses.jar", parameters="-Xmx4g")
    .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
    .jclassPath()
    
    drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
    con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
    netres <- dbSendQuery(con, query_instruct) #query instruction
    netres <- fetch(netres, n = -1)
    return (netres)
    dbDisconnect(con)
  
}

loss_data <- data_query("SELECT LOAN_ID, ORIG_AMT, OLTV / 100 AS OLTV_PERCENT, ORIG_AMT / OLTV_PERCENT AS ORIG_HV, 
NET_LOSS, TO_CHAR(DATE_TRUNC('QUARTER', ORIG_DTE), 'MM/DD/YY') AS ORIG_DTE, TO_CHAR(DATE_TRUNC('QUARTER', AQSN_DTE), 'MM/DD/YY') AS AQSN_DTE, 
TO_CHAR(DATE_TRUNC('QUARTER', DISP_DTE), 'MM/DD/YY') AS DISP_DTE, LAST_STAT, LAST_UPB, ZIP_3, MSA, STATE
FROM ADHOC_PCG_LPPUB_PROD
WHERE NET_LOSS IS NOT NULL
ORDER BY ORIG_DTE ASC")
str(loss_data)


# Load HPI data, creating different tables for ORIG_DTE and DISP_DTE

HPI_ORIG_colclasses <- c("character", "character", "character", "character", "numeric")
HPI_ORIG <- read.csv("HPI_ORIG.csv", header = TRUE, sep = ",", colClasses = HPI_ORIG_colclasses, stringsAsFactors = FALSE)
str(HPI_ORIG)

HPI_DISP_colclasses <- c("character", "character", "character", "character", "numeric")
HPI_DISP <- read.csv("HPI_DISP.csv", header = TRUE, sep = ",", colClasses = HPI_DISP_colclasses, stringsAsFactors = FALSE)
str(HPI_DISP)

# Merge HPI data and loss data using data.table

require(data.table)

# Convert data.frames to data.tables, setting keys to ORIG_DTE and DISP_DTE

loss_data_DT <- data.table(loss_data)
setkey(loss_data_DT, "ZIP_3", "ORIG_DTE", "DISP_DTE")
str(loss_data_DT)

HPI_ORIG_DT <- data.table(HPI_ORIG)
setkey(HPI_ORIG_DT, "ZIP_3", "ORIG_DTE")
str(HPI_ORIG_DT)

HPI_DISP_DT <- data.table(HPI_DISP)
setkey(HPI_DISP_DT, "ZIP_3", "DISP_DTE")
str(HPI_DISP_DT)

# Merge HPI values with loss data on ORIG_DTE and DISP_DTE by ZIP_3

loss_data_HPI_ORIG <- merge(loss_data_DT, HPI_ORIG_DT, allow.cartesian = TRUE)
str(loss_data_HPI_ORIG)
loss_data_HPI_DISP <- merge(loss_data_DT, HPI_DISP_DT, allow.cartesian = TRUE)
str(loss_data_HPI_DISP)


# Merge above tables on LOAN_ID

names(loss_data_HPI_ORIG)
names(loss_data_HPI_DISP)
loss_data_HPI_comp <- merge(loss_data_HPI_ORIG, loss_data_HPI_DISP, by = c("LOAN_ID", "STATE", "ZIP_3", "MSA", "ORIG_AMT", "OLTV_PERCENT", "ORIG_HV", "LAST_UPB", "NET_LOSS", "LAST_STAT", "ORIG_DTE", "AQSN_DTE", "DISP_DTE"))

# Delete unnecessary variables

loss_data_HPI_comp[ , c("YEAR.x", "YEAR.y", "QUARTER.x", "QUARTER.y") := NULL]
names(loss_data_HPI_comp)

# Reset column order

setcolorder(loss_data_HPI_comp, c("LOAN_ID", "STATE", "ZIP_3", "MSA", "ORIG_AMT", "OLTV_PERCENT", "ORIG_HV", "LAST_UPB", "NET_LOSS", "LAST_STAT", "ORIG_DTE", "AQSN_DTE", "DISP_DTE", "ORIG_INDEX", "DISP_INDEX"))
str(loss_data_HPI_comp)

# Calculate index multiple and home price decline from origination to dispossession and loss percentages

INDEX_MULTIPLE <- (loss_data_HPI_comp$DISP_INDEX / loss_data_HPI_comp$ORIG_INDEX)
DISP_HV <- (loss_data_HPI_comp$ORIG_HV * INDEX_MULTIPLE)
HV_PCT_CHG <- (DISP_HV / loss_data_HPI_comp$ORIG_HV) - 1
LOSS_PCTG <- (loss_data_HPI_comp$NET_LOSS / loss_data_HPI_comp$ORIG_AMT)

# Add above calculations as columns to data.table

loss_data_HPI_comp[ , "INDEX_MULTIPLE"] <- INDEX_MULTIPLE
loss_data_HPI_comp[ , "DISP_HV"] <- DISP_HV
loss_data_HPI_comp[ , "HV_PCT_CHG"] <- HV_PCT_CHG
loss_data_HPI_comp[ , "LOSS_PCTG"] <- LOSS_PCTG

# Aggregate key values by state and quarter

ORIG_AMT_tab <- aggregate(ORIG_AMT ~ ORIG_DTE + STATE, loss_data_HPI_comp, sum)
NET_LOSS_tab <- aggregate(NET_LOSS ~ ORIG_DTE + STATE, loss_data_HPI_comp, sum)
HV_PCT_CHG_tab <- aggregate(HV_PCT_CHG ~ ORIG_DTE + STATE, loss_data_HPI_comp, mean)

# Combine tabulated results into single data.table

tabulated_results <- data.table(ORIG_AMT_tab, NET_LOSS_tab$NET_LOSS, HV_PCT_CHG_tab$HV_PCT_CHG)
setNames(tabulated_results, c("ORIG_DTE", "STATE", "SUM_ORIG_AMT", "SUM_NET_LOSS", "AVG_HV_PCT_CHG"))
str(tabulated_results)

# Visualize results

require(ggplot2)
require(reshape2)
require(plyr)
require(scales)

LOSS_HV_data <- data.frame(LOSS_PCTG, HV_PCT_CHG) # Convert to data.frame, ggplot doesn't interact well with data.table

# Create scatterplot of loss percengtage versus percent change in home prices

ggplot(LOSS_HV_data, aes(x = HV_PCT_CHG, y = LOSS_PCTG)) + geom_point(aes(color = "blue")) + geom_smooth(method ="lm") + ggtitle("Loss vs. Change in Home Price")

# Create heatmap of loss distribution by state and year

LOSS_by_state <- aggregate(NET_LOSS ~ STATE, loss_data_HPI_comp, sum)
LOSS_by_state_df <- data.frame(LOSS_by_state)
LOSS_by_state_df_melt <- melt(LOSS_by_state_df)
LOSS_by_state_df_melt <- ddply(LOSS_by_state_df_melt, .(variable), transform, rescale = rescale(value))
ggplot(LOSS_by_state_df_melt, aes(variable, STATE)) + geom_tile(aes(fill = rescale), color = "white") + scale_fill_gradient(low = "white", high = "red") + ggtitle("Heat map of losses by state")

