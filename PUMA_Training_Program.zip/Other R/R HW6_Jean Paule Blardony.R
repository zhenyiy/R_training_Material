### Problem 1 ###

# a. What happens when you plot a data.frame?

plot(iris)


### Problem 2 ###

# Use plot(s) to describe 'diamonds'

library(ggplot2)

set.seed(2016)
dsmall <- diamonds[sample(nrow(diamonds), 300),]
str(dsmall)

plot(dsmall) # create a box scatter plot

qplot(carat, price, data=dsmall) # create scatterplot of carat and price

qplot(carat, data=dsmall, geom="histogram") # create histogram of carats

qplot(carat, data=dsmall, geom="density") # create density plot of carats

### Problem 3 ###

# Load 'agg.cfo.pool'

loan_pool <- read.table("/home/gaudss/RForInterns/Lecture2/agg.cfo.pool", header = TRUE, sep = " ", stringsAsFactors = FALSE)

# Divide loan_pool into expected and stressed CFs 

loan_pool_expected <- loan_pool[loan_pool$path <= 300, ]
loan_pool_stressed <- loan_pool[loan_pool$path > 300, ]

# Calculate average expected and stressed PREPAY and DEFAULT

avgPrepay_expected <- aggregate(PREPAY ~ month, loan_pool_expected, mean)
avgPrepay_expected

avgPrepay_stressed <- aggregate(PREPAY ~ month, loan_pool_stressed, mean)
avgPrepay_stressed

avgDefault_expected <- aggregate(DEFAULT ~ month, loan_pool_expected, mean)
avgDefault_expected

avgDefault_stressed <- aggregate(DEFAULT ~ month, loan_pool_stressed, mean)
avgDefault_stressed

# Plot data using ggplot

library(ggplot2)

ggplot(data = avgPrepay_expected, aes(x = month, y = PREPAY)) + geom_smooth()
ggplot(data = avgPrepay_stressed, aes(x = month, y = PREPAY)) + geom_smooth()
ggplot(data = avgDefault_expected, aes(x = month, y = DEFAULT)) + geom_smooth()
ggplot(data = avgDefault_stressed, aes(x = month, y = DEFAULT)) + geom_smooth()

# Plot average expected, min expected, and max expected default CFs

library(reshape2)

minDefault_expected <- aggregate(DEFAULT ~ month, loan_pool_expected, min)
maxDefault_expected <- aggregate(DEFAULT ~ month, loan_pool_expected, max)

Default_expected_combo <- data.frame(avgDefault_expected$month, avgDefault_expected$DEFAULT, maxDefault_expected$DEFAULT, minDefault_expected$DEFAULT)
colnames(Default_expected_combo) <- c("month", "Average Expected", "Max Expected", "Min Expected")

Default_melt <- melt(Default_expected_combo, id.vars = "month")

ggplot(data = Default_melt, aes(x = month, y = value)) + geom_line(aes(color=variable,group=variable))

# Plot average stressed, 5th percentile stressed, and 95th percentile stressed default CFs

Q5Default_stressed <- aggregate(DEFAULT ~ month, loan_pool_stressed, function(x) quantile(x, probs = .05))
Q95Default_stressed <- aggregate(DEFAULT ~ month, loan_pool_stressed, function(x) quantile(x, probs = .95))

Default_stressed_combo <- data.frame(avgDefault_stressed$month, avgDefault_stressed$DEFAULT, Q5Default_stressed$DEFAULT, Q95Default_stressed$DEFAULT)
colnames(Default_stressed_combo) <- c("month", "Average Stressed", "5th Percentile Stressed", "95th Percentile Stressed")

Default_stressed_melt <- melt(Default_stressed_combo, id.vars = "month")

ggplot(data = Default_stressed_melt, aes(x = month, y = value)) + geom_line(aes(color=variable,group=variable))

### Problem 4 ###

# Create function that generates N pairs of two uniform random numbers in the range [-1, 1] and produces data.frame indicating which pairs are inside the circle of unit radius.

coordinate_generator <- function(N, rad) { # N is the number of random pairs and rad is radius length
  
  xcoord <- vector()
  ycoord <- vector()
  inside_circle <- vector()
  
  xcoord <- runif(n = N, min = -rad, max = rad)
  ycoord <- runif(n = N, min = -rad, max = rad)
  
  for (i in 1:N) { # Determine whether each random pair is within circle of radius rad, 1 = inside circle, 0 = outside circle
    
    if ( ((xcoord[i] ^ 2) + (ycoord[i] ^ 2)) < rad  ) {
      inside_circle[i] <- 1
    } else {
      inside_circle[i] <- 0
    }
      
  }
  
  random_pairs_df <- data.frame(xcoord, ycoord, inside_circle, stringsAsFactors = FALSE)
  return (random_pairs_df)
    
}

set.seed(100)
coordinate_generator(100, 1)

# Function using ggplot to visualize random coordinates

library(ggplot2)

circleFun <- function(N, rad) { # N is the number of paired random coordinates, rad is the length of circle's radius
  
  require(ggplot2)
  xcoord <- vector()
  ycoord <- vector()
  inside_circle <- vector()
  
  xcoord <- runif(n = N, min = -rad, max = rad)
  ycoord <- runif(n = N, min = -rad, max = rad)
  
  for (i in 1:N) { 
    
    if( ((xcoord[i] ^ 2) + (ycoord[i] ^ 2)) < rad ) {
      inside_circle[i] <- 1
    } else {
      inside_circle[i] <- 0
    }
    
  }
  
  random_pairs_df <- data.frame(xcoord, ycoord, inside_circle, stringsAsFactors = FALSE)
  print (random_pairs_df)
  circle_plot <- ggplot(random_pairs_df, aes(xcoord, ycoord)) + geom_point(aes(color = inside_circle)) + annotate("path", x = 0 + rad * cos(seq(0, 2 * pi, length.out = 100)), y = 0 + rad * sin(seq(0, 2 * pi, length.out = 100)), color = "red") + geom_rect(aes(xmin = -1, ymin = -1, xmax = 1, ymax = 1), fill = NA, color = "red")
  print (circle_plot)
  
}

# N = 1000

set.seed(100)
circleFun(1000, 1)

# N = 100000

set.seed(101)
circleFun(100000, 1)

# N = 10000000

set.seed(102)
circleFun(10000000, 1)

### Problem 5 ###

# Plot and visualize average UPB, LTV, and FICO of 2015 acquisitions by month

data_query <- function(query_instruct) {
  
  library(RSQLite)
  library(RJDBC)
  library(stringr)
  
  .jinit(classpath="myClasses.jar", parameters="-Xmx4g")
  .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
  .jclassPath()
  
  drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
  con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
  netres <- dbSendQuery(con, query_instruct) #query instruction
  netres <- fetch(netres, n = -1)
  return (netres)
  dbDisconnect(con)
  
}

aqsn_stats_2015 <- data_query("SELECT DISTINCT TO_CHAR(AQSN_DT, 'MM-YYYY') AS AQSN_MONTH, AVG(FNMA_UPB) OVER (PARTITION BY AQSN_MONTH) AS AVG_UPB,
SUM(FNMA_UPB * LTV) OVER (PARTITION BY AQSN_MONTH) / SUM(FNMA_UPB) OVER (PARTITION BY AQSN_MONTH) AS WTD_AVG_LTV,
SUM(FNMA_UPB * FICO) OVER (PARTITION BY AQSN_MONTH) / SUM(FNMA_UPB) OVER (PARTITION BY AQSN_MONTH) AS WTD_AVG_FICO
FROM NZ_PUMA_TAB_POP
WHERE AQSN_DT BETWEEN '01-JAN-2015' AND '31-DEC-2015'")

# Create indexes of avg UPB, FICO, LTV
avg_UPB_indexed <- aqsn_stats_2015$AVG_UPB / aqsn_stats_2015$AVG_UPB[1]
wtd_avg_ltv_indexed <- aqsn_stats_2015$WTD_AVG_LTV / aqsn_stats_2015$WTD_AVG_LTV[1]
wtd_avg_fico_indexed <- aqsn_stats_2015$WTD_AVG_FICO / aqsn_stats_2015$WTD_AVG_FICO[1] 

aqsn_stats_2015_indexed <- data.frame(aqsn_stats_2015$AQSN_MONTH, avg_UPB_indexed, wtd_avg_fico_indexed, wtd_avg_ltv_indexed, stringsAsFactors = FALSE)
colnames(aqsn_stats_2015_indexed) <- c("AQSN_MONTH", "AVG_UPB", "WTD_AVG_FICO", "WTD_AVG_LTV")
aqsn_stats_2015_indexed

# Melt data.frame of indexed values
aqsn_stats_2015_indexed_melt <- melt(aqsn_stats_2015_indexed, id.vars = "AQSN_MONTH")
aqsn_stats_2015_melt

# Visualize via ggplot
ggplot(aqsn_stats_2015_indexed_melt, aes(x = AQSN_MONTH, y = value)) + geom_line(aes(color = variable,group = variable))


### Problem 6 ###

# Create heat map of FICO and LTC by UPB of January 2015 acquisitions

# Aggregate January 2015 acquisitions by FICO and LTV via SQL and import

data_query <- function(query_instruct) {
  
  library(RSQLite)
  library(RJDBC)
  library(stringr)
  
  .jinit(classpath="myClasses.jar", parameters="-Xmx4g")
  .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
  .jclassPath()
  
  drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
  con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
  netres <- dbSendQuery(con, query_instruct) #query instruction
  netres <- fetch(netres, n = -1)
  return (netres)
  dbDisconnect(con)
  
}

heat_map_Jan2015 <- data_query("SELECT DISTINCT RISK_BUCKET, (TOTAL_UPB_BY_RISK_BUCKET / TOTAL_UPB) * 100 AS RISK_BUCKET_PCT_TOTAL_UPB
FROM
(SELECT
CASE
	/*FOR FICO <700*/
	WHEN FICO < 700 AND LTV < 0.5 THEN 'FICO [0-700) & LTV [0-0.5)'
	WHEN FICO < 700 AND LTV < 0.7 THEN 'FICO [0-700) & LTV [0.5-0.7)'
	WHEN FICO < 700 AND LTV < 0.9 THEN 'FICO [0-700) & LTV [0.7-0.9)'
	WHEN FICO < 700 AND LTV > 0.9 THEN 'FICO [0-700) & LTV [0.9, +)'
	/*FOR FICO 700-750*/
	WHEN FICO < 750 AND LTV < 0.5 THEN 'FICO [700-750) & LTV [0-0.5)'
	WHEN FICO < 750 AND LTV < 0.7 THEN 'FICO [700-750) & LTV [0.5-0.7)'
	WHEN FICO < 750 AND LTV < 0.9 THEN 'FICO [700-750) & LTV [0.7-0.9)'
	WHEN FICO < 750 AND LTV > 0.9 THEN 'FICO [700-750) & LTV [0.9, +)'
	/*FOR FICO 750-800*/
	WHEN FICO < 800 AND LTV < 0.5 THEN 'FICO [750-800) & LTV [0-0.5)'
	WHEN FICO < 800 AND LTV < 0.7 THEN 'FICO [750-800) & LTV [0.5-0.7)'
	WHEN FICO < 800 AND LTV < 0.9 THEN 'FICO [750-800) & LTV [0.7-0.9)'
	WHEN FICO < 800 AND LTV > 0.9 THEN 'FICO [750-800) & LTV [0.9, +)'
	/*FOR FICO 800-850*/
	WHEN FICO <= 850 AND LTV < 0.5 THEN 'FICO [800-850] & LTV [0-0.5)'
	WHEN FICO <= 850 AND LTV < 0.7 THEN 'FICO [800-850] & LTV [0.5-0.7)'
	WHEN FICO <= 850 AND LTV < 0.9 THEN 'FICO [800-850] & LTV [0.7-0.9)'
	WHEN FICO <= 850 AND LTV > 0.9 THEN 'FICO [800-850] & LTV [0.9, +)'
	ELSE 'MISSING'
END AS RISK_BUCKET,
SUM(FNMA_UPB) OVER (PARTITION BY RISK_BUCKET)AS TOTAL_UPB_BY_RISK_BUCKET,
SUM(FNMA_UPB) OVER() TOTAL_UPB
FROM NZ_PUMA_TAB_POP
WHERE AQSN_DT BETWEEN '01-JAN-2015' AND '31-JAN-2015') A
ORDER BY RISK_BUCKET")

# Create heatmap using ggplot

require(reshape2)
require(plyr)
require(scales)
heat_map_Jan2015_melt <- melt(heat_map_Jan2015)
heat_map_Jan2015_melt <- ddply(heat_map_Jan2015_melt, .(variable), transform, rescale = rescale(value))

require(ggplot2)
heat_map_Jan2015_plot <- ggplot(heat_map_Jan2015_melt, aes(variable, RISK_BUCKET)) + geom_tile(aes(fill = rescale), color = "white") + scale_fill_gradient(low = "white", high = "steelblue")
heat_map_Jan2015_plot
  

### Problem 7 ###

# Shiny tutorial 1

library(shiny)
runExample("01_hello")

runApp("k2ujcb", display.mode = "showcase")


### Problem 10 ###

data_query <- function(query_instruct) {
  
  library(RSQLite)
  library(RJDBC)
  library(stringr)
  
  .jinit(classpath="myClasses.jar", parameters="-Xmx4g")
  .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
  .jclassPath()
  
  drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
  con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
  netres <- dbSendQuery(con, query_instruct) #query instruction
  netres <- fetch(netres, n = -1)
  return (netres)
  dbDisconnect(con)
  
}

SF_aquisitions_2015 <- data_query("SELECT STATE, AVG(FNMA_UPB) AS AVG_UPB, AVG(FICO) AS AVG_FICO, AVG(LTV) AS AVG_LTV, AVG(D_RATIOB) AS AVG_DTI
FROM NZ_PUMA_TAB_POP
WHERE TO_CHAR(AQSN_DT, 'YYYY') = 2015
GROUP BY STATE")

# Create heat map of key credit risk metrics

require(reshape2)
require(ggplot2)
require(plyr)
library(scales)

data_melt <- melt(SF_aquisitions_2015)
data_melt <- ddply(data_melt, .(variable), transform, rescale = rescale(value))

data_plot <- ggplot(data_melt, aes(variable, STATE)) + geom_tile(aes(fill = rescale), color = "white") + scale_fill_gradient(low = "white", high = "steelblue")
data_plot

