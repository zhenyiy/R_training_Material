###############################################################################
# R Final Project: Portfolio Optimization                                     #
# Determining optimal weight of MBS portfolio in a well-diversified portfolio #
# on mean-variance basis pre-Crisis, during crisis, and post-crisis           #
###############################################################################

library(ggplot2)
library(reshape2)

# Part 1a: Optimization pre-Crisis

# Load UST T-bill monthly rates and monthly excess returns for benchmarks
# Set names for asset classes
# Format dates

benchmark_names <- c("Date", "UST_1month", "Global_portfolio", "Global_equity", "US_MBS", "EM_equity", "Alternative", "Commodities", "Real_estate", "Global_gov_IG", "EM_debt", "Global_corp_credit")
returns <- read.csv("Market_Monthly_Returns.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)
colnames(returns) <- benchmark_names
returns$Date <- as.Date(returns$Date, "%m/%d/%Y")

excess_returns <- read.csv("Market_Monthly_Excess_Returns.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)
colnames(excess_returns) <- benchmark_names
excess_returns$Date <- as.Date(excess_returns$Date, "%m/%d/%Y")

str(returns)
head(returns)
head(excess_returns)

# Extract data for pre-crisis period: 2000-2006, remove date columns and UST and global portfolio

precrisis_returns <- returns[returns$Date <= "2006-12-31", ]
precrisis_returns <- precrisis_returns[ ,-1:-3]

# Calculate total weight vector: condition of Lagrange portfolio optimization (weights equal 1)

tweight <- rep(1, ncol(precrisis_returns))

# Calculate mean return for the period

mean_return_precrisis <- colMeans(precrisis_returns)
round(mean_return_precrisis, 5)

# Calculate covariance of asset class returns; produces covariance matrix

cov_matrix_precrisis <- cov(precrisis_returns)
round(cov_matrix_precrisis, 5)

# Rbind covariance matrix, total weight vector, and mean returns

lagrange_matrix <- rbind(cov_matrix_precrisis, tweight, mean_return_precrisis)
lagrange_matrix <- cbind(lagrange_matrix, rbind(t(tail(lagrange_matrix, 2)), matrix(0, 2, 2)))
round(lagrange_matrix, 5)

# Determine target monthly return; .0.5% monthly return, 6% annual

mu <- 0.005
b <- c(rep(0, ncol(precrisis_returns)), 1, mu)
b

# Determine optimal weights of asset classes

optweights <- round(solve(lagrange_matrix, b), 5)
optweights
optweights_df = data.frame(rbind(as.vector(optweights[-10:-11])))
names(optweights_df) <- names(optweights[-10:-11])
df.molten <- melt(optweights_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten
ggplot(data = df.molten, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Optimal Portfolio Weights, 2000-2006") + xlab("Asset Class") + ylab("Portfolio Weight")

# Draw efficient frontier for a range of target returns

minvar_frontier <- function(n, r, Q, l) {
  require(ggplot2)
  return_range <- seq(min(r), max(r), length = 100) # y-axis of expected return 
  s <- sapply(return_range, function(x) {
    y <- head(solve(l, c(rep(0, n), 1, x)), n) 
    y %*% Q %*% y 
  }) # x-axis of variance
  ggplot(data = data.frame(s, return_range), aes(x = s, y = return_range)) + geom_point(color = "orange") + theme_light() + ggtitle("Minimum Variance Frontier, 2000-2006") + xlab("Portfolio Variance") + ylab("Expected Return")
}

minvar_frontier(9, mean_return_precrisis, cov_matrix_precrisis, lagrange_matrix)

# Part 1b: Conduct optimization with risk-free asset 

# Add zeros to covariance matrix, indicating rf has 0 covariance via returns of other portfolio

n_assets <- 10 # Number of original assets plus the risk-free (10)
cov_matrix_precrisis_rf <- rbind(cov_matrix_precrisis, rep(0, (n_assets) - 1))
cov_matrix_precrisis_rf <- cbind(cov_matrix_precrisis_rf, rep(0, n_assets))
rownames(cov_matrix_precrisis_rf)[10] <- "rf"
colnames(cov_matrix_precrisis_rf)[10] <- "rf"
cov_matrix_precrisis_rf

# Calculate mean 1mo T-bill for the period
mean_rf_precrisis <- mean(returns[returns$Date <= "2006-12-31", ][ ,2])
mean_rf_precrisis
mean_return_precrisis_rf <- c(mean_return_precrisis, mean_rf_precrisis)
names(mean_return_precrisis_rf)[10] <- "rf"
mean_return_precrisis_rf

# Adjust lagrange matrix for rf dimension

tweight_rf <- rep(1, n_assets)
lagrange_matrix_rf <- rbind(cov_matrix_precrisis_rf, tweight_rf, mean_return_precrisis_rf)
lagrange_matrix_rf <- cbind(lagrange_matrix_rf, rbind(t(tail(lagrange_matrix_rf, 2)), matrix(0, 2, 2)))
round(lagrange_matrix_rf, 5)

# Determine target monthly return; .0.5% monthly return, 6% annual

mu <- 0.005
b_rf <- c(rep(0, n_assets), 1, mu)
b_rf

# Determine optimal weights of asset classes with risk-free

optweights_rf <- round(solve(lagrange_matrix_rf, b_rf), 5)
optweights_rf_df <- data.frame(rbind(as.vector(optweights_rf[-11:-12])))
names(optweights_rf_df) <- names(optweights_rf[-11:-12])
df.molten_rf <- melt(optweights_rf_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten_rf
ggplot(data = df.molten_rf, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Optimal Portfolio Weights with Risk-free Asset, 2000-2006") + xlab("Asset Class") + ylab("Portfolio Weight")

# Determine market portfolio

market_portfolio_precrisis <- head(optweights_rf, -3) / sum(head(optweights_rf, -3))
market_portfolio_precrisis_df <- data.frame(rbind(as.vector(market_portfolio_precrisis)))
names(market_portfolio_precrisis_df) <- names(market_portfolio_precrisis)
df.molten_mp <- melt(market_portfolio_precrisis_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten_mp
ggplot(data = df.molten_mp, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Market Portfolio, 2000-2006") + xlab("Asset Class") + ylab("Portfolio Weight")

#######################################################################

# Part 2a: Optimization during Crisis

# Extract data for crisis period: 2007-2010, remove date columns and UST and global portfolio

crisis_returns <- returns[returns$Date > "2006-12-31" & returns$Date <= "2010-12-31", ]
crisis_returns <- crisis_returns[ ,-1:-3]

# Calculate total weight vector: condition of Lagrange portfolio optimization (weights equal 1)

tweight2 <- rep(1, ncol(crisis_returns))

# Calculate mean return for the period

mean_return_crisis <- colMeans(crisis_returns)
round(mean_return_crisis, 5)

# Calculate covariance of asset class returns; produces covariance matrix

cov_matrix_crisis <- cov(crisis_returns)
round(cov_matrix_crisis, 5)

# Rbind covariance matrix, total weight vector, and mean returns

lagrange_matrix_crisis <- rbind(cov_matrix_crisis, tweight2, mean_return_crisis)
lagrange_matrix_crisis <- cbind(lagrange_matrix_crisis, rbind(t(tail(lagrange_matrix_crisis, 2)), matrix(0, 2, 2)))
round(lagrange_matrix_crisis, 5)

# Determine target monthly return; .0.5% monthly return, 6% annual

mu <- 0.005
b_crisis <- c(rep(0, ncol(crisis_returns)), 1, mu)
b_crisis

# Determine optimal weights of asset classes

optweights_crisis <- round(solve(lagrange_matrix_crisis, b_crisis), 5)
optweights_crisis
optweights_crisis_df = data.frame(rbind(as.vector(optweights_crisis[-10:-11])))
names(optweights_crisis_df) <- names(optweights_crisis[-10:-11])
df.molten_crisis <- melt(optweights_crisis_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten_crisis
ggplot(data = df.molten_crisis, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Optimal Portfolio Weights, 2007-2010") + xlab("Asset Class") + ylab("Portfolio Weight")

# Draw efficient frontier for a range of target returns

minvar_frontier <- function(n, r, Q, l) {
  require(ggplot2)
  return_range <- seq(min(r), max(r), length = 100) # y-axis of expected return 
  s <- sapply(return_range, function(x) {
    y <- head(solve(l, c(rep(0, n), 1, x)), n) 
    y %*% Q %*% y 
  }) # x-axis of variance
  ggplot(data = data.frame(s, return_range), aes(x = s, y = return_range)) + geom_point(color = "orange") + theme_light() + ggtitle("Minimum Variance Frontier, 2007-2010") + xlab("Portfolio Variance") + ylab("Expected Return")
}

minvar_frontier(9, mean_return_crisis, cov_matrix_crisis, lagrange_matrix_crisis)

# Part 2b: Conduct optimization with risk-free asset 

# Add zeros to covariance matrix, indicating rf has 0 covariance via returns of other portfolio

n_assets <- 10 # Number of original assets plus the risk-free (10)
cov_matrix_crisis_rf <- rbind(cov_matrix_crisis, rep(0, (n_assets) - 1))
cov_matrix_crisis_rf <- cbind(cov_matrix_crisis_rf, rep(0, n_assets))
rownames(cov_matrix_crisis_rf)[10] <- "rf"
colnames(cov_matrix_crisis_rf)[10] <- "rf"
cov_matrix_crisis_rf

# Calculate mean 1mo T-bill for the period 2007-2010
mean_rf_crisis <- mean(returns[returns$Date > "2006-12-31" & returns$Date <= "2010-12-31", ][ ,2])
mean_rf_crisis
mean_return_crisis_rf <- c(mean_return_crisis, mean_rf_crisis)
names(mean_return_crisis_rf)[10] <- "rf"
mean_return_crisis_rf

# Adjust lagrange matrix for rf dimension

tweight2_rf <- rep(1, n_assets)
lagrange_matrix_crisis_rf <- rbind(cov_matrix_crisis_rf, tweight2_rf, mean_return_crisis_rf)
lagrange_matrix_crisis_rf <- cbind(lagrange_matrix_crisis_rf, rbind(t(tail(lagrange_matrix_crisis_rf, 2)), matrix(0, 2, 2)))
round(lagrange_matrix_crisis_rf, 5)

# Determine target monthly return; .0.5% monthly return, 6% annual

mu <- 0.005
b_crisis_rf <- c(rep(0, n_assets), 1, mu)
b_crisis_rf

# Determine optimal weights of asset classes with risk-free

optweights_crisis_rf <- round(solve(lagrange_matrix_crisis_rf, b_crisis_rf), 5)
optweights_crisis_rf_df <- data.frame(rbind(as.vector(optweights_crisis_rf[-11:-12])))
names(optweights_crisis_rf_df) <- names(optweights_crisis_rf[-11:-12])
df.molten_crisis_rf <- melt(optweights_crisis_rf_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten_crisis_rf
ggplot(data = df.molten_crisis_rf, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Optimal Portfolio Weights with Risk-free Asset, 2007-2010") + xlab("Asset Class") + ylab("Portfolio Weight")

# Determine market portfolio

market_portfolio_crisis <- head(optweights_crisis_rf, -3) / sum(head(optweights_crisis_rf, -3))
market_portfolio_crisis_df <- data.frame(rbind(as.vector(market_portfolio_crisis)))
names(market_portfolio_crisis_df) <- names(market_portfolio_crisis)
df.molten_crisis_mp <- melt(market_portfolio_crisis_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten_crisis_mp
ggplot(data = df.molten_crisis_mp, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Market Portfolio, 2007-2010") + xlab("Asset Class") + ylab("Portfolio Weight")

##############################################################################

# Part 3a: Optimization post-Crisis

# Extract data for post-crisis period: 2011-2015, remove date columns and UST and global portfolio

postcrisis_returns <- returns[returns$Date > "2010-12-31", ]
postcrisis_returns <- postcrisis_returns[ ,-1:-3]

# Calculate total weight vector: condition of Lagrange portfolio optimization (weights equal 1)

tweight3 <- rep(1, ncol(postcrisis_returns))

# Calculate mean return for the period

mean_return_postcrisis <- colMeans(postcrisis_returns)
round(mean_return_postcrisis, 5)

# Calculate covariance of asset class returns; produces covariance matrix

cov_matrix_postcrisis <- cov(postcrisis_returns)
round(cov_matrix_postcrisis, 5)

# Rbind covariance matrix, total weight vector, and mean returns

lagrange_matrix_postcrisis <- rbind(cov_matrix_postcrisis, tweight3, mean_return_postcrisis)
lagrange_matrix_postcrisis <- cbind(lagrange_matrix_postcrisis, rbind(t(tail(lagrange_matrix_postcrisis, 2)), matrix(0, 2, 2)))
round(lagrange_matrix_postcrisis, 5)

# Determine target monthly return; .0.5% monthly return, 6% annual

mu <- 0.005
b_postcrisis <- c(rep(0, ncol(postcrisis_returns)), 1, mu)
b_postcrisis

# Determine optimal weights of asset classes

optweights_postcrisis <- round(solve(lagrange_matrix_postcrisis, b_postcrisis), 5)
optweights_postcrisis
optweights_postcrisis_df = data.frame(rbind(as.vector(optweights_postcrisis[-10:-11])))
names(optweights_postcrisis_df) <- names(optweights_postcrisis[-10:-11])
df.molten_postcrisis <- melt(optweights_postcrisis_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten_postcrisis
ggplot(data = df.molten_postcrisis, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Optimal Portfolio Weights, 2011-2015") + xlab("Asset Class") + ylab("Portfolio Weight")

# Draw efficient frontier for a range of target returns

minvar_frontier <- function(n, r, Q, l) {
  require(ggplot2)
  return_range <- seq(min(r), max(r), length = 100) # y-axis of expected return 
  s <- sapply(return_range, function(x) {
    y <- head(solve(l, c(rep(0, n), 1, x)), n) 
    y %*% Q %*% y 
  }) # x-axis of variance
  ggplot(data = data.frame(s, return_range), aes(x = s, y = return_range)) + geom_point(color = "orange") + theme_light() + ggtitle("Minimum Variance Frontier, 2011-2015") + xlab("Portfolio Variance") + ylab("Expected Return")
}

minvar_frontier(9, mean_return_postcrisis, cov_matrix_postcrisis, lagrange_matrix_postcrisis)

# Part 2b: Conduct optimization with risk-free asset 

# Add zeros to covariance matrix, indicating rf has 0 covariance via returns of other portfolio

n_assets <- 10 # Number of original assets plus the risk-free (10)
cov_matrix_postcrisis_rf <- rbind(cov_matrix_postcrisis, rep(0, (n_assets) - 1))
cov_matrix_postcrisis_rf <- cbind(cov_matrix_postcrisis_rf, rep(0, n_assets))
rownames(cov_matrix_postcrisis_rf)[10] <- "rf"
colnames(cov_matrix_postcrisis_rf)[10] <- "rf"
cov_matrix_postcrisis_rf

# Calculate mean 1mo T-bill for the period 2007-2010
mean_rf_postcrisis <- mean(returns[returns$Date > "2010-12-31", ][ ,2])
mean_rf_postcrisis
mean_return_postcrisis_rf <- c(mean_return_postcrisis, mean_rf_postcrisis)
names(mean_return_postcrisis_rf)[10] <- "rf"
mean_return_postcrisis_rf

# Adjust lagrange matrix for rf dimension

tweight3_rf <- rep(1, n_assets)
lagrange_matrix_postcrisis_rf <- rbind(cov_matrix_postcrisis_rf, tweight3_rf, mean_return_postcrisis_rf)
lagrange_matrix_postcrisis_rf <- cbind(lagrange_matrix_postcrisis_rf, rbind(t(tail(lagrange_matrix_postcrisis_rf, 2)), matrix(0, 2, 2)))
round(lagrange_matrix_postcrisis_rf, 5)

# Determine target monthly return; .0.5% monthly return, 6% annual

mu <- 0.005
b_postcrisis_rf <- c(rep(0, n_assets), 1, mu)
b_postcrisis_rf

# Determine optimal weights of asset classes with risk-free

optweights_postcrisis_rf <- round(solve(lagrange_matrix_postcrisis_rf, b_postcrisis_rf), 5)
optweights_postcrisis_rf_df <- data.frame(rbind(as.vector(optweights_postcrisis_rf[-11:-12])))
names(optweights_postcrisis_rf_df) <- names(optweights_postcrisis_rf[-11:-12])
df.molten_postcrisis_rf <- melt(optweights_postcrisis_rf_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten_postcrisis_rf
ggplot(data = df.molten_postcrisis_rf, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Optimal Portfolio Weights with Risk-free Asset, 2011-2015") + xlab("Asset Class") + ylab("Portfolio Weight")

# Determine market portfolio

market_portfolio_postcrisis <- head(optweights_postcrisis_rf, -3) / sum(head(optweights_postcrisis_rf, -3))
market_portfolio_postcrisis_df <- data.frame(rbind(as.vector(market_portfolio_postcrisis)))
names(market_portfolio_postcrisis_df) <- names(market_portfolio_postcrisis)
df.molten_postcrisis_mp <- melt(market_portfolio_postcrisis_df, variable.name = "Asset_Class", value.name = "Portfolio_Weight")
df.molten_postcrisis_mp
ggplot(data = df.molten_postcrisis_mp, aes(x = Asset_Class, y = Portfolio_Weight)) + geom_bar(stat = "identity", fill = "steelblue") + theme_light() + ggtitle("Market Portfolio, 2011-2015") + xlab("Asset Class") + ylab("Portfolio Weight")







