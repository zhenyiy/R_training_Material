ficos <- c(600, 400, 600, 800, 400)
ltvs <- c(60, 80, 80, 60, 80)
info <- data.frame(ficoltv = c('(400,80)', '(400,60)', '(600,80)', '(600,60)', '(800,80)', '(800,60)'), desc = c("poor", "poor", "poor", "good", "good", "excellent"), approve = c(F, F, F, T, T, T))

#use match function to match fico and ltv pairings to pre-defined pairings in info
ficoltv2 <- paste('(', ficos, ',', ltvs, ')', sep = "")
ficoltv2
ficoltvtable <- match(ficoltv2, info$ficoltv)
info[ficoltvtable, ]
