### Problem 1 ###

# & and && represent logical (boolean) operators. They are the code equivalent of AND.

x <- c(5,6,7)
y <- c(1,9,2)

if ( (x > y) && (x < 3)) {
  print(x)
}


### Problem 2 ###

library(ggplot2)
data("diamonds")

# for loop to count the number of diamonds where carat size is between 1 and 2

carats <- c(diamonds$carat)  
caratcount <- c()  

for (i in 1:length(carats)) {
  
  if( (carats[i] > 1) & (carats[i] <2) ) {
    caratcount[i] <- 1
  } else
    caratcount[i] <- 0
  
} 

sum(caratcount)

# basic characteristics of subset of diamonds with carat count between 1 and 2

smallcarats <- subset(carats, (carats > 1) & (carats <2) ) 
str(smallcarats)
mean(smallcarats)
summary(smallcarats)

# use while loop to print first 10 diamonds larger than 2 carats

diamonds2 <- subset(diamonds, carat > 2)

i <- 1

while (i <= 10) {
  print(diamonds2[i, ])
  i <- i + 1
}

# repeat loop to calculate average carat size and average price of all "Premium" diamonds

diamondspremium <- subset(diamonds, cut == "Premium")
prempricesum <- c()
premcrtsum <- c()

i <- 1

repeat {
  prempricesum[i] <- diamondspremium$price[i] + diamondspremium$price[i-1]
  premcrtsum[i] <- diamondspremium$carat[i] + diamondspremium$carat[i-1] 
  i <- i + 1
  if (i == nrow(diamondspremium)) {
    break
  }
}

premavgprice <- max(prempricesum) / nrow(diamondspremium)
premavgcrt <- max(premcrtsum) / nrow(diamondspremium)

premavgprice
premavgcrt 

# vectorized operation (ifelse) to count number of diamonds where carat size is between 1 and 2

caratcount2 <- ifelse((carats > 1) & (carats <2), 1, 0)
sum(caratcount2)

# random sample of n = 100 using sample function

d100 <- diamonds[sample(nrow(diamonds), 100), ]
d100

# random sample n = 100 using subset function

subset(diamonds, ) # ask Zhenyi for clue

# function to create a sample from data.frame of size n

mysample <- function(df, n) {
  df[sample(nrow(df), n), ]
}

mysample(diamonds, 10)

### Problem 3 ###

setwd("/home/gaudss/RForInterns/Lecture2") 
loanpool <- read.table("agg.cfo.pool", sep=" ", header=TRUE, stringsAsFactors=FALSE)

# descriptive analysis of loanpool

str(loanpool)
summary(loanpool)
head(loanpool)

# create function to calculate total and averages of expected and stressed cash flows

pathscalc <- function(df, col, pathnum, calc) { # remember to enter function arguments that are string with ""
  
  column <- match(col, names(df)) 
  
  if(pathnum <= 2) {
    montedf <- df[1:300, column]
  } else {
    montedf <- df[301:500, column]
  }
  
  monteanswer <- c()
  
  if(calc == "total") {
    monteanswer <- sum(montedf) 
  } else {
    monteanswer <- mean(montedf)
  }
  return(monteanswer)
  
}

pathscalc(loanpool, "BALANCE", 3, "mean")

### Problem 4 ###

USTfwd <- read.table("tsy1mo.dat", sep = " ", header = TRUE, stringsAsFactors = FALSE)
str(USTfwd)

# create TVM calculator based on forward curve

dfactor.calculator <- function(calc, n, tenor) { # determine what calculation (FV or PV), input time period and tenor of instrument 
  fwddfactor <- c()
  fwddfactorcum <- c()
  fwddfactor[1] <- (1 / (1 + (USTfwd$Tsy1Month[1] / tenor )))
  fwddfactorcum[1] <- (1 / (1 + (USTfwd$Tsy1Month[1] / tenor )))
  
  for (i in 2:length(USTfwd$Month)) {
    fwddfactor[i] <- (1 / (1 + (USTfwd$Tsy1Month[i] / tenor ))) 
    fwddfactorcum[i] <- fwddfactor[i] * fwddfactorcum[i - 1]
  }
  
  if(calc == "PV") {
    return(fwddfactorcum[n])
  } else {
    return((1 / fwddfactorcum[n]))
  }
  
} 

dfactor.calculator("PV", 24, 12)

# create TVM calculator: PV = 1,000, N = 24 months, FV = ?

TVM.calculator <- function(inv, calc, n, tenor) { # determine what calculation (FV or PV), input time period and tenor of instrument 
  fwddfactor <- c()
  fwddfactorcum <- c()
  fwddfactor[1] <- (1 / (1 + (USTfwd$Tsy1Month[1] / tenor )))
  fwddfactorcum[1] <- (1 / (1 + (USTfwd$Tsy1Month[1] / tenor )))
  
  for (i in 2:length(USTfwd$Month)) {
    fwddfactor[i] <- (1 / (1 + (USTfwd$Tsy1Month[i] / tenor ))) 
    fwddfactorcum[i] <- fwddfactor[i] * fwddfactorcum[i - 1]
  }
  
  if(calc == "PV") {
    return(inv * fwddfactorcum[n])
  } else {
    return(inv * (1 / fwddfactorcum[n]))
  }
  
} 

TVM.calculator(1000,"FV", 24, 12)

# FV = 1000, n = 12, PV = ?

TVM.calculator(1000,"PV", 12, 12)

# FV = 1000, n = 24, PV = ?

TVM.calculator(1000,"PV", 24, 12)

### Problem 5 ###

# generate two uniform random numbers

x <- runif(n = 1, min = -1, max = 1)
y <- runif(n = 1, min = -1, max = 1)
x
y

# generate 1000 pairs of uniform random numbers and determine number of pairs inside circle 

xcoord <- runif(n = 1000, min = -1, max = 1)
ycoord <- runif(n = 1000, min = -1, max = 1)

pairsincircle <- which(((xcoord ^ 2) + (ycoord^2)) < 1) # for a random coordinate to be within a circle of radius 1, the sum of the squares of its x and y coordinates must be less than the radius
length(pairsincircle)

# function to compute pi

picalc <- function(x, rad) {
  xcoord <- runif(n = x, min = -rad, max = rad)
  ycoord <- runif(n = x, min = -rad, max = rad)
  
  pairsincircle <- which(((xcoord ^ 2) + (ycoord^2)) < rad)  
  bug <- (length(pairsincircle) / x) * 4 # as n increases in size, the ratio (pairs in circle):(total pairs) multiplied by 4 approaches pi
  return(bug)
}

picalc(100000, 1)

### Problem 6 ###

# function to replace given value with NA

my.df <- data.frame (a = c(-999:-1005), b = c(-9999:-10005), c = c(-99999:-100005))

insertNA <- function(df, val1, val2, val3) {
  df[df == c(val1, val2, val3)] <- NA
  return(df)
}
  
insertNA(my.df, -999, -9999, -99999)  

### Problem 7 ###

# create a vector of 20 numbers and convert into 5x4 matrix

my.vector <- c(1:20)
my.matrix <- matrix(my.vector, nrow = 5, ncol = 4)
my.matrix

# 10x2 matrix using nrow

my.matrix2 <- matrix(my.vector, nrow = 10)
my.matrix2

# 10x2 matrix using ncol

my.matrix3 <- matrix(my.vector, ncol = 2)
my.matrix3

# nrow = 6, ncol = 4

my.matrix4 <- matrix(my.vector, nrow = 6, ncol = 4)
my.matrix4

# nrow = 4, ncol = 5

my.matrix5 <- matrix(my.vector, nrow = 4, ncol = 5)
my.matrix5

### Problem 8 ###

# call pathscalc function to produce loan cash flows

setwd("/home/gaudss/RForInterns/Lecture2") 
loanpool <- read.table("agg.cfo.pool", sep=" ", header=TRUE, stringsAsFactors=FALSE)

pathscalc <- function(df, col, pathnum, calc) { # remember to enter function arguments that are string with ""
  
  column <- match(col, names(df)) 
  
  if(pathnum <= 2) {
    montedf <- df[1:300, column]
  } else {
    montedf <- df[301:500, column]
  }
  
  monteanswer <- c()
  
  if(calc == "total") {
    monteanswer <- sum(montedf) 
  } else {
    monteanswer <- mean(montedf)
  }
  return(monteanswer)
  
}

pathscalc(loanpool, "BALANCE", 3, "mean")

# call dfactor.calculator function to produce discount rates from UST forward curve

USTfwd <- read.table("tsy1mo.dat", sep = " ", header = TRUE, stringsAsFactors = FALSE)
str(USTfwd)

dfactor.calculator <- function(calc, n, tenor) { # determine what calculation (FV or PV), input time period and tenor of instrument 
  fwddfactor <- c()
  fwddfactorcum <- c()
  fwddfactor[1] <- (1 / (1 + (USTfwd$Tsy1Month[1] / tenor )))
  fwddfactorcum[1] <- (1 / (1 + (USTfwd$Tsy1Month[1] / tenor )))
  
  for (i in 2:length(USTfwd$Month)) {
    fwddfactor[i] <- (1 / (1 + (USTfwd$Tsy1Month[i] / tenor ))) 
    fwddfactorcum[i] <- fwddfactor[i] * fwddfactorcum[i - 1]
  }
  
  if(calc == "PV") {
    return(fwddfactorcum[n])
  } else {
    return((1 / fwddfactorcum[n]))
  }
  
} 

dfactor.calculator("PV", 24, 12)

# calculate PVs of the cash flows on each of the paths
# NOTE: use aggregate function

### Problem 9 ###

# recursive Fibonacci to return the first n Fibonacci numbers in sequence

recursive.fib <- function(x) {
  
  if (length(x) > 1) return (sapply(x, recursive.fib)) #allows user to input numeric vector
  if (x == 1) return (0)
  if (x == 2) return (1)
  else return (recursive.fib(x-1) + recursive.fib(x-2)) # recursion
  
}

recursive.fib(1:10)

# use infix operator to return a Boolean (T or F) to indicate if a number is divisible by 5

'%multiple.of.five%' <- function(x) {
  if (x%%5 == 0) return (TRUE)
  else           return (FALSE)
}

'%multiple.of.five%'(11)

# use infix operator to return a Boolean (T or F) to indicate if a number is a multiple of the second 

'%multiple.of%' <- function(x, y) {
  if (x%%y == 0) return (TRUE)
  else           return (FALSE)
}

'%multiple.of%'(10, 5)

### Problem 10 ###

# load Grades.txt and convert to matrix

grades <- read.table("/home/k2ujcb/Grades.txt", header = T, sep = "\t")
grades
grades.mat <- as.matrix(grades, nrow = 10, ncol = 8, byrow = T)
grades.mat

# assign weights for Scenario 1: all homework counted

home <- .05
mid <- .20
final <- 1 - ((5 * home) + (2 * mid))
weights1 <- c(home, home, home, home, home, mid, mid, final)

# assign weights for Scenario 2: 1 homework dropped and more weight given to final exam

home2 <- .80 * home
mid2 <- mid
final2 <- 1 - ((5 * home2) + (2 * mid2))
weights2 <- c(home2, home2, home2, home2, mid2, mid2, final2)

# comparison of weights vectors

weights1
weights2

# function to calculate aggregate score

finalgrade.calc <- function(scenario) { # enter either S1 (5 HW) or S2 (4 HW)
  student_names <- cbind(c("Alan", "Ben", "Clark",	"Damien",	"Egon",	"Francis",	"Gregory",	"Henry",	"Ingrid",	"Joshua"))
  if (scenario == "S1") {
    finalgrades1 <- matrix((weights1 %*% t(grades.mat)), nrow = 10, byrow = T)
    return (cbind(student_names, finalgrades1))
  }
  
  if (scenario == "S2") { # SORRY, could not think of a more elegant way to do this...
    HWgrades <- grades.mat[ ,1:5]
    AlanHW <- rbind(sort(HWgrades[1, ], decreasing = T))
    BenHW <- rbind(sort(HWgrades[2, ], decreasing = T))
    ClarkHW <- rbind(sort(HWgrades[3, ], decreasing = T))
    DamienHW <- rbind(sort(HWgrades[4, ], decreasing = T))
    EgonHW <- rbind(sort(HWgrades[5, ], decreasing = T))
    FrancisHW <- rbind(sort(HWgrades[6, ], decreasing = T))
    GregoryHW <- rbind(sort(HWgrades[7, ], decreasing = T))
    HenryHW <- rbind(sort(HWgrades[8, ], decreasing = T))
    IngridHW <- rbind(sort(HWgrades[9, ], decreasing = T))
    JoshuaHW <- rbind(sort(HWgrades[10, ], decreasing = T))
    HW.mat <- rbind(AlanHW[ ,1:4], BenHW[ ,1:4], ClarkHW[ ,1:4], DamienHW[ ,1:4], EgonHW[ ,1:4], FrancisHW[ ,1:4], GregoryHW[ ,1:4], HenryHW[ ,1:4], IngridHW[ ,1:4], JoshuaHW[ ,1:4])
    grades.mat2 <- cbind(HW.mat, grades.mat[ ,6:8])
    finalgrades2 <- matrix((weights2 %*% t(grades.mat2)), nrow = 10, byrow = T)
    return (cbind(student_names, finalgrades2))
  }
}

finalgrade.calc("S1")

### Problem 11 ###

library(ggplot2)
mtcars

mtcars[mtcars$gear == 3, ] # Must use double '=' to indicate equal to.

mtcars[0:2, ] # Cannot subset with negative numbers. There are no negative columns or rows.

mtcars[mtcars$gear <= 4, ] # Must enter a value or blank space for columns.

mtcars[mtcars$gear == 3 | 4, ] # Need hint

### Problem 12 ###

# function that replicates diag(x) where x is a matrix

# create matrix and run diag(x)

my.mat <- matrix(c(1:9), nrow = 3, byrow = T)
diag(my.mat)

# create function that replicates diag(x)

my.diag <- function(a, b, c, d) { # where a and b are sequential elements, c = nrow, d = ncol
  
  matdiag <- c()
  
  if (c != d) return(paste("Must generate a square matrix. c == d"))
  else my.mat <- matrix(c(a:b), nrow = c, ncol = d)
  
  matdiag[1] <- my.mat[1, 1]
  
  for (i in 2:c) {
    matdiag[i] <- my.mat[i, i]
  }
  
  return (matdiag)
} 

my.diag(1, 16, 4, 4)

### Problem 13 ###

# load file

setwd("/export/appl/bo6_data0_r/Rtraining/Background")
smallprofile <- read.table("smallProfile.dat", sep="|", header=TRUE, stringsAsFactors=FALSE)
smallprofile

# random sample of n rows

row.sample <- function(df, n, col, calc) { # where df is name of dataframe, n is size of sample, col is variable name, and calc is either mean or variance
  
  rsample100 <- df[sample(nrow(df), n), ]
  column <- match(col, names(df))
  sampledf <- rsample100[ ,column]
  
  if (calc == "mean") return (mean(sampledf))
  else               return (var(sampledf))
  
}

row.sample(smallprofile, 100, "AMORT_MONTH_COUNT", "variance")

### Problem 14 ###

# use sample to randomly permute row-wise

my.df <- data.frame(a = c(1:5), b = c(6:10), c = c(11:15))
my.df

new.df <- my.df[sample(nrow(my.df)), ]
my.df
new.df

### Problem 15 ###

# matching integers and decimals

my.vector <- c(20, 3.54, -30, -4.54)

integers <- as.numeric(regmatches(my.vector,regexpr("[[:digit:]].",my.vector)))
decimals <- as.numeric(regmatches(my.vector,regexpr("+[[:digit:]]+\\.[[:digit:]]+",my.vector)))

integers
decimals

### Problem 16 ###

address.splitter <- function(add, n) { # where add is a character string of addresses and n is number of addresses

addresses <- cbind(add) 
addsplit <- c(unlist(strsplit(addresses, ", ")))
addline <- matrix(addsplit, ncol = 4, byrow = T)
newadd <- rbind()

for (i in 1:n) {
  newadd[i] <- c(addline[1, 2], addline[1, 3], addline[1, 4])
}

return (newadd)

}

address.splitter(c("1234 Main St., Washington, DC, 10001"), 1) # not working, why?

 
### Problem 17 ###

# load file

setwd("/export/appl/bo6_data0_r/Rtraining/Background")
smallprofile <- read.table("smallProfile.dat", sep="|", header=TRUE, stringsAsFactors=FALSE)
smallprofile

# cohort the loan profile by FICO score and show distribution

FICOcohorts <- c(300, 400, 500, 550, 600, 650, 700, 750, 800, 850)
FICOdist <- cut(smallprofile$CBD_CURRENT_FICO, breaks = FICOcohorts)
table(FICOdist)

# create cohort function using sequence to create cohort breaks

cohort.function <- function(begin, end, interval) {
  
  FICOcohorts <- c(seq(from = begin, to = end, by = interval))
  FICOdist <- cut(smallprofile$CBD_CURRENT_FICO, breaks = FICOcohorts)
  return (table(FICOdist))
  
}
  
cohort.function(300, 850, 50)

# adjust cohort function to make it compatible with other variables

cohort.function2 <- function(df, varname, begin, end, interval) {
  
  column <- match(varname, names(df)) 
  mindf <- df[ , column]
 
  cohorts <- c(seq(from = begin, to = end, by = interval))
  dist <- cut(mindf, breaks = cohorts)
  return (table(dist))
  
}

cohort.function2 (smallprofile, "CBD_CURRENT_FICO", 100, 850, 50)

# computational complexity of cohort calculator

system.time(cohort.function2(smallprofile, "CBD_CURRENT_FICO", 100, 850, 50))

### Problem 18 ###

prepmt.calculator <- function(prepmt.rate, multiple, T, calc) {
  
  CPR <- c()
  SMM <- c()
  step <- prepmt.rate * multiple # multiple allows user to scale up/down increases in the monthly prepayment rate
  CPR[1] <- prepmt.rate
  SMM[1] <- 1 - (1 - CPR[1]) ^ (1 / 12)
  
  for (i in 2:30) {
    CPR[i] <- CPR[i -1] + step
    SMM[i] <- 1 - (1 - CPR[i]) ^ (1 / 12)
  }
  
  if (T > 30) {
    CPR[31:T] <- CPR[30]
    SMM[31:T] <- SMM[30]
  }
  
  if (calc == "CPR") return (data.frame(CPR))
  else               return (data.frame(SMM))
  
}

prepmt.calculator(.002, 1, 35, "SMM")

  