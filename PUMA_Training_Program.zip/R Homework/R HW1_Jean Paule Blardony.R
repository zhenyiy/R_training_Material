###Problem 2###

data("diamonds")
head(diamonds)
summary(diamonds)
str(diamonds)
dsmall1 <- diamonds[sample(nrow(diamonds), 200),]
dsmall2 <- diamonds[sample(nrow(diamonds), 200),]
pdf("Diamonds.pdf")
par(pin=c(6,4))
plot(dsmall1$carat, dsmall1$price, main="Bling versus Cheddar dsmall1", xlab="Carat", ylab="Price")
plot(dsmall2$carat, dsmall2$price, main="Bling versus Cheddar dsmall2", xlab="Carat", ylab="Price")
hist(dsmall1$price, main="Histogram of Price, sample dsmall1", xlab="Price")
hist(dsmall2$price, main="Histogram of Price, sample dsmall2", xlab="Price")
dev.off()
str(dsmall1)
str(dsmall2)
summary(dsmall1)
summary(dsmall2)
set.seed(12345)
dsmall1 <- diamonds[sample(nrow(diamonds), 200),]
set.seed(12345)
dsmall2 <- diamonds[sample(nrow(diamonds), 200),]
set.seed(56789)
dsmall3 <- diamonds[sample(nrow(diamonds), 200),]
summary(dsmall1)
summary(dsmall2)
summary(dsmall3)

###Problem 3###

setwd("/home/gaudss/RForInterns/Lecture1") 
loanprofile <- read.table("smallProfile.dat", sep="|", header=TRUE, stringsAsFactors=FALSE, na.strings = "-99999")
results <- read.table("smallResults.dat", sep="|", header=TRUE, stringsAsFactors=FALSE)
str(loanprofile)
str(results)
summary(loanprofile)
summary(results)
numFICO660 <- nrow(subset(loanprofile, CBD_CURRENT_FICO < 660, select = LOAN_ID))
numFICO660 / nrow(loanprofile)
numMTMLTV0.8 <- nrow(subset(loanprofile, COMBINED_MTMLTV_RATE > 0.8, select = LOAN_ID))
numMTMLTV0.8 / nrow(loanprofile)
numBorrowers1 <- nrow(subset(loanprofile, NUMBER_OF_BORROWERS > 1, select = LOAN_ID))
numBorrowers1 / nrow(loanprofile)
numGFee100 <- nrow(subset(results, GFeebps  > 100, select = LOAN_ID))
numGFee100 / nrow(results)
numWAM72 <- nrow(subset(results, WeightedAverageLife > 72, select = LOAN_ID))
numWAM72 / nrow(results)
numFIPS <- nrow(subset(loanprofile, STATE_CATEGORY == c(11, 24, 51), select = LOAN_ID))
print(numFIPS)
numMICov <- nrow(subset(loanprofile, MI_COVERAGE_RATE > 0, select = LOAN_ID))
print(numMICov)
numLTV <- nrow(subset(loanprofile, ORIGINATION_LTV_RATE > 0.8, select = LOAN_ID))
numLTVwMI <- nrow(subset(loanprofile, ORIGINATION_LTV_RATE > 0.8 & MI_COVERAGE_RATE > 0, select = LOAN_ID))
print(numLTVwMI)
print(numLTVwMI / numLTV)

###Problem 4###

totalUPB <- sum(loanprofile$CURRENT_UPB_DOLLAR, na.rm = TRUE)
print(totalUPB)
avgFICOorig <- mean(loanprofile$ORIGINATION_MIN_FICO, na.rm = TRUE)
avgFICOcurrent <- mean(loanprofile$CBD_CURRENT_FICO, na.rm = TRUE)
print(avgFICOorig)
print(avgFICOcurrent)
setwd("/home/k2ujcb")
pdf("Loanprofile.pdf")
plot(x = loanprofile$ORIGINATION_MIN_FICO, y = loanprofile$CURRENT_NOTE_RATE, main = "Note Rate versus FICO at Origination", xlab = "FICO score at origination", ylab = "Note rate")
plot(x = loanprofile$ORIGINATION_MIN_FICO, y = loanprofile$GUARANTY_FEE_RATE, main = "Guarantee Fee versus FICO at Origination", xlab = "FICO score at origination", ylab = "Guaranty fee")
plot(x = loanprofile$ORIGINATION_LTV_RATE, y = loanprofile$GUARANTY_FEE_RATE, main = "Guarantee Fee versus LTV at Origination", xlab = "LTV at origination", ylab = "Guaranty fee")
dev.off()

###Problem 5###

randnum <- rnorm(100)
mean(randnum)
sd(randnum)
draw_mean_rnorm <- function (n, m) {
  plot(x = n, y = mean(rnorm(n)))
}
draw_mean_rnorm(100)
draw_mean_rnorm(1000)
draw_mean_rnorm(10000)
draw_mean_rnorm(100000)
draw_mean_rnorm(1000000)

###Problem 7###

17*(38-17)
log(14^7)
sqrt(436/12)

###Problem 8###

seqx <- seq(0,10,0.2)
sinx <- sin(seqx / pi)
cosx <- cos(seqx / pi)
pdf("Seqx.pdf")
par(pin=c(6,4))
plot(x = seqx, y = sinx, main = "Cosx & Sinx v. Seqx", xlab = "seqx", ylab = " ", lty = 5, pch = 20, col = "red", ylim = c(-1, 1))
lines(x = seqx, y = cosx, col = "blue")
legend(inset = 0.05, "bottomleft", c("Sinx", "Cosx"), lty = 3, col = c("red", "blue"))
dev.off()

###Problem 9###

system.time( rnorm(10000000) )
system.time( mean( rnorm(10000000) ) )
system.time( sd( rnorm(10000000) ) )
system.time(replicate(10, sd( rnorm(10000000) ) ))
system.time(replicate(5, sd( rnorm(10000000) ) ))
system.time(replicate(20, sd( rnorm(10000000) ) ))

###Problem 10###

v1 <- c(7,9,12,2,4,13)
v2 <- c(1,7,12,19,2,8,13,20,3,9,14,21)
matrix1 <- matrix(v1, nrow = 2, byrow = T)
matrix2 <- matrix(v2, nrow = 3, byrow = T)
matrix3 <- matrix1 %*% matrix2
print(matrix3)

###Problem 12###

#define inputs of amortization calculator
options(scipen=999)
mortgage_calculator <- function(principal, tenor, nrate) {
  age <- (tenor*12) 
  rate <- (nrate / 12)
  PMT <- (rate*principal*((1+rate)^age)) / (((1 + rate)^age)-1)
  
#define outputs at time i and write a loop to calculate outputs for every period thereafter
  pmtrem <- vector()
  CPN <- vector()
  amort <- vector()
  UPB <- vector()
  
  pmtrem[1] <- age - 1
  CPN[1] <- principal * (rate)
  amort[1] <- PMT - CPN[1]
  UPB[1] <- principal - amort[1]
  
  for (i in 2:age) {
    pmtrem[i] <- pmtrem[i-1] - 1
    CPN[i] <- UPB[i-1] * (rate)
    amort[i] <- PMT - CPN[i]
    UPB[i] <- UPB[i -1] - amort[i]
  }

#create data frame  
  mortgage_schedule <- data.frame(Payments_Remaining = pmtrem, Monthly_Payment = PMT, Interest_Payment = CPN, Principal_Payment = amort, Outstanding_Balance = UPB)
  return(mortgage_schedule)
  
}
mortgage_calculator(100000, 30, .05)

###Problem 13###

rn <- rnorm(100)
t.test(rn)

#t-test of mean of rn100
rn100 <- replicate(200, mean(rnorm(100)))
t.test(rn100)

#manually construct 95% confidence interval of rn200
n <- 200
rn100 <- replicate(200, mean(rnorm(100)))
mean <- mean(rn100)
stddev <- sd(rn100)
zalpha <- qnorm(.95)
error <- zalpha * (stddev / (sqrt(n)))
upper <- mean + error
lower <- mean - error
print(mean)
print(upper)
print(lower)

#1000 random numbers
n <- 100
rn1000 <- replicate(100, mean(rnorm(1000)))
mean <- mean(rn1000)
stddev <- sd(rn1000)
zalpha <- qnorm(.95)
error <- zalpha * (stddev / (sqrt(n)))
upper <- mean + error
lower <- mean - error
print(mean)
print(upper)
print(lower)

#10000 random numbers
n <- 100
rn10000 <- replicate(100, mean(rnorm(10000)))
mean <- mean(rn10000)
stddev <- sd(rn10000)
zalpha <- qnorm(.95)
error <- zalpha * (stddev / (sqrt(n)))
upper <- mean + error
lower <- mean - error
print(mean)
print(upper)
print(lower)

###Problem 14###

#a. Fibonacci sequence
fibonacci <- function(n) {
  
  fibseries <- vector()
  fibseries[1:2] <- c(0,1)
  
  for (i in 3:n)
    
    fibseries[i] <- fibseries[i-2] + fibseries[i-1]
    return(fibseries[n])
    
}

fibonacci(8)

#b. Golden ratio
goldenratio <- function(n) {
  
  gratio <- vector()
  
  for (i in 1:n)
    
    gratio[i] <- fibseries[i+1] / fibseries[i]
    return(gratio[n])
}

goldenratio(7)

#c. Factorial
factorial <- function(n) {
  
  n <- "string"
  n <- 3.14
  n <- as.integer(6)
  factor <- 1
  
  if(is.integer(n) == "TRUE") {
    if(n == 0) {
    print(1) 
    }
    else {for(i in n:1) {
    factor = factor*i
    }
    print(factor)
    }
  else {print("Please enter positive integer.")}
  }

}

factorial(171)

###Problem 15###

#load Grades.txt
grades <- read.table("/home/k2ujcb/Grades.txt", header = T, sep = "\t")
grades

#assign weights with all homework
home <- .05
mid <- .20
final <- 1 - ((5*home) + (2*mid))
weights1 <- c(home, home, home, home, home, mid, mid, final)

#assign weights with 1 homework dropped --> final exam counts for more
home2 <- .80*home
mid2 <- mid
final2 <- 1 - ((5*home2) + (2*mid2))
weights2 <- c(home2, home2, home2, home2, mid2, mid2, final2)

#compute total score for each student w/ 5 homework
hw1grades <- home*grades[2]
hw2grades <- home*grades[3]
hw3grades <- home*grades[4]
hw4grades <- home*grades[5]
hw5grades <- home*grades[6]
mid1grades <- mid*grades[7]
mid2grades <- mid*grades[8]
finalgrades <- final*grades[9]
student_names <- c("Alan", "Ben", "Clark",	"Damien",	"Egon",	"Francis",	"Gregory",	"Henry",	"Ingrid",	"Joshua")
weighted_grades <- cbind(hw1grades, hw2grades, hw3grades, hw4grades, hw5grades, mid1grades, mid2grades, finalgrades)
final_grades <- rowSums(weighted_grades)
final_grades_report <- data.frame(student_names, final_grades)
final_grades_report

#assign final letter grade to each student
letter_grade_generator <- function(x) {
  
  gradedist <- c()
  if(x >= 90){ gradedist = "A"}
  else if((x >= 80) && (x < 90)) {gradedist <- "B"}
  else if((x >= 70) && (x < 80)) {gradedist <- "C"}
  else if((x >= 60) && (x < 70)) {gradedist <- "D"}
  else if((x >= 0) && (x < 60)) {gradedist <- "F"}
  return(gradedist)
}

letter_grades <- vector()

for (i in 1:10) {
  letter_grades[i] <- letter_grade_generator(final_grades[i])
}

letter_grades_report <- cbind(final_grades_report, letter_grades)
letter_grades_report  

#replicate function using switch
x <- 95
z <- switch(x,"A" >= 90,"B" >= 80 && < 90, "C" >= 70 && < 80, "D" >= 60 && < 70, "F" >= 0 && < 60)
z

#assign "pass" "fail" using vectorized ifelse
pass_fail <- ifelse(final_grades >= 70, "Pass", "Fail")
pass_fail_report <- cbind(letter_grades_report, pass_fail)
pass_fail_report
