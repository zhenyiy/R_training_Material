setwd("/home/k2ujcb/")

### Problem 1 ###

# Load winning ticket, sample numbers, and prize files

pball_winner <- read.csv("powerball_winner.csv", header = FALSE, sep = ",")
pball_numbers <- read.csv("powerball_numbers.csv",header = FALSE, sep = ",")
pball_prizes <- read.csv("powerball_prizes.csv", header = FALSE, sep = ",")

# Create function

r_u_lucky <- function(players, winner, prizes) { # these are the input CSV files
  
  first5 <- vector()
  ball6 <- vector()
  
  for (i in 1:nrow(players)) { # create boolean sums of first 5 numbers and 6th number to determine score
    
    first5[i] <- sum( players[i, 1:5] %in% winner[1, 1:5] )
    ball6[i] <- sum( players[i, 6] %in% winner[1, 6] )
    
  }
    
  tix_matrix <- (cbind(players, first5, ball6))
  
  winnings <- vector()
  
  for (i in 1:nrow(tix_matrix)) { # compare ticket scores to prize rules
    
    if (tix_matrix[i, 7] == 0 & tix_matrix[i, 8] == 1) {winnings[i] <- prizes[2, 9]} #9th prize
    else if (tix_matrix[i, 7] == 1 & tix_matrix[i, 8] == 1) {winnings[i] <- prizes[2, 8]} #8th prize
    else if (tix_matrix[i, 7] == 2 & tix_matrix[i, 8] == 1) {winnings[i] <- prizes[2, 7]} #7th prize
    else if (tix_matrix[i, 7] == 3 & tix_matrix[i, 8] == 0) {winnings[i] <- prizes[2, 6]} #6th prize
    else if (tix_matrix[i, 7] == 3 & tix_matrix[i, 8] == 1) {winnings[i] <- prizes[2, 5]} #5th prize 
    else if (tix_matrix[i, 7] == 4 & tix_matrix[i, 8] == 0) {winnings[i] <- prizes[2, 4]} #4th prize 
    else if (tix_matrix[i, 7] == 4 & tix_matrix[i, 8] == 1) {winnings[i] <- prizes[2, 3]} #3rd prize 
    else if (tix_matrix[i, 7] == 5 & tix_matrix[i, 8] == 0) {winnings[i] <- prizes[2, 2]} #2nd prize 
    else if (tix_matrix[i, 7] == 5 & tix_matrix[i, 8] == 1) {winnings[i] <- prizes[2, 1]} #Grand prize
    else {winnings[i] <- 0}
    
  }
 
  prize_matrix <- cbind(tix_matrix, winnings)
  
  #winners_num <- vector()
  #winners_pot <- vector()
  #losers <- vector()
  
  #for (i in 1:nrow(prize_matrix)) { # sort winners and losers
    
    #if (prize_matrix[i, 9] > 0) {
      #winners_pot[i] <- prize_matrix[i, 9]
      #winners_num[i] <- as.character(prize_matrix[i, 1:6])
    #} else {losers[i] <- as.character(prize_matrix[i, 1:6])}
    
  #}  
    
  #winners <- cbind(winners_num, winners_pot)
  
  #print(winners)
  #print(losers)
  
  print(prize_matrix)
  write.table(prize_matrix, "powerball_results.csv", col.names = TRUE)

}
  
r_u_lucky(pball_numbers, pball_winner, pball_prizes)

### Problem 2 ###

# Load csv of prizes and respective probabilities

pball_prob_file <- read.csv("pball_expectedreturns.csv", stringsAsFactors = FALSE, sep = ",", header = TRUE)
str(pball_prob_file)

# Function to calculate expected return and volatility of powerball given probabilities for each prize

pball_ERandVol <- function(pball_prob) { # input csv file
  
  pball_ER <- vector()
  pball_totER <- vector()
  pball_var <- vector()
  pball_totvar <- vector
  
  for (i in 1:nrow(pball_prob)) { # calculate expected return of each prize
    
    pball_ER[i] <- pball_prob$Probability[i] * as.numeric(gsub(",", "", pball_prob$Prize[i]))
    
  }
  
  pball_totER <- sum(pball_ER)
  
  for (i in 1:nrow(pball_prob)) { # calculate variance of each prize
    
    pball_var[i] <- ( as.numeric(gsub(",", "", pball_prob$Prize[i])) - pball_totER ) ^ 2
    
  } 

  pball_totvar <- sum(pball_var)
  pball_std <- sqrt(pball_totvar)
  
  probability_matrix <- cbind(pball_prob, pball_ER, pball_var)
  
  print(probability_matrix)
  print(pball_totER)
  print(pball_totvar)
  print(pball_std)
  
} 
   
pball_ERandVol(pball_prob_file)

### Problem 3 ###

loan_profile <- read.table("loanProfile.txt", header = TRUE, sep = "|", stringsAsFactors = FALSE, na.strings = "NA")
loan_results <- read.table("Results.dat", header = TRUE, sep = "|", stringsAsFactors = FALSE, na.strings = "NA")

columns_keep <- c("LOAN_ID", "CBD_CURRENT_FICO", "COMBINED_MTMLTV_RATE", "INITIAL_PRODUCT_CATEGORY", "BACKEND_RATIO_RATE", "NUMBER_OF_BORROWERS", "PROPERTY_TYPE_CATEGORY", "CPR", "VCPR", "CFR", "Losses", "StressLosses", "GFeebps", "Capital", "CreditROC", "ROCWeight", "UPB")

match(columns_keep, colnames(loan_profile)) # column locations in loan_profile
match(columns_keep, colnames(loan_results)) # column locations in loan_results

merge_loandata <- merge(loan_profile[c("LOAN_ID", "CBD_CURRENT_FICO", "COMBINED_MTMLTV_RATE", "INITIAL_PRODUCT_CATEGORY", "BACKEND_RATIO_RATE", "NUMBER_OF_BORROWERS", "PROPERTY_TYPE_CATEGORY")], loan_results[c("LOAN_ID", "CPR", "VCPR", "CFR", "Losses", "StressLosses", "GFeebps", "Capital", "CreditROC", "ROCWeight", "UPB")], by = c("LOAN_ID"))
str(merge_loandata)

### Problem 4 ###

# Load cash flow data

hpi <- read.table("1.hpi.txt", header = TRUE, sep = " ", stringsAsFactors = FALSE, na.strings = "NA")
colnames(hpi) = c("Path", "Month", "HPI")
str(hpi)

# Function to calculate average expected ans stressed cash flows by path

cashflow_calculator <- function(CF_file, expected) { # where expected is the first n paths that are expected
  
  colnames(CF_file) = c("Path", "Month", "HPI")
  
  # Divide data into expected and stressed cash flows
  hpi_expected <- CF_file[CF_file$Path <= expected, ]
  hpi_stressed <- CF_file[CF_file$Path > expected, ]
  
  # Aggregate cash flows and take average
  hpi_expected_aggmean <- aggregate(HPI ~ Month, hpi_expected, mean)
  hpi_stressed_aggmean <- aggregate(HPI ~ Month, hpi_stressed, mean)
  
  str(hpi_expected_aggmean)
  str(hpi_stressed_aggmean)
    
  # Write table
  write.table(hpi_expected_aggmean, "hpi_expected_aggmean", col.names = FALSE)
  write.table(hpi_stressed_aggmean, "hpi_stressed_aggmean", col.names = FALSE)
  
}

cashflow_calculator(hpi, 300)

### Problem 5 ###

# Load data

PUMA_org_chart <- read.csv("PUMA_org_chart.csv", sep = ",", header = FALSE, stringsAsFactors = FALSE)

staffer <- function(director, org_chart) {
  
  x <- match(director, org_chart[ ,1])
  staff <- org_chart[x, ]
  return (staff)
  
}

staffer("Leonard, Nicholas", PUMA_org_chart)

# This is probably not what you're looking for! Gave it a shot...
