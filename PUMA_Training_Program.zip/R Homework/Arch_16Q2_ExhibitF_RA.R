##############################################################
### PMIERS Required Assets Calculator, Not HARP-treated V5 ###
##############################################################

### Overview, Instructions, & Notes #####################################################################################
#                                                                                                                       #
# This program calculates the risk in force (RIF) and risk-based required asset amounts of private mortgage insurers    #
# conducting business with Fannie Mae in accordance with the December 21, 2015 draft of Exhibit A of the                #
# Private Mortgage Insurer Eligibility Requirements (PMIERS) framework.                                                 #                                   
#                                                                                                                       # 
# 1. Line xx: Change working directory to folder containing files of PMI being evaluated.                               #
# 2. Lines xx: Change file directory and file names of input .txt data to reflect name of PMI being evaluated.          # 
# 3. Line xx: Change variable 'mi_parent_entity' to name of PMI being evaluated.                                        #
# 4. Lines xx: Set djusted RIF and required assets for PMI's other assumed obligations.                                 #       
#                                                                                                                       # 
# NOTES:                                                                                                                # 
# 1. V4 and V5 differ in how the primary and pool flags are created. V5 flags are based on flag_coverage_type.          #
# to both performing and non-performing.                                                                                #
# 2. Beginning 16Q2, Table 5 risk multipliers will include LPMI multiplier.                                             #
#                                                                                                                       #
#########################################################################################################################

### Preliminaries #######################################################################################################

# Clear environment
rm(list=ls())

# Set working directory to PMI folder
setwd("/home/k2ujcb/PMIERS/Arch/16Q2")

# Start proc.time
ptime <- proc.time()

# Load dplyr
library(dplyr)

# Create custom infix operator for negation of %in%
'%notin%' <- Negate('%in%')

### Read in loan-level data, pool data, and reinsurance data ############################################################
loans <- read.table("/home/k2ujcb/PMIERS/Arch/16Q2/16Q2 Arch Exhibit F - Fannie - HARP.txt", sep = "|", 
                    stringsAsFactors = FALSE, header = TRUE, quote = "", comment.char = "", 
                    fill = TRUE, na.strings = c(".", " ", ""))
pool <- read.table("/home/k2ujcb/PMIERS/Arch/16Q2/16Q2 Arch Pool.txt", sep = "|", stringsAsFactors = FALSE, 
                   header = TRUE, quote = "", comment.char = "", fill = TRUE, na.strings = c(".", " ", ""))
rein <- read.table("/home/k2ujcb/PMIERS/Arch/16Q2/16Q2 Arch Reins.txt", sep = "|", stringsAsFactors = FALSE, 
                   header = TRUE, comment.char = "", fill = TRUE, na.strings = c(".", " ", ""))

### Variable names clean-up #############################################################################################

# Rename 'amt_ininpb' in pool data table to 'amt_ininpb_pool'
colnames(pool)[5] <- "amt_ininpb_pool"
colnames(pool)

# Rename "REIN_ID" in rein data table to "rein_id" to fix for R case-sensitivity
colnames(rein)[6] <- "rein_id"

# Eliminate variable mi_name in rein data to avoid redundancy post-merge
rein[1] <- NULL
colnames(rein)

### Implement pool merge then reinsurance merge; both are left outer joins i.e. all.x = TRUE ############################
ExhibitF_agg <- merge(x = loans, y = pool, by = "cd_pool_agrmt", all.x = TRUE)
ExhibitF_agg <- merge(x = ExhibitF_agg, y = rein, by = "rein_id", all.x = TRUE)
str(ExhibitF_agg)
colnames(ExhibitF_agg)

### Reset all HARP data and repopulate with MI's HARP paramter estimates ################################################
ExhibitF_agg$flag_harp <- "N"
ExhibitF_agg$HARP_orig_date <- NA
ExhibitF_agg$HARP_orig_LTV <- NA
ExhibitF_agg$HARP_orig_creditscore <- NA
ExhibitF_agg$HARP_orig_UPB <- NA

ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$flag_harp <- "Y"
ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$HARP_orig_date <- 
  ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$mi_HARP_orig_date
ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$HARP_orig_LTV <- 
  ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$mi_HARP_orig_LTV
ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$HARP_orig_creditscore <- 
  ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$mi_HARP_orig_creditscore
ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$HARP_orig_UPB <- 
  ExhibitF_agg[ExhibitF_agg$mi_flag_harp == "Y", ]$mi_HARP_orig_UPB

### Create variable mi_parent_entity and set parent entity ##############################################################
mi_parent_entity <- "Arch"
ExhibitF_agg$mi_parent_entity <- mi_parent_entity

### Date treatment: dt_orig in format YYYY-MM-DD, dt_report in format YYYY-MM ###########################################

# Dates read-in as integers, must convert to characters first to use as.Date function to coerce into date class
ExhibitF_agg$dt_orig <- as.Date(as.character(ExhibitF_agg$dt_orig), "%Y%m%d")
class(ExhibitF_agg$dt_orig)

# Roll date to first of the month before class conversion
ExhibitF_agg$dt_report <- paste(ExhibitF_agg$dt_report, "30", sep = "") # Make sure end of month day is consistent with that month e.g. 28th for February, 30th for June
ExhibitF_agg$dt_report <- as.Date(ExhibitF_agg$dt_report, "%Y%m%d")
class(ExhibitF_agg$dt_report)

### Vintage creation: assign PMIERS vintage based on dt_orig ############################################################

# Create new column 'vintage', temporarily fill with "0"
ExhibitF_agg$vintage <- "0"

# Set vintage based on dt_orig
ExhibitF_agg[ExhibitF_agg$flag_harp == "Y", ]$vintage <- "HARP"
ExhibitF_agg[ExhibitF_agg$flag_harp == "N" & 
               ExhibitF_agg$dt_orig <= "2004-12-31", ]$vintage <- "Pre-2005"
ExhibitF_agg[ExhibitF_agg$flag_harp == "N" &
               ExhibitF_agg$dt_orig > "2004-12-31" & 
               ExhibitF_agg$dt_orig <= "2008-12-31", ]$vintage <- "2005-2008"
ExhibitF_agg[ExhibitF_agg$flag_harp == "N" &
               ExhibitF_agg$dt_orig > "2008-12-31" & 
               ExhibitF_agg$dt_orig <= "2012-06-30", ]$vintage <- "2009-June 2012"
ExhibitF_agg[ExhibitF_agg$flag_harp == "N" &
               ExhibitF_agg$dt_orig > "2012-06-30", ]$vintage <- "Post June 2012"

# Check to see if all loans have been categorized for vintage; length should be 0
vintage_test <- length(ExhibitF_agg$vintage[ExhibitF_agg$vintage == "0"]) 
print(vintage_test)

### Create primary and pool coverage flags ##############################################################################

# Assign 0 where mi_assm_covg_pct and mi_prim_covg_pct is NA
ExhibitF_agg$mi_assm_covg_pct <- ifelse(is.na(ExhibitF_agg$mi_assm_covg_pct) == TRUE, 0, ExhibitF_agg$mi_assm_covg_pct)
ExhibitF_agg$mi_prim_covg_pct <- ifelse(is.na(ExhibitF_agg$mi_prim_covg_pct) == TRUE, 0, ExhibitF_agg$mi_prim_covg_pct)

# Create primary coverage flag
ExhibitF_agg$primary <- ifelse(ExhibitF_agg$flag_coverage_type %in% c("PMI", "BOTH", "Both"), 1, 0)
total_primary <- length(ExhibitF_agg$primary[ExhibitF_agg$primary == 1])
total_primary

# Create pool coverage flag
ExhibitF_agg$pool <- ifelse(ExhibitF_agg$flag_coverage_type %in% c("POOL", "BOTH", "Pool", "Both"), 1, 0)
total_pool <- length(ExhibitF_agg$pool[ExhibitF_agg$pool == 1])
total_pool

### Create loan performance indicator and new letter indicating non-performance to eliminate NAs ########################
ExhibitF_agg$perf_status <- ifelse(ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), "Performing", "Non-Performing")
ExhibitF_agg$delq_status <- ifelse(ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), "P", ExhibitF_agg$delq_status)

### Calculate Risk in Force (RIF) and adjusted RIF for non-pool loans ###################################################

# Create variable 'coverage', assign either primary or assumed coverage
ExhibitF_agg$coverage <- ifelse(ExhibitF_agg$mi_assm_covg_pct > 0, ExhibitF_agg$mi_assm_covg_pct / 100, 
                                ExhibitF_agg$mi_prim_covg_pct / 100) 

# Check to see if all loans have either primary or assumed coverage; length should be 0. NOTE: Coverage can be 0 owing to pool policies
coverage_test <- length(ExhibitF_agg$coverage[is.na(ExhibitF_agg$coverage) == TRUE]) 
coverage_test

# Set all coverage values that are not greater than or equal to 0 to 0.5; part 2 of validity check
ExhibitF_agg$coverage[is.na(ExhibitF_agg$coverage) == TRUE] <- 0.5 

# Create new column 'direct_RIF' and calculate sum
ExhibitF_agg$direct_RIF <- ExhibitF_agg$amt_cupb * ExhibitF_agg$coverage
total_direct_RIF <- sum(ExhibitF_agg$direct_RIF)
total_direct_RIF

# Convert 'pct_rein_qs' NAs to 0
ExhibitF_agg$pct_rein_qs[is.na(ExhibitF_agg$pct_rein_qs)] <- 0 

# Create new variable 'adj_RIF' and calculate sum; NOTE: for loans without reinsurance, adj_RIF will be equal to direct_RIF
ExhibitF_agg$adj_RIF <- ExhibitF_agg$direct_RIF * (1 - (ExhibitF_agg$pct_rein_qs / 100))
total_adj_RIF <- sum(ExhibitF_agg$adj_RIF)
total_adj_RIF

### Calculate Risk in Force (RIF) for pool loans pre-application of pool structure ######################################

# Convert 'mi_pool_covg_pct' NAs to 0 for non-pool loans
ExhibitF_agg[ExhibitF_agg$flag_coverage_type %notin% c("POOL", "BOTH", "Pool", "Both"), ]$mi_pool_covg_pct <- 0

# Create new variable 'pool_coverage', for all loans with pool policy, assign either the minimum of policy coverage and 50%
ExhibitF_agg$pool_coverage <- ifelse(ExhibitF_agg$flag_coverage_type %in% c("POOL", "BOTH", "Pool", "Both"), 
                                     pmin(ExhibitF_agg$mi_pool_covg_pct / 100, 0.5), 0)

# For pool policy-covered loans with mi_pool_covg_pct equal to 0 (i.e. previously NA), set pool_coverage to 50%
ExhibitF_agg$pool_coverage <- ifelse(ExhibitF_agg$flag_coverage_type %in% c("POOL", "BOTH", "Pool", "Both") & 
                                       ExhibitF_agg$mi_pool_covg_pct <= 0, 
                                     0.5, ExhibitF_agg$pool_coverage)

# Convert 'amt_ininpb' NAs to 0
ExhibitF_agg$amt_ininpb[is.na(ExhibitF_agg$amt_ininpb)] <- 0

# Calculate total initial insured principal balance
total_amt_ininpb <- sum(ExhibitF_agg$amt_ininpb)
total_amt_ininpb

# Create new variable 'pool_RIF' and calculate sum
ExhibitF_agg$pool_RIF <- ExhibitF_agg$amt_ininpb * ExhibitF_agg$pool_coverage
total_pool_RIF <- sum(ExhibitF_agg$pool_RIF)
total_pool_RIF

### Treat critical missing variables ####################################################################################

# Non-HARP original LTV
ExhibitF_agg$pct_oltv[is.na(ExhibitF_agg$pct_oltv) | ExhibitF_agg$pct_oltv <= 0] <- 106
pct_oltv_test <- length(ExhibitF_agg$pct_oltv[is.na(ExhibitF_agg$pct_oltv)])
pct_oltv_test

# Non-HARP representative credit score
ExhibitF_agg$representative_cs[is.na(ExhibitF_agg$representative_cs) | ExhibitF_agg$representative_cs <= 0] <- 0
representative_cs_test <- length(ExhibitF_agg$representative_cs[ExhibitF_agg$representative_cs < 0])
representative_cs_test

# HARP credit score
ExhibitF_agg[ExhibitF_agg$flag_harp == "Y" & 
               (is.na(ExhibitF_agg$HARP_orig_creditscore) | ExhibitF_agg$HARP_orig_creditscore <= 0), ]$HARP_orig_creditscore <- 0
HARP_orig_creditscore_test <- length(ExhibitF_agg$HARP_orig_creditscore[is.na(ExhibitF_agg$HARP_orig_creditscore)])
HARP_orig_creditscore_test

# HARP original LTV
ExhibitF_agg[ExhibitF_agg$flag_harp == "Y" & 
               (is.na(ExhibitF_agg$HARP_orig_LTV) | ExhibitF_agg$HARP_orig_LTV <= 0), ]$HARP_orig_LTV <- 106
ExhibitF_agg$HARP_orig_LTV[is.na(ExhibitF_agg$HARP_orig_LTV)] <- 0
HARP_orig_LTV_test <- length(ExhibitF_agg$HARP_orig_LTV[is.na(ExhibitF_agg$HARP_orig_LTV)])
HARP_orig_LTV_test

# Risk Multiples
ExhibitF_agg$cd_occup[ExhibitF_agg$cd_occup == "UN" | ExhibitF_agg$cd_occup == " "] <- "IN"
cd_occup_test <- length(ExhibitF_agg$cd_occup[ExhibitF_agg$cd_occup == "UN"])
cd_occup_test

ExhibitF_agg$pct_dti[is.na(ExhibitF_agg$pct_dti) | ExhibitF_agg$pct_dti <= 0] <- 51
pct_dti_test <- length(ExhibitF_agg$pct_dti[is.na(ExhibitF_agg$pct_dti) | ExhibitF_agg$pct_dti <= 0])
pct_dti_test

ExhibitF_agg$flag_amort[ExhibitF_agg$flag_amort == " "] <- "N"
flag_amort_test <- length(ExhibitF_agg$flag_amort[ExhibitF_agg$flag_amort == " "])
flag_amort_test

ExhibitF_agg$cd_purp[ExhibitF_agg$cd_purp == "UN" | ExhibitF_agg$cd_purp == " "] <- "CO"
cd_purp_test <- length(ExhibitF_agg$cd_purp[ExhibitF_agg$cd_purp == "UN" | ExhibitF_agg$cd_purp == " "])
cd_purp_test

# High FICOs; NOTE: Won't work if FICO NAs are set as 9999
ExhibitF_agg$representative_cs[ExhibitF_agg$representative_cs > 850] <- 850
high_representative_cs_test <- length(ExhibitF_agg$representative_cs[ExhibitF_agg$representative_cs > 850])
high_representative_cs_test

ExhibitF_agg$HARP_orig_creditscore[ExhibitF_agg$HARP_orig_creditscore > 850] <- 850
high_HARP_orig_creditscore_test <- length(ExhibitF_agg$HARP_orig_creditscore[ExhibitF_agg$HARP_orig_creditscore > 850])
high_representative_cs_test

### Calculate Table 1 required capital factors: vintage Pre-2005, performing, non-HARP ##################################

# Create variable 'cap', temporarily fill with 0
ExhibitF_agg$cap <- 0

# Table 1, 0 < pct_oltv <= 85
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.0409
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.0277
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0107
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 779, ]$cap <- 0.01
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 779 & 
               ExhibitF_agg$representative_cs <= 850, ]$cap <- 0.01

# Table 1, 85 < pct_oltv <= 90
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.048
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.0378
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.02
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 779, ]$cap <- 0.01
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 779 & 
               ExhibitF_agg$representative_cs <= 850, ]$cap <- 0.01

# Table 1, 90 < pct_oltv <= 95
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.0512
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.0366
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0229
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 779, ]$cap <- 0.0107
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 779 & 
               ExhibitF_agg$representative_cs <= 850, ]$cap <- 0.01

# Table 1, pct_oltv > 95
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.0798
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.0513
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0273
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 779, ]$cap <- 0.0147
ExhibitF_agg[ExhibitF_agg$vintage == "Pre-2005" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 779 & 
               ExhibitF_agg$representative_cs <= 850, ]$cap <- 0.01

### Calculate Table 2 required capital factors: vintage 2005-2008, performing, non-HARP #################################

# Table 2, pct_oltv <= 85
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.1142
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.0827
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0528
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 779, ]$cap <- 0.0283
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 779 & 
               ExhibitF_agg$representative_cs <= 850, ]$cap <- 0.0139

# Table 2, 85 < pct_oltv <= 90
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.1512
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.1073
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0674
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 779, ]$cap <- 0.0369
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 85 & 
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 779 & 
               ExhibitF_agg$representative_cs <= 850, ]$cap <- 0.0206

# Table 2, 90 < pct_oltv <= 95
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.1768
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.128
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0822
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 779, ]$cap <- 0.0482
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 90 & 
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 779 & 
               ExhibitF_agg$representative_cs <= 850, ]$cap <- 0.0289

# Table 2, pct_oltv > 95
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.2202
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.1704
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.1175
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 779, ]$cap <- 0.0727
ExhibitF_agg[ExhibitF_agg$vintage == "2005-2008" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 779 & 
               ExhibitF_agg$representative_cs <= 850, ]$cap <- 0.0435

### Calculate Table 3 required capital factors: vintage 2009-June 2012, performing, non-HARP ############################

# Table 3, pct_oltv <= 85
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.0961
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.0406
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 699, ]$cap <- 0.023
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 699 & 
               ExhibitF_agg$representative_cs <= 719, ]$cap <- 0.0186
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 719 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0124
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 759, ]$cap <- 0.01
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 759, ]$cap <- 0.01

# Table 3, 85 < pct_oltv <= 90
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 &
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.1286
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.0887
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 699, ]$cap <- 0.0602
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 699 & 
               ExhibitF_agg$representative_cs <= 719, ]$cap <- 0.0481
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 719 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0362
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 759, ]$cap <- 0.0276
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 759, ]$cap <- 0.016

# Table 3, 90 < pct_oltv <= 95
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 &
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.2008
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.1427
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 &
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 699, ]$cap <- 0.1015
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 699 & 
               ExhibitF_agg$representative_cs <= 719, ]$cap <- 0.0817
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 719 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0653
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 &
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 759, ]$cap <- 0.0498
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 &
               ExhibitF_agg$representative_cs > 759, ]$cap <- 0.0298

# Table 3, pct_oltv > 95
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 95 &
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.2208
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.157
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 95 &
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 699, ]$cap <- 0.1116
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 699 & 
               ExhibitF_agg$representative_cs <= 719, ]$cap <- 0.0899
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 719 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0718
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 95 &
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 759, ]$cap <- 0.0548
ExhibitF_agg[ExhibitF_agg$vintage == "2009-June 2012" & 
               ExhibitF_agg$pct_oltv > 95 &
               ExhibitF_agg$representative_cs > 759, ]$cap <- 0.0328

### Calculate Table 4 required capital factors: vintage Post June 2012, performing, non-HARP ############################

# Table 4, pct_oltv <= 85
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.1309
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.0917
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 699, ]$cap <- 0.0585
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 699 & 
               ExhibitF_agg$representative_cs <= 719, ]$cap <- 0.0466
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 719 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0361
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 759, ]$cap <- 0.0273
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv <= 85 & 
               ExhibitF_agg$representative_cs > 759, ]$cap <- 0.0158

# Table 4, 85 < pct_oltv <= 90
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 &
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.2122
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.1434
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 699, ]$cap <- 0.1004
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 699 & 
               ExhibitF_agg$representative_cs <= 719, ]$cap <- 0.0814
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 719 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0663
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 759, ]$cap <- 0.0507
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 85 &
               ExhibitF_agg$pct_oltv <= 90 & 
               ExhibitF_agg$representative_cs > 759, ]$cap <- 0.0307

# Table 4, 90 < pct_oltv <= 95
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 &
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.2643
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.1745
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 &
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 699, ]$cap <- 0.1296
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 699 & 
               ExhibitF_agg$representative_cs <= 719, ]$cap <- 0.105
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 & 
               ExhibitF_agg$representative_cs > 719 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0895
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 &
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 759, ]$cap <- 0.0691
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 90 &
               ExhibitF_agg$pct_oltv <= 95 &
               ExhibitF_agg$representative_cs > 759, ]$cap <- 0.0439

# Table 4, pct_oltv > 95
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 95 &
               ExhibitF_agg$representative_cs < 620, ]$cap <- 0.2907
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs >= 620 & 
               ExhibitF_agg$representative_cs <= 679, ]$cap <- 0.192
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 95 &
               ExhibitF_agg$representative_cs > 679 & 
               ExhibitF_agg$representative_cs <= 699, ]$cap <- 0.1425
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 699 & 
               ExhibitF_agg$representative_cs <= 719, ]$cap <- 0.1155
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 95 & 
               ExhibitF_agg$representative_cs > 719 & 
               ExhibitF_agg$representative_cs <= 739, ]$cap <- 0.0984
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 95 &
               ExhibitF_agg$representative_cs > 739 & 
               ExhibitF_agg$representative_cs <= 759, ]$cap <- 0.076
ExhibitF_agg[ExhibitF_agg$vintage == "Post June 2012" & 
               ExhibitF_agg$pct_oltv > 95 &
               ExhibitF_agg$representative_cs > 759, ]$cap <- 0.0483

### Calculate Table 7 HARP required capital factors: vintage HARP, performing ###########################################

# HARP, HARP_orig_LTV <= 85
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV <= 85 & 
               ExhibitF_agg$HARP_orig_creditscore < 620, ]$cap <- 0.0236
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV <= 85 & 
               ExhibitF_agg$HARP_orig_creditscore >= 620 & 
               ExhibitF_agg$HARP_orig_creditscore <= 679, ]$cap <- 0.0146
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV <= 85 & 
               ExhibitF_agg$HARP_orig_creditscore > 679 & 
               ExhibitF_agg$HARP_orig_creditscore <= 699, ]$cap <- 0.01
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV <= 85 & 
               ExhibitF_agg$HARP_orig_creditscore > 699 & 
               ExhibitF_agg$HARP_orig_creditscore <= 719, ]$cap <- 0.01
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV <= 85 & 
               ExhibitF_agg$HARP_orig_creditscore > 719 & 
               ExhibitF_agg$HARP_orig_creditscore <= 739, ]$cap <- 0.01
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV <= 85 & 
               ExhibitF_agg$HARP_orig_creditscore > 739 & 
               ExhibitF_agg$HARP_orig_creditscore <= 759, ]$cap <- 0.01
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV <= 85 & 
               ExhibitF_agg$HARP_orig_creditscore > 759, ]$cap <- 0.01

# HARP, 85 < HARP_orig_LTV <= 90
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 85 &
               ExhibitF_agg$HARP_orig_LTV <= 90 &
               ExhibitF_agg$HARP_orig_creditscore < 620, ]$cap <- 0.0511
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 85 &
               ExhibitF_agg$HARP_orig_LTV <= 90 & 
               ExhibitF_agg$HARP_orig_creditscore >= 620 & 
               ExhibitF_agg$HARP_orig_creditscore <= 679, ]$cap <- 0.028
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 85 &
               ExhibitF_agg$HARP_orig_LTV <= 90 & 
               ExhibitF_agg$HARP_orig_creditscore > 679 & 
               ExhibitF_agg$HARP_orig_creditscore <= 699, ]$cap <- 0.0168
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 85 &
               ExhibitF_agg$HARP_orig_LTV <= 90 & 
               ExhibitF_agg$HARP_orig_creditscore > 699 & 
               ExhibitF_agg$HARP_orig_creditscore <= 719, ]$cap <- 0.014
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 85 &
               ExhibitF_agg$HARP_orig_LTV <= 90 & 
               ExhibitF_agg$HARP_orig_creditscore > 719 & 
               ExhibitF_agg$HARP_orig_creditscore <= 739, ]$cap <- 0.0109
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 85 &
               ExhibitF_agg$HARP_orig_LTV <= 90 & 
               ExhibitF_agg$HARP_orig_creditscore > 739 & 
               ExhibitF_agg$HARP_orig_creditscore <= 759, ]$cap <- 0.01
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 85 &
               ExhibitF_agg$HARP_orig_LTV <= 90 & 
               ExhibitF_agg$HARP_orig_creditscore > 759, ]$cap <- 0.01

# HARP, 90 < HARP_orig_LTV <= 95
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 90 &
               ExhibitF_agg$HARP_orig_LTV <= 95 &
               ExhibitF_agg$HARP_orig_creditscore < 620, ]$cap <- 0.0716
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 90 &
               ExhibitF_agg$HARP_orig_LTV <= 95 & 
               ExhibitF_agg$HARP_orig_creditscore >= 620 & 
               ExhibitF_agg$HARP_orig_creditscore <= 679, ]$cap <- 0.041
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 90 &
               ExhibitF_agg$HARP_orig_LTV <= 95 &
               ExhibitF_agg$HARP_orig_creditscore > 679 & 
               ExhibitF_agg$HARP_orig_creditscore <= 699, ]$cap <- 0.0242
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 90 &
               ExhibitF_agg$HARP_orig_LTV <= 95 & 
               ExhibitF_agg$HARP_orig_creditscore > 699 & 
               ExhibitF_agg$HARP_orig_creditscore <= 719, ]$cap <- 0.0208
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 90 &
               ExhibitF_agg$HARP_orig_LTV <= 95 & 
               ExhibitF_agg$HARP_orig_creditscore > 719 & 
               ExhibitF_agg$HARP_orig_creditscore <= 739, ]$cap <- 0.0159
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 90 &
               ExhibitF_agg$HARP_orig_LTV <= 95 &
               ExhibitF_agg$HARP_orig_creditscore > 739 & 
               ExhibitF_agg$HARP_orig_creditscore <= 759, ]$cap <- 0.0111
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 90 &
               ExhibitF_agg$HARP_orig_LTV <= 95 &
               ExhibitF_agg$HARP_orig_creditscore > 759, ]$cap <- 0.01

# HARP, 95 < HARP_orig_LTV <= 100
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 95 &
               ExhibitF_agg$HARP_orig_LTV <= 100 &
               ExhibitF_agg$HARP_orig_creditscore < 620, ]$cap <- 0.0931
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 95 &
               ExhibitF_agg$HARP_orig_LTV <= 100 & 
               ExhibitF_agg$HARP_orig_creditscore >= 620 & 
               ExhibitF_agg$HARP_orig_creditscore <= 679, ]$cap <- 0.0535
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 95 &
               ExhibitF_agg$HARP_orig_LTV <= 100 &
               ExhibitF_agg$HARP_orig_creditscore > 679 & 
               ExhibitF_agg$HARP_orig_creditscore <= 699, ]$cap <- 0.0333
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 95 &
               ExhibitF_agg$HARP_orig_LTV <= 100 & 
               ExhibitF_agg$HARP_orig_creditscore > 699 & 
               ExhibitF_agg$HARP_orig_creditscore <= 719, ]$cap <- 0.0286
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 95 &
               ExhibitF_agg$HARP_orig_LTV <= 100 & 
               ExhibitF_agg$HARP_orig_creditscore > 719 & 
               ExhibitF_agg$HARP_orig_creditscore <= 739, ]$cap <- 0.0209
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 95 &
               ExhibitF_agg$HARP_orig_LTV <= 100 &
               ExhibitF_agg$HARP_orig_creditscore > 739 & 
               ExhibitF_agg$HARP_orig_creditscore <= 759, ]$cap <- 0.0148
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 95 &
               ExhibitF_agg$HARP_orig_LTV <= 100 &
               ExhibitF_agg$HARP_orig_creditscore > 759, ]$cap <- 0.01

# HARP, 100 < HARP_orig_LTV <= 105
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 100 &
               ExhibitF_agg$HARP_orig_LTV <= 105 &
               ExhibitF_agg$HARP_orig_creditscore < 620, ]$cap <- 0.0972
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 100 &
               ExhibitF_agg$HARP_orig_LTV <= 105 & 
               ExhibitF_agg$HARP_orig_creditscore >= 620 & 
               ExhibitF_agg$HARP_orig_creditscore <= 679, ]$cap <- 0.0544
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 100 &
               ExhibitF_agg$HARP_orig_LTV <= 105 &
               ExhibitF_agg$HARP_orig_creditscore > 679 & 
               ExhibitF_agg$HARP_orig_creditscore <= 699, ]$cap <- 0.0347
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 100 &
               ExhibitF_agg$HARP_orig_LTV <= 105 &
               ExhibitF_agg$HARP_orig_creditscore > 699 & 
               ExhibitF_agg$HARP_orig_creditscore <= 719, ]$cap <- 0.0279
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 100 &
               ExhibitF_agg$HARP_orig_LTV <= 105 & 
               ExhibitF_agg$HARP_orig_creditscore > 719 & 
               ExhibitF_agg$HARP_orig_creditscore <= 739, ]$cap <- 0.0221
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 100 &
               ExhibitF_agg$HARP_orig_LTV <= 105 &
               ExhibitF_agg$HARP_orig_creditscore > 739 & 
               ExhibitF_agg$HARP_orig_creditscore <= 759, ]$cap <- 0.0158
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 100 &
               ExhibitF_agg$HARP_orig_LTV <= 105 &
               ExhibitF_agg$HARP_orig_creditscore > 759, ]$cap <- 0.01

# HARP, HARP_orig_LTV > 105
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 105 &
               ExhibitF_agg$HARP_orig_creditscore < 620, ]$cap <- 0.1863
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 105 & 
               ExhibitF_agg$HARP_orig_creditscore >= 620 & 
               ExhibitF_agg$HARP_orig_creditscore <= 679, ]$cap <- 0.1161
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 105 &
               ExhibitF_agg$HARP_orig_creditscore > 679 & 
               ExhibitF_agg$HARP_orig_creditscore <= 699, ]$cap <- 0.0779
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 105 & 
               ExhibitF_agg$HARP_orig_creditscore > 699 & 
               ExhibitF_agg$HARP_orig_creditscore <= 719, ]$cap <- 0.0673
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 105 & 
               ExhibitF_agg$HARP_orig_creditscore > 719 & 
               ExhibitF_agg$HARP_orig_creditscore <= 739, ]$cap <- 0.0554
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 105 &
               ExhibitF_agg$HARP_orig_creditscore > 739 & 
               ExhibitF_agg$HARP_orig_creditscore <= 759, ]$cap <- 0.0435
ExhibitF_agg[ExhibitF_agg$vintage == "HARP" & 
               ExhibitF_agg$HARP_orig_LTV > 105 &
               ExhibitF_agg$HARP_orig_creditscore > 759, ]$cap <- 0.0263

### Calculate Table 5 factor multipliers: vintage Post-2008, performing, non-HARP #######################################

# Create variable 'mult', assign initial value 1 then apply multiplier based on risk characteristics
ExhibitF_agg$mult <- 1

# Convert variable 'cd_doctn' from boolean FALSE to character 'F'
ExhibitF_agg$cd_doctn <- ifelse(ExhibitF_agg$cd_doctn == FALSE, "F", ExhibitF_agg$cd_doctn)

# Not underwritten with full documentation
mult1 <- 3 * (ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$cd_doctn != "F") +
  1.0 * !(ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$cd_doctn != "F")
mult1_count <- length(mult1[mult1 == 3])
mult1_count

# Investment property at origination
mult2 <- 1.75 * (ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$cd_occup == "IN") +
  1.0 * !(ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$cd_occup == "IN")
mult2_count <- length(ExhibitF_agg[ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$cd_occup == "IN" & 
                                     ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), ]$cert_nbr)
mult2_count

# DTI ratio greater than 50%
mult3 <- 1.75 * (ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$pct_dti / 100 > 0.50) +
  1.0 * !(ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$pct_dti / 100 > 0.50)
mult3_count <- length(ExhibitF_agg[ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$pct_dti / 100 > 0.50 & 
                                     ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), ]$cert_nbr)
mult3_count

# Mortgage payment is not fully amortizing
mult4 <-  2.0 * (ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$flag_amort == "N") +
  1.0 * !(ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$flag_amort == "N")
mult4_count <- length(ExhibitF_agg[ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$flag_amort == "N" & 
                                     ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), ]$cert_nbr)
mult4_count

# Cash out refinance
mult5 <- 1.50 * (ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$cd_purp == "CO") +
  1.0 * !(ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$cd_purp == "CO")
mult5_count <- length(ExhibitF_agg[ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$cd_purp == "CO" & 
                                     ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), ]$cert_nbr)
mult5_count

# Original maturity term 20 years or less
mult6 <- 0.50 * (ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$nbr_term > 0 & ExhibitF_agg$nbr_term <= 240) +
  1.0 * !(ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$nbr_term > 0 & ExhibitF_agg$nbr_term <= 240)
mult6_count <- length(ExhibitF_agg[ExhibitF_agg$dt_orig >= "2009-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$nbr_term > 0 & ExhibitF_agg$nbr_term <= 240 & 
                                     ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), ]$cert_nbr)
mult6_count

# LPMI with OLTV greater than 90%
mult7 <- 1.10 * (ExhibitF_agg$dt_orig >= "2016-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$prm_type == "L" & ExhibitF_agg$flag_auto_cancel_78 %in% c(NA, "N") & ExhibitF_agg$pct_oltv > 90) +
  1.0 * !(ExhibitF_agg$dt_orig >= "2016-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$prm_type == "L" & ExhibitF_agg$flag_auto_cancel_78 %in% c(NA, "N") & ExhibitF_agg$pct_oltv > 90)
mult7_count <- length(ExhibitF_agg[ExhibitF_agg$dt_orig >= "2016-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$prm_type == "L" & ExhibitF_agg$flag_auto_cancel_78 %in% c(NA, "N") & ExhibitF_agg$pct_oltv > 90 & 
                                     ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), ]$cert_nbr)
mult7_count

# LPMI with OLTV less than or equal to 90%
mult8 <- 1.35 * (ExhibitF_agg$dt_orig >= "2016-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$prm_type == "L" & ExhibitF_agg$flag_auto_cancel_78 %in% c(NA, "N") & ExhibitF_agg$pct_oltv <= 90) +
  1.0 * !(ExhibitF_agg$dt_orig >= "2016-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$prm_type == "L" & ExhibitF_agg$flag_auto_cancel_78 %in% c(NA, "N") & ExhibitF_agg$pct_oltv <= 90)
mult8_count <- length(ExhibitF_agg[ExhibitF_agg$dt_orig >= "2016-01-01" & ExhibitF_agg$vintage != "HARP" & ExhibitF_agg$prm_type == "L" & ExhibitF_agg$flag_auto_cancel_78 %in% c(NA, "N") & ExhibitF_agg$pct_oltv <= 90 & 
                                     ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), ]$cert_nbr)
mult8_count

# Implement horizontal multiplication of risk factor multipliers and assign final product to variable 'mult'
ExhibitF_agg$mult <- ExhibitF_agg$mult * mult1 * mult2 * mult3 * mult4 * mult5 * mult6 * mult7 * mult8
max(ExhibitF_agg$mult)
min(ExhibitF_agg$mult)
hist(ExhibitF_agg$mult)

# Create multiplier loan count summary table
mult_sumview <- data.frame(risk_feature = c("Not underwritten with full documentation", "Investment property at origination", "DTI ratio greater than 50%",
                                            "Mortgage payment is not fully amortizing", "Cash out refinance", "Original maturity term 20 years or less", 
                                            "LPMI with Original LTV greater than 90%", "LPMI with Original LTV less than or equal to 90%"),
                           record_count = c(mult1_count, mult2_count, mult3_count, mult4_count, mult5_count, mult6_count, mult7_count, mult8_count))
names(mult_sumview) <- c("Risk Feature", "Record Count")

mult_sumview

# Output multiplier loan count summary table
write.csv(mult_sumview, "ExhibitF_mult_sumview.csv")

### Calculate Table 6 seasoning weights: vintage Post June 2012, performing, non-HARP ###################################

# Calculate new variable 'loan_age' as the difference in months between origination date and report date
#ExhibitF_agg$loan_age <- round((ExhibitF_agg$dt_report - ExhibitF_agg$dt_orig) / (365.25/12))
d1 <- as.POSIXlt(ExhibitF_agg$dt_orig)
d2 <- as.POSIXlt(ExhibitF_agg$dt_report)
ExhibitF_agg$loan_age <- 12 * (d2$year - d1$year) + (d2$mon - d1$mon)

# Add 1 to give credit for the reporting month (reporting month is set at 1st of the month)
ExhibitF_agg$loan_age <- ExhibitF_agg$loan_age + 1

# Subtract 1 month from loan_age for loans where dt_orig is set to the middle of a month (gives age credit to loans originating mid-month); create a vector of -1 and 0
#dt_orig_day <- ifelse(as.numeric(format(ExhibitF_agg$dt_orig, "%d")) != 1, -1, 0)
dt_orig_day <- ifelse(as.numeric(format(d1, "%d")) != 1, -1, 0)
ExhibitF_agg$loan_age <- ExhibitF_agg$loan_age + dt_orig_day

# Create new variable 'seas_weight', set to 1
ExhibitF_agg$seas_weight <- 1

# Apply seasoning weights for loans vintage Post June 2012 based on loan age
# Loan age less than 25 months
seas_weight1 <- ifelse((ExhibitF_agg$vintage == "Post June 2012" & ExhibitF_agg$loan_age < 25) == TRUE, 
                       ExhibitF_agg$seas_weight * 1.0, ExhibitF_agg$seas_weight * 1.0) 
seas_weight1_count <- length(seas_weight1[seas_weight1 == 1.0])
seas_weight1_count

# Loan age more than 25 months through 36 months
seas_weight2 <- ifelse((ExhibitF_agg$vintage == "Post June 2012" & ExhibitF_agg$loan_age >= 25 & ExhibitF_agg$loan_age <= 36) == TRUE,
                       ExhibitF_agg$seas_weight * 0.88, ExhibitF_agg$seas_weight * 1.0)
seas_weight2_count <- length(seas_weight2[seas_weight2 == 0.88])
seas_weight2_count

# Loan age more than 36 months through 48 months
seas_weight3 <- ifelse((ExhibitF_agg$vintage == "Post June 2012" & ExhibitF_agg$loan_age > 36 & ExhibitF_agg$loan_age <= 48) == TRUE,
                       ExhibitF_agg$seas_weight * 0.81, ExhibitF_agg$seas_weight * 1.0)
seas_weight3_count <- length(seas_weight3[seas_weight3 == 0.81])
seas_weight3_count

# Loan age more than 48 months through 60 months
seas_weight4 <- ifelse((ExhibitF_agg$vintage == "Post June 2012" & ExhibitF_agg$loan_age > 48 & ExhibitF_agg$loan_age <= 60) == TRUE,
                       ExhibitF_agg$seas_weight * 0.78, ExhibitF_agg$seas_weight * 1.0)
seas_weight4_count <- length(seas_weight4[seas_weight4 == 0.78])
seas_weight4_count

# Loan age more than 60 months
seas_weight5 <- ifelse((ExhibitF_agg$vintage == "Post June 2012" & ExhibitF_agg$loan_age > 60) == TRUE,
                       ExhibitF_agg$seas_weight * 0.73, ExhibitF_agg$seas_weight * 1.0)
seas_weight5_count <- length(seas_weight5[seas_weight5 == 0.73])
seas_weight5_count

# Multiply variable seas_weight to each seas_weight vector
ExhibitF_agg$seas_weight <- ExhibitF_agg$seas_weight * seas_weight1 * seas_weight2 * seas_weight3 * seas_weight4 * seas_weight5
max(ExhibitF_agg$seas_weight)
min(ExhibitF_agg$seas_weight)
hist(ExhibitF_agg$seas_weight)

# Create seasoning weight loan count summary table
season_sumview <- data.frame(loan_age = c("25 through 36 months",	"More than 36 months through 48 months",	"More than 48 months through 60 months",
                                          "More than 60 months"),
                             record_count = c(seas_weight2_count, seas_weight3_count, seas_weight4_count, seas_weight5_count))
names(season_sumview) <- c("Loan Age", "Record Count")

season_sumview

# Output multiplier loan count summary table
write.csv(season_sumview, "ExhibitF_season_sumview.csv")

### Calculate Table 8 non-performing loans required capital factors: all vintages, non-performing #######################

# Reset capital factors for all non-performing loans
ExhibitF_agg$cap <- ifelse(ExhibitF_agg$delq_status %in% c("A", "B", "C", "D", "E"), 0, ExhibitF_agg$cap)

# Reset seasoning weights and risk factor multipliers to 1 for all non-performing loans
ExhibitF_agg[ExhibitF_agg$delq_status %in% c("A", "B", "C", "D", "E"), ]$seas_weight <- 1
ExhibitF_agg[ExhibitF_agg$delq_status %in% c("A", "B", "C", "D", "E"), ]$mult <- 1

# Set required capital values based on delinquency status
# 2-3 missed monthly payments, delq_status == "A"
ExhibitF_agg[ExhibitF_agg$delq_status == "A", ]$cap <- 0.55

# 4-5 missed monthly payments, delq_status == "B"
ExhibitF_agg[ExhibitF_agg$delq_status == "B", ]$cap <- 0.69

# 6-11 missed monthly payments, delq_status == "C"
ExhibitF_agg[ExhibitF_agg$delq_status == "C", ]$cap <- 0.78

# 12 or more missed monthly payments, delq_status == "D"
ExhibitF_agg[ExhibitF_agg$delq_status == "D", ]$cap <- 0.85

# Pending claims, delq_status == "D"
ExhibitF_agg[ExhibitF_agg$delq_status == "E", ]$cap <- 1.06

### Calculate required assets ###########################################################################################

# Create new variable 'ra_amt_factor', temporarily fill with 0
ExhibitF_agg$ra_amt_factor <- 0

# Determine ra_amt_factor based on delq_status of loans
ExhibitF_agg$ra_amt_factor <- ifelse(ExhibitF_agg$delq_status %notin% c("A", "B", "C", "D", "E"), 
                                     pmin(ExhibitF_agg$cap * ExhibitF_agg$mult * ExhibitF_agg$seas_weight, 1.00),
                                     ExhibitF_agg$cap)

# Create new variable 'ra_amt'
ExhibitF_agg$ra_amt <- ExhibitF_agg$ra_amt_factor * ExhibitF_agg$adj_RIF
total_ra_amt <- sum(ExhibitF_agg$ra_amt)
total_ra_amt

# Calculate top-level required asset amount factor
ra_amt_factor <- total_ra_amt / total_adj_RIF
ra_amt_factor

# Create new variable 'ra_amt_pool'
ExhibitF_agg$ra_amt_pool <- ifelse(ExhibitF_agg$flag_coverage_type %in% c("POOL", "BOTH", "Pool", "Both"), 
                                   ExhibitF_agg$ra_amt_factor * ExhibitF_agg$pool_RIF, 0)
total_ra_amt_pool <- sum(ExhibitF_agg$ra_amt_pool)
total_ra_amt_pool

# Calculate implied required asset amount risk factor pre-pool structure application
ra_amt_factor_pool <- total_ra_amt_pool / total_pool_RIF
ra_amt_factor_pool * 100

### Create primary insurance summary view tables (non-pool) #############################################################

# Subset data for loans with primary insurance only
ExhibitF_agg_primary <- ExhibitF_agg[ExhibitF_agg$primary == 1, ]

# Create primary summary view 'overall' table
primary_sumview_overall_col_names <- c("Private Mortgage Insurer", "Record Count", "Current Loan Balance", "Direct RIF",
                                       "Adjusted RIF", "Required Asset Amount", "Required Asset Amount Factor")
primary_sumview_overall <- data.frame(mi_parent_entity, total_primary, sum(as.numeric(ExhibitF_agg_primary$amt_cupb)), total_direct_RIF,
                                      total_adj_RIF, total_ra_amt, ra_amt_factor)
names(primary_sumview_overall) <- primary_sumview_overall_col_names

primary_sumview_overall

# Create primary summary view 'by vintage' table
primary_sumview_vintage_col_names <- c("Private Mortgage Insurer", "Vintage", "Record Count", "Current Loan Balance", "Direct RIF",
                                       "Adjusted RIF", "Required Asset Amount", "Required Asset Amount Factor")
primary_sumview_vintage <- ExhibitF_agg_primary %>%
  group_by(mi_parent_entity, vintage) %>%
  summarize(current_loan_balance = sum(as.numeric(amt_cupb)), direct_RIF = sum(as.numeric(direct_RIF)), adjusted_RIF = sum(as.numeric(adj_RIF)),
            required_asset_amount = sum(as.numeric(ra_amt)), required_asset_amount_factor = sum(as.numeric(ra_amt)) / sum(as.numeric(adj_RIF)))
primary_sumview_vintage_count <- ExhibitF_agg_primary %>%
  count(mi_parent_entity, vintage)
primary_sumview_vintage <- merge(x = primary_sumview_vintage_count, y = primary_sumview_vintage, by = c("mi_parent_entity", "vintage"), all = TRUE)

primary_sumview_vintage <- primary_sumview_vintage[c("mi_parent_entity", "vintage", "n", "current_loan_balance", "direct_RIF", 
                                                     "adjusted_RIF", "required_asset_amount", "required_asset_amount_factor")]
names(primary_sumview_vintage) <- primary_sumview_vintage_col_names

# Order primary summary view 'by vintage' table
primary_sumview_vintage <- primary_sumview_vintage[c(5, 1, 2, 4, 3), ]

primary_sumview_vintage

# Create primary summary view 'by loan performance' table
primary_sumview_performance_col_names <- c("Private Mortgage Insurer", "Performing Status", "Record Count", "Current Loan Balance", "Direct RIF",
                                           "Adjusted RIF", "Required Asset Amount", "Required Asset Amount Factor")
primary_sumview_performance <- ExhibitF_agg_primary %>%
  group_by(mi_parent_entity, perf_status) %>%
  summarize(current_loan_balance = sum(as.numeric(amt_cupb)), direct_RIF = sum(as.numeric(direct_RIF)), adjusted_RIF = sum(as.numeric(adj_RIF)),
            required_asset_amount = sum(as.numeric(ra_amt)), required_asset_amount_factor = sum(as.numeric(ra_amt)) / sum(as.numeric(adj_RIF)))
primary_sumview_performance_count <- ExhibitF_agg_primary %>%
  count(mi_parent_entity, perf_status)
primary_sumview_performance <- merge(x = primary_sumview_performance_count, y = primary_sumview_performance, by = c("mi_parent_entity", "perf_status"), all = TRUE)
primary_sumview_performance <- primary_sumview_performance[c("mi_parent_entity", "perf_status", "n", "current_loan_balance", "direct_RIF", 
                                                             "adjusted_RIF", "required_asset_amount", "required_asset_amount_factor")]
names(primary_sumview_performance) <- primary_sumview_performance_col_names

primary_sumview_performance

# Create primary summary view 'by vintage and loan performance' table
primary_sumview_performance_vintage_col_names <- c("Private Mortgage Insurer", "Performing Status", "Vintage", "Record Count", "Current Loan Balance", "Direct RIF",
                                                   "Adjusted RIF", "Required Asset Amount", "Required Asset Amount Factor")
primary_sumview_performance_vintage <- ExhibitF_agg_primary %>%
  group_by(mi_parent_entity, perf_status, vintage) %>%
  summarize(current_loan_balance = sum(as.numeric(amt_cupb)), direct_RIF = sum(as.numeric(direct_RIF)), adjusted_RIF = sum(as.numeric(adj_RIF)),
            required_asset_amount = sum(as.numeric(ra_amt)), required_asset_amount_factor = sum(as.numeric(ra_amt)) / sum(as.numeric(adj_RIF)))
primary_sumview_performance_vintage_count <- ExhibitF_agg_primary %>%
  count(mi_parent_entity, perf_status, vintage)
primary_sumview_performance_vintage <- merge(x = primary_sumview_performance_vintage_count, y = primary_sumview_performance_vintage, by = c("mi_parent_entity", "perf_status", "vintage"), all = TRUE)
primary_sumview_performance_vintage <- primary_sumview_performance_vintage[c("mi_parent_entity", "perf_status", "vintage", "n", "current_loan_balance", "direct_RIF", 
                                                                             "adjusted_RIF", "required_asset_amount", "required_asset_amount_factor")]
names(primary_sumview_performance_vintage) <- primary_sumview_performance_vintage_col_names

# Order primary summary view 'by vintage and loan performance' table
primary_sumview_performance_vintage <- primary_sumview_performance_vintage[c(5, 1, 2, 4, 3, 10, 6, 7, 9, 8), ]

primary_sumview_performance_vintage

# Bind all primary sumview tables
primary_sumview <- bind_rows(primary_sumview_overall, primary_sumview_vintage, primary_sumview_performance, primary_sumview_performance_vintage)
primary_sumview <- primary_sumview[c("Private Mortgage Insurer", "Performing Status", "Vintage", "Record Count", "Current Loan Balance", "Direct RIF",
                                     "Adjusted RIF", "Required Asset Amount", "Required Asset Amount Factor")]

# Output primary insurance summary view tables to csv
write.csv(primary_sumview, "ExhibitF_primary_sumview.csv")

### Calculate pool required assets after applying pool structure i.e. net of deductibles and stop loss ##################

# Create pool-only data.frame
pool_vars <- c("mi_parent_entity", "cd_pool_agrmt","amt_oupb", "amt_ininpb", "pool_RIF", "ra_amt_pool", 
               "ra_amt_factor", "amt_pool_deductible_remain", "amt_net_sl", "amt_ininpb_pool")
pool <- ExhibitF_agg[ExhibitF_agg$pool == 1, ][pool_vars]

# Set pool loans with amt_net_sl equal to NA to -1
pool[is.na(pool$amt_net_sl), ]$amt_net_sl <- -1

# Tabulate relevant pool data using dplyr summarize function: produces aggregated sums and means by cd_pool_agrmt and mi_parent_entity
ExhibitF_pool_summary <- pool %>%
  group_by(cd_pool_agrmt, mi_parent_entity) %>%
  summarize(amt_oupb = sum(as.numeric(amt_oupb)), amt_ininpb = sum(as.numeric(amt_ininpb)),
            pool_RIF = sum(as.numeric(pool_RIF)), ra_amt_pool = sum(as.numeric(ra_amt_pool)),
            amt_pool_deductible_remain = mean(amt_pool_deductible_remain),
            amt_net_sl = mean(amt_net_sl), amt_ininpb_pool = mean(amt_ininpb_pool))
ra_amt_factor_pool_wmean <- pool %>%
  group_by(cd_pool_agrmt, mi_parent_entity) %>%
  summarize(ra_amt_factor = weighted.mean(ra_amt_factor, pool_RIF))

# Merge summary and weighted means tables by cd_pool_agrmt and mi_parent_entity
ExhibitF_agg_pool <- merge(x = ExhibitF_pool_summary, y = ra_amt_factor_pool_wmean, by = c("cd_pool_agrmt", "mi_parent_entity"), all = TRUE)

# Apply pool structure; create new variable 'ra_net_deductible': required assets minus deductible, preventing negative values
ExhibitF_agg_pool$ra_net_deductible <- pmax(ExhibitF_agg_pool$ra_amt_pool + -1 * ExhibitF_agg_pool$amt_pool_deductible_remain, 0)

# Create new variable 'ra_net_ddtbl_stoploss': required assets lesser of RA net of deductible and net remaining stop loss
ExhibitF_agg_pool$ra_net_ddtbl_stoploss <- ifelse(ExhibitF_agg_pool$amt_net_sl < 0, ExhibitF_agg_pool$ra_net_deductible, 
                                                  pmin(ExhibitF_agg_pool$ra_net_deductible, ExhibitF_agg_pool$amt_net_sl))

ExhibitF_agg_pool

# Calculate key pool structure aggregate variables
total_amt_pool_deductible_remain <- sum(ExhibitF_agg_pool$amt_pool_deductible_remain)
total_amt_net_sl <- sum(ExhibitF_agg_pool$amt_net_sl)
total_ra_net_deductible <- sum(ExhibitF_agg_pool$ra_net_deductible)
total_ra_net_ddtbl_stoploss <- sum(ExhibitF_agg_pool$ra_net_ddtbl_stoploss)
ra_amt_factor_pool_str <- total_ra_net_ddtbl_stoploss / total_pool_RIF

# Create pool summary view table
pool_sumview_col_names <- c("MI Name", "Pool Policy Count", "Loan Count", "Loan Level Initial Insured Principal Balance Amount",
                            "Pool RIF", "Required Asset Amount (Pre-Str)", "Required Asset Amount Factor (Pre Str)", "Remaining Pool Deductible", "Net Remaining Stop Loss",
                            "Required Asset Amount Net of Deductible", "Required Asset Amount Net of Deductible and Stop Loss",
                            "Required Asset Amount Factor (Post-Str)")
ExhibitF_agg_pool_sumview <- data.frame(mi_parent_entity, length(ExhibitF_agg_pool$cd_pool_agrmt), total_pool, 
                                        total_amt_ininpb, total_pool_RIF, total_ra_amt_pool, ra_amt_factor_pool, total_amt_pool_deductible_remain, 
                                        total_amt_net_sl, total_ra_net_deductible, total_ra_net_ddtbl_stoploss, ra_amt_factor_pool_str)
names(ExhibitF_agg_pool_sumview) <- pool_sumview_col_names

ExhibitF_agg_pool_sumview

# Output pool summary view table to csv
write.csv(ExhibitF_agg_pool_sumview, "ExhibitF_agg_pool_sumview.csv")

### Calculate reinsurance xol required assets ###########################################################################

# Tabulate relevant reinsurance xol data using dplyr summarize function: produces aggregated sums and means by rein_id and mi_parent_entity
rein_xol_vars <- c("mi_parent_entity", "rein_id","perf_status", "vintage", "amt_cupb", "direct_RIF", "adj_RIF", "ra_amt", 
                   "ra_amt_factor", "rein_remaining_deductible", "rein_remaining_stoploss")
rein_xol <- ExhibitF_agg[ExhibitF_agg$rein_type == "X" & is.na(ExhibitF_agg$rein_id) == FALSE, ][rein_xol_vars]
ExhibitF_rein_xol_summary <- rein_xol %>%
  group_by(rein_id, mi_parent_entity) %>%
  summarize(amt_cupb = sum(as.numeric(amt_cupb)), direct_RIF = sum(as.numeric(direct_RIF)),
            adj_RIF = sum(as.numeric(adj_RIF)), ra_amt = sum(as.numeric(ra_amt)), # Note: adj_RIF in this table should be equal to direct_RIF becuase XOL structure has not yet been applied
            rein_remaining_deductible = mean(rein_remaining_deductible),
            rein_remaining_stoploss = mean(rein_remaining_stoploss))
rein_xol_loan_count <- rein_xol %>%
  count(rein_id, mi_parent_entity)
ra_amt_factor_rein_xol_wmean <- rein_xol %>%
  group_by(rein_id, mi_parent_entity) %>%
  summarize(ra_amt_factor = weighted.mean(ra_amt_factor, adj_RIF))

# Merge summary, count, and weighted means tables by rein_ID and mi_parent_entity
ExhibitF_agg_rein_xol <- merge(x = ExhibitF_rein_xol_summary, y = ra_amt_factor_rein_xol_wmean, by = c("rein_id", "mi_parent_entity"), all = TRUE)
ExhibitF_agg_rein_xol <- merge(x = ExhibitF_agg_rein_xol, y = rein_xol_loan_count, by = c("rein_id", "mi_parent_entity"), all = TRUE )

# Create new variable 'eligible_coverage': required assets minus deductible, preventing negative values
ExhibitF_agg_rein_xol$eligible_coverage <- pmax(ExhibitF_agg_rein_xol$ra_amt + -1 * ExhibitF_agg_rein_xol$rein_remaining_deductible, 0)

# Create new variable 'net_rein_rem_stoploss': reinsurer remaining stop loss net of deductible
ExhibitF_agg_rein_xol$net_rein_rem_stoploss <- ExhibitF_agg_rein_xol$rein_remaining_stoploss + 
  -1 * ExhibitF_agg_rein_xol$rein_remaining_deductible

# Calculate xol required assets, new variable 'ra_amt_xol': required assets minus minimum of reinsurer stoploss and eligible coverage
ExhibitF_agg_rein_xol$ra_amt_xol <- ExhibitF_agg_rein_xol$ra_amt + 
  -1 * pmin(pmax(ExhibitF_agg_rein_xol$net_rein_rem_stoploss, 0), ExhibitF_agg_rein_xol$eligible_coverage)

# Calculate implied adjusted RIF post xol
ExhibitF_agg_rein_xol$adj_RIF_xol <- ExhibitF_agg_rein_xol$ra_amt_xol / ExhibitF_agg_rein_xol$ra_amt_factor

# Calculate implied required assets factor post xol
ExhibitF_agg_rein_xol$xol_benefit_factor <- ExhibitF_agg_rein_xol$adj_RIF_xol / ExhibitF_agg_rein_xol$direct_RIF

ExhibitF_agg_rein_xol

# Calculate key xol aggregate variables
total_direct_RIF_rein_prexol <- sum(ExhibitF_agg_rein_xol$direct_RIF)
total_ra_amt_rein_prexol <- sum(ExhibitF_agg_rein_xol$ra_amt)
ra_amt_factor_rein_prexol <- total_ra_amt_rein_prexol / total_direct_RIF_rein_prexol
total_rein_remaining_stoploss <- sum(ExhibitF_agg_rein_xol$rein_remaining_stoploss)
total_rein_remaining_deductible <- sum(ExhibitF_agg_rein_xol$rein_remaining_deductible)
total_net_rein_rem_stoploss <- sum(ExhibitF_agg_rein_xol$net_rein_rem_stoploss)
total_eligible_coverage <- sum(ExhibitF_agg_rein_xol$eligible_coverage)
total_ra_amt_rein_xol <- sum(ExhibitF_agg_rein_xol$ra_amt_xol)
total_adj_RIF_rein_xol <- sum(ExhibitF_agg_rein_xol$adj_RIF_xol)

# Create rein xol summary view Table 1 (tabulation by rein_id)
rein_xol_sumview_T1_vars <- c("rein_id", "n", "direct_RIF", "ra_amt", "ra_amt_factor", "rein_remaining_stoploss",
                              "rein_remaining_deductible", "net_rein_rem_stoploss", "eligible_coverage",
                              "adj_RIF_xol", "ra_amt_xol")
rein_xol_sumview_T1_col_names <- c("Deal Name", "Count of Loans Covered", "Direct RIF (Pre XOL)", "Required Asset Amount (Pre XOL)",
                                   "Required Asset Amount Factor (Pre XOL)", "Remaining Stoploss (Includes Deductible)", "Remaining Deductible",
                                   "Net Remaining Stoploss", "Eligible Coverage", "Adjusted RIF (Post XOL)", "Required Asset Amount (Post XOL)")
ExhibitF_agg_rein_xol_sumview_T1 <- ExhibitF_agg_rein_xol[rein_xol_sumview_T1_vars]
names(ExhibitF_agg_rein_xol_sumview_T1) <- rein_xol_sumview_T1_col_names

ExhibitF_agg_rein_xol_sumview_T1

# Re-tabulate and re-merge to create rein xol summary view Table 3 (tabulation by rein_id, perf_status, and vintage)
rein_xol_sumview_T3_vars <- c("rein_id", "perf_status", "vintage", "n", "direct_RIF", "ra_amt", "ra_amt_factor")
ExhibitF_rein_xol_summary_T3 <- rein_xol %>%
  group_by(rein_id, perf_status, vintage) %>%
  summarize(direct_RIF = sum(as.numeric(direct_RIF)), ra_amt = sum(as.numeric(ra_amt)))
rein_xol_loan_count_T3 <- rein_xol %>%
  count(rein_id, perf_status, vintage)
ra_amt_factor_rein_xol_wmean_T3 <- rein_xol %>%
  group_by(rein_id, perf_status, vintage) %>%
  summarize(ra_amt_factor = weighted.mean(ra_amt_factor, adj_RIF))
ExhibitF_agg_rein_xol_sumview_T3 <- merge(x = ExhibitF_rein_xol_summary_T3, y = rein_xol_loan_count_T3, by = c("rein_id", "perf_status", "vintage"), all = TRUE)
ExhibitF_agg_rein_xol_sumview_T3 <- merge(x = ExhibitF_agg_rein_xol_sumview_T3, y = ra_amt_factor_rein_xol_wmean_T3, by = c("rein_id", "perf_status", "vintage"), all = TRUE)
ExhibitF_agg_rein_xol_sumview_T3 <- ExhibitF_agg_rein_xol_sumview_T3[rein_xol_sumview_T3_vars]

ExhibitF_agg_rein_xol_sumview_T3

# Implement XOL benefit allocation at the deal level (to both performing and non-performing loans); will be appended to rein xol summary view Table 3
rein_xol_benefit_allocation_T3 <- merge(x = rein_xol %>% group_by(rein_id, perf_status, vintage) %>% 
                                          summarize(direct_RIF = sum(as.numeric(direct_RIF)), ra_amt = sum(as.numeric(ra_amt))), 
                                        y = ExhibitF_agg_rein_xol %>% group_by(rein_id) %>% 
                                          summarize(adj_RIF_xol_deal_level = adj_RIF_xol, ra_amt_xol_deal_level = ra_amt_xol), 
                                        by = "rein_id", all = TRUE)
rein_xol_benefit_allocation_T3 <- merge(x = rein_xol_benefit_allocation_T3,
                                        y = rein_xol %>% group_by(rein_id, perf_status) %>% 
                                          summarize(direct_RIF_deal_perf_level = sum(as.numeric(direct_RIF)), ra_amt_deal_perf_level = sum(as.numeric(ra_amt))),
                                        by = c("rein_id", "perf_status"), all = TRUE)
rein_xol_benefit_allocation_T3 <- merge(x = rein_xol_benefit_allocation_T3, 
                                        y = rein_xol %>% group_by(rein_id) %>% 
                                          summarize(direct_RIF_deal_level = sum(as.numeric(direct_RIF)), ra_amt_deal_level = sum(as.numeric(ra_amt))),
                                        by = "rein_id", all = TRUE)
rein_xol_benefit_allocation_T3$RIF_adj_factor <- rein_xol_benefit_allocation_T3$adj_RIF_xol_deal_level / rein_xol_benefit_allocation_T3$direct_RIF_deal_level
rein_xol_benefit_allocation_T3$ra_amt_adj_factor <- rein_xol_benefit_allocation_T3$ra_amt_xol_deal_level / rein_xol_benefit_allocation_T3$ra_amt_deal_level 
rein_xol_benefit_allocation_T3$adj_RIF_xol_recal <- rein_xol_benefit_allocation_T3$direct_RIF * rein_xol_benefit_allocation_T3$RIF_adj_factor
rein_xol_benefit_allocation_T3$ra_amt_xol_recal <- rein_xol_benefit_allocation_T3$ra_amt * rein_xol_benefit_allocation_T3$ra_amt_adj_factor
rein_xol_benefit_allocation_T3 <- rein_xol_benefit_allocation_T3[c("rein_id", "perf_status", "vintage", "RIF_adj_factor", "ra_amt_adj_factor", 
                                                                   "adj_RIF_xol_recal", "ra_amt_xol_recal")]
rein_xol_benefit_allocation_T3

# Merge rein xol summary view Table 3 and XOL benefit reallocation table
rein_xol_sumview_T3_col_names <- c("Deal Name", "Performing Status", "Vintage", "Count of Loans Covered", "Direct RIF (Pre XOL)", 
                                   "Required Asset Amount (Pre XOL)", "Required Asset Amount Factor (Pre XOL)", "RIF Adjustment Factor", 
                                   "RA Adjustment Factor", "Adjusted RIF (Post XOL, Performing Only)", "Required Asset Amount (Post XOL, Performing Only)")
ExhibitF_agg_rein_xol_sumview_T3 <- merge(x = ExhibitF_agg_rein_xol_sumview_T3, y = rein_xol_benefit_allocation_T3, by = c("rein_id", "perf_status", "vintage"), all = TRUE)
names(ExhibitF_agg_rein_xol_sumview_T3) <- rein_xol_sumview_T3_col_names

ExhibitF_agg_rein_xol_sumview_T3

# Output rein xol sumview tables to csv
write.csv(ExhibitF_agg_rein_xol_sumview_T1, "ExhibitF_agg_rein_xol_sumview_T1.csv")
write.csv(ExhibitF_agg_rein_xol_sumview_T3, "ExhibitF_agg_rein_xol_sumview_T3.csv")

### Create cover page summary table #####################################################################################

# Summary RIF figures
total_performing_primary_adj_RIF <- sum(ExhibitF_agg_primary[ExhibitF_agg_primary$perf_status == "Performing", ]$adj_RIF)
total_nonperforming_primary_adj_RIF <- sum(ExhibitF_agg_primary[ExhibitF_agg_primary$perf_status == "Non-Performing", ]$adj_RIF)
total_rein_xol_adj_RIF_credit <- ifelse(is.na(total_direct_RIF_rein_prexol - total_adj_RIF_rein_xol), 0, total_direct_RIF_rein_prexol - total_adj_RIF_rein_xol)
total_other_obligations_adj_RIF <- 0
total_summary_adj_RIF <- sum(total_performing_primary_adj_RIF, total_nonperforming_primary_adj_RIF, total_pool_RIF, 
                             -1 * total_rein_xol_adj_RIF_credit, total_other_obligations_adj_RIF)

# Summary required assets figures
total_performing_primary_ra_amt <- sum(ExhibitF_agg_primary[ExhibitF_agg_primary$perf_status == "Performing", ]$ra_amt)
total_nonperforming_primary_ra_amt <- sum(ExhibitF_agg_primary[ExhibitF_agg_primary$perf_status == "Non-Performing", ]$ra_amt)
total_rein_xol_ra_amt_credit <- ifelse(is.na(total_ra_amt_rein_prexol - total_ra_amt_rein_xol), 0, total_ra_amt_rein_prexol - total_ra_amt_rein_xol) 
total_other_obligations_ra_amt <- 0
total_summary_ra_amt <- sum(total_performing_primary_ra_amt, total_nonperforming_primary_ra_amt, total_ra_net_ddtbl_stoploss, 
                            -1 * total_rein_xol_ra_amt_credit, total_other_obligations_ra_amt)

# Summary RA factors
performing_primary_ra_amt_factor <- total_performing_primary_ra_amt / total_performing_primary_adj_RIF
nonperforming_primary_ra_amt_factor <- total_nonperforming_primary_ra_amt / total_nonperforming_primary_adj_RIF
other_obligations_ra_amt_factor <- ifelse(is.na(total_other_obligations_ra_amt / total_other_obligations_adj_RIF), 0, total_other_obligations_ra_amt / total_other_obligations_adj_RIF)
summary_ra_amt_factor <- total_summary_ra_amt / total_summary_adj_RIF

# Create summary view table
cover_page_sumview_col_names <- c("Required Asset Amount", "Adjusted Risk in Force", "%")
cover_page_sumview <- data.frame(required_asset_amount = c(total_performing_primary_ra_amt, total_nonperforming_primary_ra_amt, total_ra_net_ddtbl_stoploss,
                                                           -1 * total_rein_xol_ra_amt_credit, total_other_obligations_ra_amt, total_summary_ra_amt),
                                 adusted_RIF = c(total_performing_primary_adj_RIF, total_nonperforming_primary_adj_RIF, total_pool_RIF,
                                                 -1 * total_rein_xol_adj_RIF_credit, total_other_obligations_adj_RIF, total_summary_adj_RIF),
                                 required_asset_amount_factor = c(performing_primary_ra_amt_factor, nonperforming_primary_ra_amt_factor, ra_amt_factor_pool_str,
                                                                  0, other_obligations_ra_amt_factor, summary_ra_amt_factor))
names(cover_page_sumview) <- cover_page_sumview_col_names

cover_page_sumview

# Output cover page summary view table
write.csv(cover_page_sumview, "ExhibitF_cover_page_sumview.csv")

### Stop the clock ######################################################################################################
proc.time() - ptime

#### END ################################################################################################################
