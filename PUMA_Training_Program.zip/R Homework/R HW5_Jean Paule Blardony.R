### Problem 1 ###

# Use integrate() and function to find the area under the curve

integrate(function(x) x^2-x, lower = 1, upper = 10)

integrate(function(x) sin(x)+cos(x), lower = -pi, upper = pi)

integrate(function(x) exp(x)/x, lower = 10, upper = 20)


### Problem 2 ###

# What does the following function do? What's a better name than bc?

bc <- function(lambda) {
  if (lambda == 0) {
    function(x) log(x)
  } else {
    function(x) (x ^ lambda - 1) / lambda
  }
}

# This is a single parameter Box-Cox power transformation.


### Problem 3 ###

# Implement a summary function that works like base summary()

my_summary <- function(df) {
  
  Min <- sapply(df, function(x) min(x))
  FirstQ <- sapply(df, function(x) quantile(x, .25))
  Median <- sapply(df, function(x) median(x))
  Mean <- sapply(df, function(x) mean(x))
  ThirdQ <- sapply(df, function(x) quantile(x, .75))
  Max <- sapply(df, function(x) max(x))
  
  return (rbind(Min, FirstQ, Median, Mean, ThirdQ, Max))
  
}

my_summary(mtcars)


### Problem 4 ###

# The function below scales a vector so it falls in the range [0, 1].

scale01 <- function(x) {
  rng <- range(x, na.rm = TRUE)
  (x - rng[1]) / (rng[2] - rng[1])
}

# How would you apply it to every column of a data frame?

sapply(diamonds[1:20, ], scale01)

# How would you apply it to every numeric column in a data frame?

sapply(diamonds[1:20, ][sapply(diamonds[1:20, ],is.numeric)],scale01)


### Problem 5 ###

# Use below xvariables to determine mpg using lm()

formulas <- list(
  mpg ~ disp,
  mpg ~ I(1 / disp),
  mpg ~ disp + wt,
  mpg ~ I(1 / disp) + wt
)


# Use for loop to implement lm() of mpg from mtcars

regression_function <- function(vars, df) {
  
  mpg_model <- list()
    
  for (i in 1:length(vars)) {
    
    mpg_model[[i]] <- lm(formula = vars[[i]], df)
    
  }
  
  return(mpg_model)
  
}
  
regression_function(formulas, mtcars)

# Use lapply to implement lm() of mpg from mtcars

lapply(formulas, function(x) lm(x, mtcars))


### Problem 6 ###

# The following code simulates a t-test for non-normal data

trials <- replicate(100, t.test(rpois(10, 10), rpois(7, 10)), simplify = FALSE)

class(trials)

# trials$p.value <why does this produce null?>

# Using sapply and anonymous function to extract p-values

sapply(trials, function(x) x$p.value)


### Problem 7 ###

# Load loanprofile.txt

loanProfile <- read.table("loanProfile.txt", sep = "|", header = TRUE, stringsAsFactors = FALSE)

str(loanProfile)

# Remove NAs from data

NA_remover <- function(df) {
  
  df[df == -99999] <- NA
  return(df)
  
}

NA_remover(loanProfile)

# Calculated the UPB weighted mean of CURRENT_FICO

wavg_CurrFICO <- weighted.mean(loanProfile$CBD_CURRENT_FICO, loanProfile$CURRENT_ACTUAL_UPB_DOLLAR)
wavg_CurrFICO


# Function factory to replace any missing value AND calculate UPB weighted mean of BACKEND_RATIO_RATE

missing_fixer <- function(na_value) {
  
  function(df) {
    
    df[df == na_value] <- NA
    return(df)
    
  }
  
}

df <- lapply(loanProfile, missing_fixer(-99999))

weighted.mean(df$BACKEND_RATIO_RATE, df$CURRENT_ACTUAL_UPB_DOLLAR, na.rm = TRUE)


### Problem 8 ###

# Use filter and vapply() to create a function that applies a summary statistic to every numeric column in a data frame

apply_mean <- function(df) {
  
  vapply(Filter(is.numeric, df), mean, double(1))

}

apply_mean(diamonds)


### Problem 9 ###

# Manually implement argmax() of below function with given input vector

my_vector <- c(1:4) # vector 

my_function <- sapply(my_vector, function(x) x^2-x) # function

argmax.input <- my_vector[which.max(my_function)]
argmax.input


### Problem 10 - 12 in SQL ###


### Problem 13 ###

library(magrittr)
library(dplyr)

# Analyze GOOGL stock using magrittr and dplyr

googl <- read.csv("googl.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)
str(googl)

# Add daily %chg column

daily_simple_return <- googl2$Close / lag(googl2$Close, k = -1) - 1
daily_simple_return
hist(daily_simple_return)
googl2 <- cbind(googl, daily_simple_return)

# Filter for volume greater than 20000000

googl2 %>% filter(Volume > 25000000)

# Filter for % daily change greater than +6%

googl2 %>% filter(daily_simple_return > .06)

# Filter for % daily change less than -6%

googl2 %>% filter(daily_simple_return < -.06) 







