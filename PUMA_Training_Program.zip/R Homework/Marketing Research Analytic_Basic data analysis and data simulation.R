###############################################################
# R Marketing Research Analytics                              #
# by Chapman & Feit                                           #  
# Example 1: Basic data analysis and data simulation          #
###############################################################

### Create dataframe containing store, country, product, sales, price, and promotion status data for every week for 2 years i.e. 20x104 = 2080 observations
k.stores <- 20
k.weeks <- 104  # 2 years of data
store.df <- data.frame(matrix(NA, ncol = 10, nrow = k.stores * k.weeks))
names(store.df) <- c("storeNum", "Year", "Week", "p1sales", "p2sales", "p1price", "p2price", "p1prom", "p2prom", "country")

# Use dim function to evaluate number of row and columns
dim(store.df)

# Create vectors that represent store number and country for each observation
store.num <- 101:(100 + k.stores)
store.cty <- c(rep("US", 3), rep("DE", 5), rep("GB", 3), rep("BR", 2), rep("JP", 4), rep("AU", 1), rep("CN", 2))
length(store.cty)

# Fill in store.df with store numbers and country location
store.df$storeNum <- rep(store.num, each = k.weeks) # each argument repeats every element of the vector a designates number of times
store.df$country <- rep(store.cty, each = k.weeks)
rm(store.num, store.cty)  # delete store.num and store.cty vectors

# Fill in store.df with week and year values
store.df$Week <- rep(1:52, times = k.stores * 2) # times argument repeats the entire vector a designated number of times
store.df$Year <- rep(rep(1:2, each=k.weeks/2), times=k.stores)

# Redefine store numbers and country as categorical variables i.e. factors
store.df$storeNum <- factor(store.df$storeNum)
store.df$country <- factor(store.df$country)
