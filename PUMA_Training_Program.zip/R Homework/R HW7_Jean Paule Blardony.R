#################
### Problem 1 ### 
#################

################################################
### Part 1: Create LLPA matrix of Credit ROC ###
################################################

# Load data into global environment

loanData <- read.table("/home/g1usid/R/data/internData/loanProfile.txt", sep = "|", header = TRUE, stringsAsFactors = FALSE)
modResults <- read.table("/home/g1usid/R/data/internData/Results.dat", sep = "|", header = TRUE, stringsAsFactors = FALSE)

# Merge tables along key LOAN_ID and subset relevant variables

loanData_comp <- merge(loanData, modResults, by = 'LOAN_ID')
myvars <- c("LOAN_ID", "CBD_CURRENT_FICO", "COMBINED_MTMLTV_RATE", "CreditROC", "ROCWeight")
loanData_comp_small <- loanData_comp[myvars]
str(loanData_comp_small)

# Create MLTV and FICO buckets using cut function then add to data.frame as categorical variable

MLTV_buckets <- c(-Inf, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 0.97, Inf)
MLTV_buckets_labels <- c('<=60', '(60,65]', '(65,70]', '(70,75]', '(75,80]', '(80,85]', '(85,90]', '(90,95]', '(95,97]', '> 97')
MLTV_dist <- cut(loanData_comp_small$COMBINED_MTMLTV_RATE, breaks = MLTV_buckets, labels = MLTV_buckets_labels, include.lowest = TRUE, right = FALSE)

FICO_buckets <- c(-Inf, 620, 640, 660, 680, 700, 720, 740, Inf)
FICO_buckets_labels <- c('<=620', '(620,640]', '(640,660]', '(660,680]', '(680,700]', '(700,720]', '(720,740]', '>740')
FICO_dist <- cut(loanData_comp_small$CBD_CURRENT_FICO, breaks = FICO_buckets, labels = FICO_buckets_labels, include.lowest = TRUE, right = FALSE)

loanData_comp_small$MLTV_BUCKET <- MLTV_dist
loanData_comp_small$FICO_BUCKET <- FICO_dist

# Calculate weighted Credit ROCs, weighting by ROCWeight

loanData_comp_small$CreditROC_Wtd <- loanData_comp_small$CreditROC * loanData_comp_small$ROCWeight

# Aggregate CreditROC_Wtd and ROCWeight by FICO and LTV, divide to calculate weighted average Credit ROC for each bucket

CreditROC_agg <- aggregate(data.frame(loanData_comp_small$CreditROC_Wtd, loanData_comp_small$ROCWeight), by = list(MLTV = loanData_comp_small$MLTV_BUCKET, FICO = loanData_comp_small$FICO_BUCKET), sum)

colnames(CreditROC_agg)[3] <- "CreditROC_Wtd"
colnames(CreditROC_agg)[4] <- "ROCWeight"

CreditROC_agg$Wtd_Avg_CreditROC <- CreditROC_agg$CreditROC_Wtd / CreditROC_agg$ROCWeight

# Convert long format aggregation to wide format using dcast()

require(reshape2)

CreditROC_grid <- dcast(CreditROC_agg, FICO~MLTV, value.var = "Wtd_Avg_CreditROC")
print(CreditROC_grid[rev(rownames(CreditROC_grid)), ])

############################################################################
### Part 2: Create correlation matrix between FICO, MLTV, and Credit ROC ###
############################################################################

testvars <- c("CBD_CURRENT_FICO", "COMBINED_MTMLTV_RATE", "CreditROC")
corr.test(loanData_comp_small[testvars], use = "complete")

#############################################################################
### Part 3: Conduct simple linear regression of CreditROC on FICO and LTV ###
#############################################################################

CreditROC_fit <- lm(loanData_comp_small$CreditROC ~ loanData_comp_small$CBD_CURRENT_FICO + loanData_comp_small$COMBINED_MTMLTV_RATE)
par(mfrow = c(2,2))
plot(CreditROC_fit)
summary(CreditROC_fit)

#################
### Problem 2 ### 
#################

########################################
### Part 1: Convert ACI_PROB to odds ###
########################################

# Load data

acquisitionData <- read.table("/home/g1usid/R/data/internData/acquisitionPortfolio.txt", sep = "|", header = TRUE, stringsAsFactors = FALSE)

# Create ACI_ODD variable, natural log of ACI_PROB / 1-ACI_PROB

acquisitionData$ACI_ODD <- log(acquisitionData$ACI_PROB / (1 - acquisitionData$ACI_PROB))

# Conduct forward stepwise regression 

require(MASS)

ACI_ODD_fit <- lm(ACI_ODD ~ ORIGINATION_MIN_FICO + ORIGINATION_LTV_RATE + MI_COVERAGE_RATE + NUMBER_OF_BORROWERS + FIRST_LIEN_RATIO, data = acquisitionData)

stepAIC(ACI_ODD_fit, direction = "backward")

summary(stepAIC(ACI_ODD_fit, direction = "backward"))













