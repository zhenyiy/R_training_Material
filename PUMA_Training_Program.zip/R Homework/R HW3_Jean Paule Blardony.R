setwd("/home/k2ujcb")

### Problem 1 ###

library(data.table)

# Set file path

file_path <- "/home/d1uhak/LPPub/Data/"
file_list <- list.files(file_path, pattern = glob2rx("*Performance*txt"), full.names=TRUE)
file_list[60] # 4Q'14 performance file

# Define variables classes and variable names

data_colclasses = c("character", "character", "character", "numeric", "numeric", "numeric", "numeric", "numeric", "character", "character", "character", "character", "character", "character", "character", "character", "character", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric")
data_varnames = c("LOAN_IDENTIFIER", "MONTHLY_REPORTING_PERIOD", "SERVICER_NAME",	"CURRENT_INTEREST_RATE",	"CURRENT_ACTUAL_UNPAID_PRINCIPAL_BALANCE_(UPB)",	"LOAN_AGE",	"REMAINING_MONTHS_TO_LEGAL_MATURITY",	"ADJUSTED_REMAINING_MONTHS_TO_MATURITY",	"MATURITY_DATE",	"METROPOLITAN_STATISTICAL_AREA_(MSA)",	"CURRENT_LOAN_DELINQUENCY_STATUS",	"MODIFICATION_FLAG",	"ZERO_BALANCE_CODE",	"ZERO_BALANCE_EFFECTIVE_DATE",	"LAST_PAID_INSTALLMENT_DATE",	"FORECLOSURE_DATE",	"DISPOSITION_DATE",	"FORECLOSURE_COSTS",	"PROPERTY_PRESERVATION_AND_REPAIR_COSTS",	"ASSET_RECOVERY_COSTS",	"MISCELLANEOUS_HOLDING_EXPENSES_AND_CREDITS",	"ASSOCIATED_TAXES_FOR_HOLDING_PROPERTY",	"NET_SALE_PROCEEDS",	"CREDIT_ENHANCEMENT_PROCEEDS",	"REPURCHASE_MAKE_WHOLE_PROCEEDS",	"OTHER_FORECLOSURE_PROCEEDS",	"NON_INTEREST_BEARING_UPB",	"PRINCIPAL_FORGIVENESS_UPB")

# Read file using fread

performance_4Q14 <- fread(file_list[60], sep = "|", colClasses = data_colclasses, stringsAsFactors = FALSE, showProgress = FALSE) 
setnames(performance_4Q14, data_varnames)
str(performance_4Q14)

# Create function to convert dates from characters to dates

readtable_withDateConversion <- function(file_path, file_type, file_num) { #where file_num is the number of the file in file_list
  
  library(data.table)
  
  my_file_list <- list.files(file_path, pattern = glob2rx(file_type), full.names=TRUE) 
  
  setClass("myDate1")
  setClass("myDate2")
  
  setAs("character", "myDate1", function(from) as.Date(from, format = "%m/%d/%Y"))
  setAs("character", "myDate2", function(from) as.Date(paste("01/",from), format = "%d/%m/%Y"))
  
  data_colclasses = c("character", "myDate1", "character", "numeric", "numeric", "numeric", "numeric", "numeric", "myDate2", "character", "character", "character", "character", "myDate2", "myDate1", "myDate1", "myDate1", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric", "numeric")
  data_varnames = c("LOAN_IDENTIFIER", "MONTHLY_REPORTING_PERIOD", "SERVICER_NAME",	"CURRENT_INTEREST_RATE",	"CURRENT_ACTUAL_UNPAID_PRINCIPAL_BALANCE_(UPB)",	"LOAN_AGE",	"REMAINING_MONTHS_TO_LEGAL_MATURITY",	"ADJUSTED_REMAINING_MONTHS_TO_MATURITY",	"MATURITY_DATE",	"METROPOLITAN_STATISTICAL_AREA_(MSA)",	"CURRENT_LOAN_DELINQUENCY_STATUS",	"MODIFICATION_FLAG",	"ZERO_BALANCE_CODE",	"ZERO_BALANCE_EFFECTIVE_DATE",	"LAST_PAID_INSTALLMENT_DATE",	"FORECLOSURE_DATE",	"DISPOSITION_DATE",	"FORECLOSURE_COSTS",	"PROPERTY_PRESERVATION_AND_REPAIR_COSTS",	"ASSET_RECOVERY_COSTS",	"MISCELLANEOUS_HOLDING_EXPENSES_AND_CREDITS",	"ASSOCIATED_TAXES_FOR_HOLDING_PROPERTY",	"NET_SALE_PROCEEDS",	"CREDIT_ENHANCEMENT_PROCEEDS",	"REPURCHASE_MAKE_WHOLE_PROCEEDS",	"OTHER_FORECLOSURE_PROCEEDS",	"NON_INTEREST_BEARING_UPB",	"PRINCIPAL_FORGIVENESS_UPB")
  
  my_data_table <- read.table(my_file_list[file_num], sep = "|", colClasses = data_colclasses)
  setnames(my_data_table, data_varnames)
  
  return (str(my_data_table))
  
}

readtable_withDateConversion("/home/d1uhak/LPPub/Data/", "*Performance*txt", 60)

# Test time of function

system.time(readtable_withDateConversion("/home/d1uhak/LPPub/Data/", "*Performance*txt", 60))

### Problem 3 ###

# Connect to Neteeza or Oracle and query data via function

data_query <- function(database, query_instruct) {
  
  if (database == "Neteeza") {
    
    library(RSQLite)
    library(RJDBC)
    library(stringr)
    
    .jinit(classpath="myClasses.jar", parameters="-Xmx512m")
    .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
    .jclassPath()
    
    start_aqsn_dte <- 201301 # define time period, if applicable
    end_aqsn_dte <- 201312
    
    drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
    con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
    netres <- dbSendQuery(con, query_instruct) #query instruction
    netres <- fetch(netres, n = -1)
    return (netres)
    dbDisconnect(con)
    
  } else {
    
    library(ROracle)
    library(stringr)
    
    drv = dbDriver ("Oracle")
    host = "pwarehouse-rdb11lp1"
    port = "1521"
    sid = "POWH17"
    connect.string <- paste(
      "(DESCRIPTION=",
      "(ADDRESS=(PROTOCOL=tcp)(HOST=", host, ")(PORT=", port, "))",
      "(CONNECT_DATA=(SID=", sid, ")))", sep = "")
    con <- dbConnect(drv,Sys.getenv("db_username"),Sys.getenv("db_password_oracle"),dbname=connect.string)
    orares <- dbGetQuery(con, query_instruct)
    return (orares)
    dbDisconnect(con)
    
  }
  
}

data_query("Neteeza", "SELECT DISTINCT sell_no FROM NZ_VEW_LL_LN_1
           WHERE P_ENTITY = 'JPMOR'")

# Test time of function

system.time(data_query("Neteeza", "SELECT DISTINCT sell_no FROM NZ_VEW_LL_LN_1
           WHERE P_ENTITY = 'JPMOR'"))

### Problem 4 ###

data_query <- function(database, query_instruct) {
  
  if (database == "Neteeza") {
    
    library(RSQLite)
    library(RJDBC)
    library(stringr)
    
    .jinit(classpath="myClasses.jar", parameters="-Xmx512m")
    .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
    .jclassPath()
    
    start_aqsn_dte <- 201301 # define time period, if applicable
    end_aqsn_dte <- 201312
    
    drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
    con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
    return (dbGetFields(con, query_instruct))
    dbDisconnect(con)
    
  } else {
    
    library(ROracle)
    library(stringr)
    
    drv = dbDriver ("Oracle")
    host = "pwarehouse-rdb11lp1"
    port = "1521"
    sid = "POWH17"
    connect.string <- paste(
      "(DESCRIPTION=",
      "(ADDRESS=(PROTOCOL=tcp)(HOST=", host, ")(PORT=", port, "))",
      "(CONNECT_DATA=(SID=", sid, ")))", sep = "")
    con <- dbConnect(drv, Sys.getenv("db_username"), Sys.getenv("db_password_oracle"), dbname=connect.string)
    info <- dbGetInfo(con, query_instruct)
    return (info$fields)
    dbDisconnect(con)
    
  }
  
}

data_query("Neteeza", "NZ_PUMA_TAB_POP")

# Test time of function

system.time(data_query("Neteeza", "NZ_PUMA_TAB_POP"))

### Problem 5 ###

data_query <- function(database, query_instruct, col_name) {
  
  if (database == "Neteeza") {
    
    library(RSQLite)
    library(RJDBC)
    library(stringr)
    
    .jinit(classpath="myClasses.jar", parameters="-Xmx512m")
    .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
    .jclassPath()
    
    start_aqsn_dte <- 201301 # define time period, if applicable
    end_aqsn_dte <- 201312
    
    drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
    con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
    fields <- dbGetFields(con, query_instruct)
    print (fields[2,3])
    return (fields[grep(col_name, fields$COLUMN_NAME),4])
    dbDisconnect(con)
    
  } else {
    
    library(ROracle)
    library(stringr)
    
    drv = dbDriver ("Oracle")
    host = "pwarehouse-rdb11lp1"
    port = "1521"
    sid = "POWH17"
    connect.string <- paste(
      "(DESCRIPTION=",
      "(ADDRESS=(PROTOCOL=tcp)(HOST=", host, ")(PORT=", port, "))",
      "(CONNECT_DATA=(SID=", sid, ")))", sep = "")
    con <- dbConnect(drv, Sys.getenv("db_username"), Sys.getenv("db_password_oracle"), dbname=connect.string)
    info <- dbGetInfo(con, query_instruct)
    return (info$fields)
    dbDisconnect(con)
    
  }
  
}

data_query("Neteeza", "NZ_PUMA_TAB_POP", "FNMA")

# Test system time

system.time(data_query("Neteeza", "NZ_PUMA_TAB_POP", "FNMA"))

### Problem 6 ###

# Compare number of unique p entities in PUMA_TAB_POP in Neteeza and Vew_LL_LN_1 in Oracle

data_query <- function(database, query_instruct) {
  
  if (database == "Neteeza") {
    
    library(RSQLite)
    library(RJDBC)
    library(stringr)
    
    .jinit(classpath="myClasses.jar", parameters="-Xmx512m")
    .jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
    .jclassPath()
    
    start_aqsn_dte <- 201501 # define time period, if applicable
    end_aqsn_dte <- 201512
    
    drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
    con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
    netres <- dbSendQuery(con, query_instruct) #query instruction
    netres <- fetch(netres, n = -1)
    return (netres)
    dbDisconnect(con)
    
  } else {
    
    library(ROracle)
    library(stringr)
    
    drv = dbDriver ("Oracle")
    host = "pwarehouse-rdb11lp1"
    port = "1521"
    sid = "POWH17"
    connect.string <- paste(
      "(DESCRIPTION=",
      "(ADDRESS=(PROTOCOL=tcp)(HOST=", host, ")(PORT=", port, "))",
      "(CONNECT_DATA=(SID=", sid, ")))", sep = "")
    con <- dbConnect(drv,Sys.getenv("db_username"),Sys.getenv("db_password_oracle"),dbname=connect.string)
    orares <- dbGetQuery(con, query_instruct)
    return (orares)
    dbDisconnect(con)
    
  }
  
}

# Neteeza query

data_query("Neteeza", "SELECT COUNT(DISTINCT P_ENTITY_SELL) FROM NZ_PUMA_TAB_POP
WHERE (AQ_ACTDT BETWEEN '01-JAN-2015' AND '31-DEC-2015')")

# Oracle query

data_query("Oracle", "SELECT COUNT(DISTINCT P_ENTITY) FROM VEW_LL_LN_1
WHERE (AQ_ACTDT BETWEEN '01-JAN-2015' AND '31-DEC-2015')")

# Test time of function

system.time(data_query("Neteeza", "SELECT COUNT(DISTINCT P_ENTITY_SELL) FROM NZ_PUMA_TAB_POP
WHERE (AQ_ACTDT BETWEEN '01-JAN-2015' AND '31-DEC-2015')"))

system.time(data_query("Oracle", "SELECT COUNT(DISTINCT P_ENTITY) FROM VEW_LL_LN_1
WHERE (AQ_ACTDT BETWEEN '01-JAN-2015' AND '31-DEC-2015')"))

### Problem 7 ###

# Run Neteeza query and create data frame of 2015 FNMA LN, FICO, TPO CODE, and OCC STAT

library(RSQLite)
library(RJDBC)
library(stringr)
    
.jinit(classpath="myClasses.jar", parameters="-Xmx512m")
.jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
.jclassPath()
    
drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
netres <- dbSendQuery(con, "SELECT FNMA_LN, FICO, TPO_CODE, OCC_STAT
                      FROM NZ_PUMA_TAB_POP
                      WHERE (AQ_ACTDT BETWEEN '01-JAN-2015' AND '31-DEC-2015')") #query instruction
netres <- fetch(netres, n = -1)
my.data <- data.frame(netres)
attach(my.data)
dbDisconnect(con)

# Mean, max, and min of FICO

max(my.data$FICO)

avgFICO <- mean(my.data$FICO, na.rm = T)
maxFICO <- max(my.data$FICO, na.rm = T)
minFICO <- min(my.data$FICO, na.rm = T)

avgFICO_table <- data.frame(avgFICO, maxFICO, minFICO)

avgFICO_table

# Use aggregate to calculate mean, max, and min of FICO by TPO CODE 

avgFICO_byTPO <- aggregate(FICO~TPO_CODE, my.data, mean)
maxFICO_byTPO <- aggregate(FICO~TPO_CODE, my.data, max)
minFICO_byTPO <- aggregate(FICO~TPO_CODE, my.data, min)

print(avgFICO_byTPO)
print(maxFICO_byTPO)
print(minFICO_byTPO)

# Use aggregate to calculate mean, max, and min of FICO by OCC STAT  

avgFICO_byOCC <- aggregate(FICO~OCC_STAT, my.data, mean)
maxFICO_byOCC <- aggregate(FICO~OCC_STAT, my.data, max)
minFICO_byOCC <- aggregate(FICO~OCC_STAT, my.data, min)

print(avgFICO_byOCC)
print(maxFICO_byOCC)
print(minFICO_byOCC)

# Use aggregate to calculate mean, max, and min of FICO by TPO CODE and OCC STAT  

avgFICO_byTPO_OCC <- aggregate(FICO~TPO_CODE+OCC_STAT, my.data, mean)
maxFICO_byTPO_OCC <- aggregate(FICO~TPO_CODE+OCC_STAT, my.data, max)
minFICO_byTPO_OCC <- aggregate(FICO~TPO_CODE+OCC_STAT, my.data, min)

print(avgFICO_byTPO_OCC)
print(maxFICO_byTPO_OCC)
print(minFICO_byTPO_OCC)

### Problem 8 ###

# Run Neteeza query and create data frame of FICO and LTV for 2004-2014 acquisitions 

library(RSQLite)
library(RJDBC)
library(stringr)

.jinit(classpath="myClasses.jar", parameters="-Xmx512m")
.jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") 
.jclassPath()

drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
con <- dbConnect(drv, "jdbc:netezza://pwarehouse-unz01:5480/PUMA", Sys.getenv("db_username"), Sys.getenv("db_password_neteeza")) # connection prompt
netres <- dbSendQuery(con, "SELECT FNMA_LN, FICO, LTV, AQ_ACTDT 
                      FROM NZ_PUMA_TAB_POP
                      WHERE (AQ_ACTDT BETWEEN '01-JAN-2004' AND '31-DEC-2014')") #query instruction
netres <- fetch(netres, n = -1)
my.data <- data.frame(netres)
attach(my.data)
dbDisconnect(con)

# Create buckets for FICO: 'Missing FICO', '[0-680)', '[680-720)','[720-760)', '[760+)'

FICO_dist <- cut(my.data$FICO, breaks = c(-Inf, 0, 680, 720, 760, Inf), labels = c('Missing FICO', '[0-680)', '[680-720)','[720-760)', '[760+)'), include.lowest = TRUE, right = FALSE)
FICO_table <- table(FICO_dist)
FICO_table

# Create buckets for LTV: 'Missing LTV', '[0-60)', '[60-70)', '[70-80)', '[80-90)', '[90-95)', '(95+)'

LTV_dist <- cut(my.data$LTV, breaks = c(-Inf,0, .60, .70, .80, .90, .95, Inf), labels = c('Missing LTV', '[0-60)', '[60-70)', '[70-80)', '[80-90)', '[90-95)', '(95+)'), include.lowest = TRUE, right = FALSE)
LTV_table <- table(LTV_dist)
LTV_table
