getwd()

setwd("/home/gaudss/RForInterns/Lecture1") 

x <- c(88,89,90,91)

c(1,2,3) + c(1,2,3,4,5,6)

# Vector operations

x <- c(1,2,3)
x + c(5,0,-1)
x * c(5,0,-1)
x / c(5,0,-1)

5:8

seq(from=12,to=30,by=3)
seq(from=12,to=20,by=0.2)

w <- function(x) { return (x+1) }
w(x)

sqrt(1:10)
