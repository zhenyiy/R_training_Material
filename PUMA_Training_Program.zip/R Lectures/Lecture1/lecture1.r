###############################################
# R class for Spring 2016 Intern Class
###############################################


# find out your current working directory
getwd()

# list objects in your current workspace
ls()

# change working directory
setwd("/home/gaudss/RForInterns/Lecture1") 

# remove all objects
rm(list = ls())

# vectors

x
x <- c(88,89,90,91)
x
y <- c(x,x,x,x,x,x,x,x,x,x,x)
y
z=3
z

str(z)
mode(z)

length(x)

class(x)

#Vector with mixed variable types

y <- c(1,"Two",3)
y

# Recycling

c(1,2,3) + c(1,2,3,4,5,6)

# Vector operations

x <- c(1,2,3)
x + c(5,0,-1)
x * c(5,0,-1)
x / c(5,0,-1)

u <- c(5,2,3)
v <- c(1,3,9)
u>v

y <- c(1.2,3.9,0.4,0.12)

y[c(1,3)]
y[1:3]

5:8

# basic use in for loop
#
# for ( i in 1:length(x)) { ... }
# 

seq(from=12,to=30,by=3)
seq(from=12,to=20,by=0.2)

seq(5)

#basic function

w <- function(x) return (x+1)
w(u)
w <- function(x) { return (x+1) }
w(u)

sqrt(1:10)
y <- c(1.2,3.9,0.4)
round(y)

# list

a <- list(name="Alice", salary=98000, state="MD")
a
a$name
b <- list("Bob", 38000, "VA")
b

b[1]
b[[1]]

a$salary
a[[2]]
a[["salary"]]

a$year <- 1990

a

names(a)

unlist(a)
class(a)
class(unlist(a))

b$year <- 1998


# Data Frames

a <- c("Alice", "Bob")
b <- c(98000,38000)
c <- c("MD","VA")

d <- data.frame(a,b,c)
d

d <- data.frame(name=a,salary=b,state=c)
d

str(d)

d <- data.frame(name=a,salary=b,state=c,stringsAsFactors = FALSE)

str(d)


# we want to analyze some data

# load data
loanprofile <- read.table("smallProfile.dat", sep="|", header=TRUE, stringsAsFactors=FALSE, na.strings = "-99999")
results <- read.table("smallResults.dat", sep="|", header=TRUE, stringsAsFactors=FALSE)

ls()

# Investigate the data
# str() displays the structure of an R object

str(loanprofile)
str(results)

#summary() shows the basic stats
# View the loaded data in RStudio

summary(loanprofile$ARM_INDICATOR)
summary(results$Losses)
summary(loanprofile$FLOAT_DAYS_AA_COUNT)


loanprofile_frm <- subset(loanprofile, ARM_INDICATOR == 0, select=c(LOAN_ID, ARM_INDICATOR, COMBINED_MTMLTV_RATE, CURRENT_DLQ_MONTH_COUNT, CURRENT_UPB_DOLLAR, INTEREST_ONLY_INDICATOR)) 

loanprofile_arm <- subset(loanprofile, ARM_INDICATOR == 1, select=c(LOAN_ID, ARM_INDICATOR, COMBINED_MTMLTV_RATE, CURRENT_DLQ_MONTH_COUNT, CURRENT_UPB_DOLLAR, INTEREST_ONLY_INDICATOR)) 

# Subset the loan profile to include only {LOAN_ID, Losses, GrossLosses,
# StressLosses, GrossStressLosses}

few_res <- subset(results, select=c(LOAN_ID, Losses, GrossLosses, StressLosses, GrossStressLosses,GFeebps,Capital,PVM,PVMTsy,AdminPVbps,FloatPVbps,LossPVbps,LossPVbpsTsy,StressLossPVbpsTsy)) 

# delete original dataframes
rm(loanprofile, results)

# See below that all the dataframe attributes are conserved
str(loanprofile_frm)
str(loanprofile_arm)
str(few_res)

#approximate capital

few_res$cap <- (few_res$StressLossPVbpsTsy - few_res$LossPVbpsTsy)/100
few_res$capcost <- few_res$cap * 12 /0.65

few_res$modelFee <- 16 + few_res$capcost + few_res$LossPVbps/few_res$PVM + few_res$FloatPVbps/few_res$PVM

fee_err <- few_res$GFeebps - few_res$modelFee

summary(fee_err)

plot(few_res$GFeebps, few_res$modelFee)

x<-seq(0,500,by=1)
lines(x,x)

# Merge datasets (innerjoin), keeping all loans in the intersection of both datasets

losses_frm <- merge(loanprofile_frm, few_res, by=c("LOAN_ID"))
losses_arm <- merge(loanprofile_arm, few_res, by=c("LOAN_ID"))

# Note, if the primary key is named differently the syntax will be:
# suppose that in loanprofile the key was named LN_ID, then:
#
# merge(loanprofile_arm, results_small, by.x=c(LN_ID), by.y=c(LOAN_ID))
#
# delete the source datasets

rm(loanprofile_frm, loanprofile_arm, results_small)

# See below that all the dataframe attributes are conserved

str(losses_frm)
str(losses_arm)


## PROBABILITY ##
# Calculate mean and stddev of losses

summary(losses_frm$GrossLosses)
summary(losses_arm$GrossLosses)
mu_frm_GrossLosses <- mean(losses_frm$GrossLosses)
mu_arm_GrossLosses <- mean(losses_arm$GrossLosses)
sigma_frm_GrossLosses <- sd(losses_frm$GrossLosses)
sigma_arm_GrossLosses <- sd(losses_arm$GrossLosses)
str(mu_frm_GrossLosses)
str(mu_arm_GrossLosses)

# What is this object

class(mu_frm_GrossLosses)
class(losses_frm)

mu_frm_GrossLosses
sigma_frm_GrossLosses

# Pr( X > 0.3868163)

1 - pnorm(0.3868163, mean = mu_frm_GrossLosses, sd = sigma_frm_GrossLosses)

# Pr(0.06 < X < 0.66)

pnorm(0.66, mean = mu_frm_GrossLosses, sd = sigma_frm_GrossLosses) - pnorm(0.06, mean = mu_frm_GrossLosses, sd = sigma_frm_GrossLosses)

# 1%, 5%, 24%, 50%, 75%, 95% and 99% quantile of the normal dist with mu and sd equal to losses_frm$GrossLosses's

qnorm(c(0.01, 0.05, 0.25, 0.50, 0.75, 0.95, 0.99), mean = mu_frm_GrossLosses, sd = sigma_frm_GrossLosses)

# dnorm() function gives you the normal density for given mu and sd
#histogram against normal density

plot(function(x){ dnorm(x,mean=mu_frm_GrossLosses, sd=sigma_frm_GrossLosses) },xlim=c(-2.10,3.00), ylim=c(0,2.5),xlab = "frm_GrossLosses", ylab = "Density")

hist(losses_frm$GrossLosses, breaks = 50 ,xlim=c(-2.00,3.00), freq=FALSE, add=TRUE)

#histogram against log normal density

plot(function(x)dlnorm(x,mean=mu_frm_GrossLosses, sd=sigma_frm_GrossLosses),xlim=c(-2.10,3.00), ylim=c(0,2.5),xlab = "frm_GrossLosses", ylab = "Density")

hist(losses_frm$GrossLosses, breaks = 50 ,xlim=c(-2.00,3.00), freq=FALSE, add=TRUE)


###########################

Year <- c(1800, 1850, 1900, 1950, 2000)
Carbon <- c(8, 54, 534, 1630, 6611)
plot(Carbon ~ Year, pch=16)

fossilfuel <- data.frame(year=Year, carbon=Carbon)
fossilfuel

Ozone <- c(4, 8, 54, 160, 661)
oc <- data.frame(year=Year, ozone=Ozone)

total <- merge(fossilfuel, oc, by="year")
head(total)

Carbon <- c(8, 54, 534, 1630, 6611)
Trees <- c(128, 64, 32, 16, 8)

tc <- data.frame(tree=Trees,carbon=Carbon)
tc

test <- merge(fossilfuel, tc, by="carbon")


plot(test$year, test$tree)
plot(test$year, test$tree, xlab="Year", ylab="Number of Trees")

#################################


help(Distributions)
help(Normal)

# Probability Density Function

dnorm(0)
dnorm(0)*sqrt(2*pi)
dnorm(0,mean=2)
dnorm(0,mean=4)
dnorm(0,mean=4,sd=2)
dnorm(0,mean=4,sd=5)
x <- seq(-5,5,by=0.1)
y <- dnorm(x)

plot(x,y)
plot(x,y,pch='.')
y <- dnorm(x,mean=2,sd=1.5)
plot(x,y,pch='.',add=TRUE)

?plot
lines(x,y,pch='.')

# Distribution Function

pnorm(0)
pnorm(1)
pnorm(1,lower.tail=FALSE)
y <- pnorm(x,mean=3,sd=4)
plot(x,y,pch='.')

# Inverse CDF (quantile function)

qnorm(0.5)
qnorm(0.5,mean=2,sd=4)
qnorm(0.25,mean=2,sd=4)
xx <- seq(0,1,by=.05)
yy <- qnorm(xx,mean=3,sd=2)

plot(xx,yy,pch='.')
lines(xx,yy)

# Random number generation

rnorm(3)
rn <- rnorm(300)
mean(rn)
rn <- rnorm(30000)
mean(rn)
sd(rn)
rn <- rnorm(30)
mean(rn); sd(rn)

rnorm(3)
set.seed(12345)
rnorm(3)

set.seed(12345)
rnorm(3)

rn <- rnorm(3000)
mean(rn); sd(rn)
rn <- rnorm(300000)
mean(rn); sd(rn)
rn <- rnorm(3000000)
mean(rn); sd(rn)

rn <- rnorm(300)
mean(rn); sd(rn)
hist(rn)

qqnorm(rn,pch=4)
qqline(rn)


#Uniform random number genertion

y <- runif(x)
y
length(y)
?runif


y1 <- runif(x,min=-1,max=1)
y2 <- runif(x,min=-1,max=1)
newvar <- which (y1*y1+y2*y2 < 1)
#head(newvar)
#tail(newvar)
#length(newvar)

#mypi <- length(newvar)/100
#mypi*4

#mypi <- length(which (y1*y1+y2*y2 < 1))*4/10000
#mypi
#n<-1000000
#y1 <- runif(n,min=-1,max=1); y2 <- runif(n,min=-1,max=1)
#mypi <- length(which (y1*y1+y2*y2 < 1))*4/n
#mypi

n<-5000
y <- runif(n,min=-1,max=1); y2 <- runif(n,min=-1,max=1)
plot(y,y2,pch='.')
hist(y)

# Statistical Tests

rn <- rnorm(100)
t <- t.test(rn)

# t is an object

str(t)
t$conf.int

t <- t.test(rnorm(100))
t$conf.int

t.test(rnorm(100))$conf.int
t.test(rnorm(100000))$conf.int


# How to do it over and over

replicate(10,mean(rnorm(100)))
replicate(10,mean(rnorm(10000)))
replicate(10,mean(rnorm(100000)))

replicate(100,mean(rnorm(1000)))

# How to see the results of replication

library(ggplot2)

qplot(replicate(10,mean(rnorm(100000))),geom="histogram")

qplot(replicate(100,mean(rnorm(10))),geom="histogram")

qplot(replicate(1000,mean(runif(10))),geom="histogram")

qplot(replicate(1000,mean(runif(1000,min=0,max=10))),geom="histogram")

### functions

draw_mean_rnorm <- function (n, m) {}

draw_mean_rnorm <- function (n, m) {
  qplot(replicate(m,mean(rnorm(n))), geom="histogram")
}

draw_mean_rnorm(100,100)
draw_mean_rnorm(1000,100)
draw_mean_rnorm(1000,1000)
draw_mean_rnorm(10000,100000)

# Default arguments in functions

g <- function(x,y=2,z=T) { x==y && z }

g(2)
g(3,3)
g(3,3,F)
g(3,3,T)

## simulation
### Sum of exponentials gives gamma distribution

require(ggplot2)

rep <- 50000
nexp <- 5
rate <- 1
set.seed(0)

x1 <- replicate(rep,sum(rexp(n=nexp, rate=rate)))

ggplot(data.frame(x1), aes(x1)) + geom_histogram(aes(y=..density..))+stat_function(fun=function(x)dgamma(x, shape=nexp,scale=1/rate), color="red", size=2)
