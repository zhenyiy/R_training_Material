select
    channel,
    act_dte,
    sum(mtmltv*hfr_upb)/sum(hfr_upb) as mtmltv,
    sum(under_water_upb)/sum(hfr_upb)*100 as under_water_pct,
    sum(d180_upb)/sum(hfr_upb)*100 as d180_pct,
    sum(d90_upb)/sum(hfr_upb)*100 as d90_pct,
    sum(d60_upb)/sum(hfr_upb)*100 as d60_pct,
    sum(hfr_upb) as hfr_upb
    from
    (
      select
        case when ln1.bus_chan='2' then 'Investor Channel'
             when ln1.bus_chan='3' then 'Lender Channel'
             else 'Other Channel' end as channel,
        ln1.bus_chan, a1.act_dte, a1.mtmltv,
        case when a1.mtmltv>1 then a1.hfr_upb else 0 end under_water_upb,
        case when a1.mthsdel>=6 then a1.hfr_upb else 0 end d180_upb,
        case when a1.mthsdel>=3 then a1.hfr_upb else 0 end d90_upb,
        case when a1.mthsdel>=2 then a1.hfr_upb else 0 end d60_upb,
        a1.hfr_upb
      from vew_ll_ln_actvy_1 a1
      inner join vew_ll_ln_1 ln1
      on ln1.fnma_ln=a1.fnma_ln
      where ln1.aqsn_dt>=to_date(200401,'YYYYMM') and ln1.aqsn_dt<add_months(to_date(200403,'YYYYMM'),1)
    ) agg
    group by channel, act_dte
    order by channel, act_dte
