library(ggplot2)

p <- ggplot(data=mtcars)

p1 <- p + geom_point(aes(x=disp,y=mpg))
p2 <- p + geom_line(aes(x=disp,y=mpg))
p3 <- p + geom_bar(aes(x=mpg))
p4 <- p + geom_boxplot(aes(x=factor(gear), y=mpg))
p5 <- p1 + geom_text(x=200,y=25, label="Scatter Plot")
p6 <- p + geom_histogram(aes(x=disp))

source('~/Kaggle/BNPParibas/code/multiplot.R')

multiplot(p1,p2,p3,p4,p5,cols=2)
multiplot(p1,p2,p3,p4,p5,cols=3)

multiplot(p1,p2,p3,p4,p5,p6,cols=3)

p6 <- p + geom_histogram(aes(x=disp),bins = 10)

multiplot(p1,p2,p3,p4,p5,p6,cols=3)
