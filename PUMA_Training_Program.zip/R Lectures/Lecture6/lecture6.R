setwd("/home/gaudss/RForInterns/Lecture6")

set.seed(1410)

dsmall <- diamonds[sample(nrow(diamonds), 200),]
str(dsmall)

plot(dsmall)



















#How to plot a data frame

setwd("/home/gaudss/RForInterns/Lecture1")
loanprofile <- read.table("smallProfile.dat", sep="|", header=TRUE, stringsAsFactors=FALSE, na.strings = "-99999")
plot(loanprofile)
str(loanprofile)
plot(loanprofile[12:22,])
plot(loanprofile[12:16,])
plot(loanprofile[,12:16])











getwd()
setwd("/home/gaudss/RForInterns/Lecture6")


crts_6class <- read.table(file="crts6_obj.txt",header=T, sep=";")


attach(crts_6class)

head(crts_6class)

plot(amplitude,std)

# Changing a few things for display

?plot

# plot functions

plot(sin, -pi, 2*pi)


plot(amplitude)

plot(amplitude, type = "p", col = "red", lwd = 10, main = "Amplitude")
plot(amplitude, type = "h", col = "red", lwd = 1, main = "Amplitude")
plot(amplitude, type = "h", col = "red", lwd = 1, main = "Amplitude", xlab="X Label")
plot(amplitude, type = "p", col = "red", lwd = 1, main = "Amplitude", xlab="X Label", ylab="Y Label")
plot(amplitude, type = "b", col = "red", lwd = 1, main = "Amplitude")
plot(amplitude, type = "c", col = "red", lwd = 1, main = "Amplitude")
plot(amplitude, type = "o", col = "red", lwd = 1, main = "Amplitude")
plot(amplitude, type = "n", col = "red", lwd = 1, main = "Amplitude")

#
# Going to ggplot2
# Grammar of Graphics - mostly suited for 2D plots
# Specify plot at a high level of specification

library(ggplot2)

# Defined default behavior

qplot(amplitude)

qplot(amplitude,std)

ggplot(aes(amplitude,std))

ggplot(aes(amplitude,std), data=crts_6class)

# does not produce a plot as geometry not specified

ggplot(data=crts_6class, aes(amplitude,std)) + geom_point()

p <- ggplot(aes(amplitude,std), data=crts_6class)
p1 <- p + geom_point()

p1

p + geom_point()
p + geom_point() + geom_smooth()

ggplot(aes(amplitude,std), data=crts_6class[amplitude < 5,]) + geom_point() + geom_smooth()

#adding more aesthetics

ggplot(data=crts_6class, aes(x=amplitude,y=std, shape=object))+geom_point()

ggplot(data=crts_6class, aes(x=amplitude,y=std, color=object))+geom_point()

?ggplot

ggplot(data=crts_6class, aes(x=amplitude,y=std)) + geom_point() + geom_smooth()

ggplot(data=crts_6class, aes(x=amplitude,y=std, color=object)) + geom_point() + geom_smooth()

ggplot(data=crts_6class, aes(x=object, y=amplitude)) + geom_jitter()

ggplot(data=crts_6class, aes(x=object, y=amplitude)) + geom_jitter(alpha=0.75)

ggplot(data=crts_6class, aes(x=object, y=amplitude)) + geom_boxplot()

ggplot(data=crts_6class, aes(x=amplitude,color=object)) + geom_density()

ggplot(data=crts_6class, aes(x=amplitude,y=std)) + geom_point() + facet_grid(.~object)

ggplot(data=crts_6class, aes(x=amplitude,y=std)) + geom_point() + facet_grid(.~object) + geom_smooth()

#ggplot(data=crts_6class, aes(x=amplitude,y=std)) + geom_point() + facet_grid(.~object) + geom_smooth(methods=x)

summary(p)

p2 <- ggplot(data = crts_6class, aes(amplitude,std))

p2 + layer(geom = "density2d",geom_params = list(fill = "steelblue"),stat = "density2d",stat_params = list(binwidth=0.01))

p2 + geom_point(color="red")




# Exploring ggplot some more

library(ggplot2)

qplot(carat, price, data=dsmall)
qplot(carat, price, data=diamonds)

qplot(log(carat), log(price), data=diamonds)

#View data
#diamonds

#head(diamonds)
#tail(diamonds)

qplot(carat, x*y*z, data=diamonds)
qplot(carat, price, data=dsmall, colour=color)
qplot(carat, price, data=dsmall, shape=cut)

qplot(carat, price, data=dsmall, alpha=I(1/10))

qplot(carat, price, data=diamonds, alpha=I(1/30))
qplot(carat, price, data=diamonds, alpha=I(1/10))
#qplot(carat, price, data=diamonds, geom=c("point","smooth"))
#qplot(carat, price, data=diamonds, geom=c("point","smooth"),se=FALSE)
#qplot(carat, price, data=diamonds, geom=c("point","smooth"))

qplot(carat, price, data=dsmall, geom=c("point","smooth"))

#

qplot(color, price / carat, data=diamonds, geom="point")
qplot(color, price / carat, data=diamonds, geom="jitter")
qplot(color, price / carat, data=diamonds, geom="jitter", alpha=I(1/5))
qplot(color, price / carat, data=diamonds, geom="jitter", alpha=I(1/20))
qplot(color, price / carat, data=diamonds, geom="jitter", alpha=I(1/200))

qplot(carat, data=diamonds, geom="histogram")
qplot(carat, data=diamonds)
qplot(carat, data=diamonds, geom="density")
qplot(carat, data=diamonds, geom="density", binwidth=1, xlim=c(0,3))
qplot(carat, data=diamonds, geom="histogram", binwidth=1, xlim=c(0,3))
qplot(carat, data=diamonds, geom="histogram", binwidth=0.1, xlim=c(0,3))
qplot(carat, data=diamonds, geom="histogram", binwidth=0.01, xlim=c(0,3))
qplot(carat, data=diamonds, geom="histogram", binwidth=0.5, color=color, xlim=c(0,3))
qplot(carat, data=diamonds, geom="density", color=color, xlim=c(0,3))
qplot(carat, data=diamonds, geom="density", color=color)
qplot(carat, data=diamonds, geom="density", fill=color, xlim=c(0,3))

qplot(color, data=diamonds, geom="bar", fill=color, xlim=c(0,3), weight=carat) + scale_y_continuous("carat")
qplot(color, data=diamonds, geom="bar")
qplot(color, data=diamonds, geom="bar", weight=carat) + scale_y_continuous("carat")

qplot(date, unemploy / pop, data = economics, geom="line")

qplot(date, uempmed, data = economics, geom="line")

plot(economics)
