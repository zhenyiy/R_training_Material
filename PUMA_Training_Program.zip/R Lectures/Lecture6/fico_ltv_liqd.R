# Input Parameters:

# Acqisition Period
start_aqsn_dt <- '201201'
end_aqsn_dt <- '201212'

# liquidation Code
liqd_cd<-'1'

# RDW UserId and Password
DBuserid <- 'xxxxxx'
DBPassword <- 'xxxxxx'

library(ROracle)  # Oracle database interface
library(ggplot2)  # An implementation of the Grammar of Graphics
library(reshape2) # Flexibly reshape data
library(plyr)     # Tools for splitting, applying and combining data
library(scales)   # Scale functions for graphics
library(labeling) # Axis Labeling

drv <- dbDriver("Oracle")
host <- "pwarehouse-rdb11lp1"
port <- "1521"
sid <- "POWH17"
connect.string <- paste(
  "(DESCRIPTION=",
  "(ADDRESS=(PROTOCOL=tcp)(HOST=", host, ")(PORT=", port, "))",
  "(CONNECT_DATA=(SID=", sid, ")))", sep = "")

# Create the SQL Statements

# Sub-query for minimum FICO
min_fico_sql<-paste(
  "(select fnma_ln, min(crd_scr) as fico",
  "from vew_ll_applnt_brwr_cr_scr",
  "where aqsn_dt>=to_date(",start_aqsn_dt,",'YYYYMM') and aqsn_dt<add_months(to_date(",end_aqsn_dt,",'YYYYMM'),1)",
  "group by fnma_ln)",sep=" ")
min_fico_sql

# Create the FICO Buckets
start<-590
end<-800
step<-10
bkt<-seq(from=start,to=end,by=step)

fico_bkt<-paste(' when fico.fico<',bkt, 'then', bkt, collapse='')
fico_bkt<-paste('case when fico.fico is null or fico.fico<',start-step, 'then', start-step, fico_bkt, 'else', end+step, 'end as fico,', collapse='')
fico_bkt

# Create the LTV Buckets
start<-0.20
end<-1.25
step<-0.05
bkt<-seq(from=start,to=end,by=step)

ltv_bkt<-paste(' when ln1.ltv<',bkt, 'then', bkt*100, collapse='')
ltv_bkt<-paste('case when fico.fico is null or fico.fico<',start-step, 'then', (start-step)*100, ltv_bkt, 'else', (end+step)*100, 'end as ltv,')
ltv_bkt

sql_stmt<-paste(
  "select",
  fico_bkt,
  ltv_bkt,
  "ln1.fnma_upb",
  "from vew_ll_ln_1 ln1",
  "inner join",
  min_fico_sql, "fico on fico.fnma_ln=ln1.fnma_ln",
  "where ln1.aqsn_dt>=to_date(",start_aqsn_dt,",'YYYYMM') and ln1.aqsn_dt<add_months(to_date(",end_aqsn_dt,",'YYYYMM'),1)", sep=" ")

sql_stmt<-paste(
  "select fico, ltv, sum(fnma_upb) as fnma_upb from (",
  sql_stmt,
  ") ln group by fico, ltv order by fico desc, ltv", spe=" ")
sql_stmt

liq_sql_stmt<-paste(
  "select",
  fico_bkt,
  ltv_bkt,
  "ln1.actupbrm",
  "from vew_ll_ln_1 ln1",
  "inner join vew_ll_ln_2 ln2 on ln2.fnma_ln=ln1.fnma_ln",
  "inner join",
  min_fico_sql, "fico on fico.fnma_ln=ln1.fnma_ln",
  "where ln1.aqsn_dt>=to_date(",start_aqsn_dt,",'YYYYMM') and ln1.aqsn_dt<add_months(to_date(",end_aqsn_dt,",'YYYYMM'),1)",
  "and ln2.liqd_cd=", liqd_cd, sep=" ")

liq_sql_stmt<-paste(
  "select fico, ltv, sum(actupbrm) as liqd_upb from (",
  liq_sql_stmt,
  ") liq group by fico, ltv order by fico desc, ltv", sep=" ")

liq_sql_stmt

con<-dbConnect(drv,username=DBuserid,password=DBPassword,dbname=connect.string)
rs<-dbSendQuery(con,sql_stmt)
data_upb<-fetch(rs)
dbDisconnect(con)

con<-dbConnect(drv,username=DBuserid,password=DBPassword,dbname=connect.string)
rs<-dbSendQuery(con,liq_sql_stmt)
data_liq<-fetch(rs)
dbDisconnect(con)

dim(data_upb)
dim(data_liq)

head(data_upb)
head(data_liq)

# Meage data frame
merged<-merge(data_upb,data_liq,by=c("FICO","LTV"),all.x=TRUE)
merged$liq_pct<-merged$LIQD_UPB/merged$FNMA_UPB*100
head(merged)

mid<-(max(merged$liq_pct, na.rm=T)-min(merged$liq_pct,na.rm=T))/2

legand_name<-switch(liqd_cd, "1"="CPR %", "3"="CDR %", "2"="Repurchase %")

(p <- ggplot(merged, aes(LTV, FICO))
 + geom_tile(aes(fill = liq_pct), color = 'grey100', size=.1) 
 + scale_fill_gradient2(name=legand_name, 
                        low = 'forestgreen', mid = 'orange', high = 'red', 
                        midpoint = mid, space = "rgb", na.value = 'black', guide = 'colorbar'))

base_size <- 9
p + labs(title = paste('Aqsn Date: ',start_aqsn_dt, ' - ', end_aqsn_dt)) +
  theme_grey(base_size = base_size) + 
  scale_x_continuous(expand = c(0, 0)) +
  scale_y_continuous(expand = c(0, 0)) +
  theme(
    panel.border = element_rect(linetype = 'solid', color = 'grey30', fill = NA, size = 0.1),
    plot.background = element_rect(fill="grey96"),
    # legend.position = 'none',
    legend.key.width = unit(12,'points'),
    panel.grid = element_line(size=0)
  )
