# Input Parameters:

# Acqisition Period
start_aqsn_dt <- '201201'
end_aqsn_dt <- '201212'

# RDW UserId and Password
DBuserid <- 'xxxxxx'
DBPassword <- 'xxxxxx'

library(ROracle)  # Oracle database interface
library(ggplot2)  # An implementation of the Grammar of Graphics
library(reshape2) # Flexibly reshape data
library(plyr)     # Tools for splitting, applying and combining data
library(scales)   # Scale functions for graphics
library(labeling) # Axis Labeling

drv <- dbDriver("Oracle")
host <- "pwarehouse-rdb11lp1"
port <- "1521"
sid <- "POWH17"
connect.string <- paste(
  "(DESCRIPTION=",
  "(ADDRESS=(PROTOCOL=tcp)(HOST=", host, ")(PORT=", port, "))",
  "(CONNECT_DATA=(SID=", sid, ")))", sep = "")

# Display the coonection string
connect.string

con <- dbConnect(drv,username=DBuserid,password=DBPassword,dbname=connect.string)

# Create the SQL Statements

# Sub-query for minimum FICO
min_fico_sql<-paste(
  "(select fnma_ln, min(crd_scr) as fico",
  "from vew_ll_applnt_brwr_cr_scr",
  "where aqsn_dt>=to_date(",start_aqsn_dt,",'YYYYMM') and aqsn_dt<add_months(to_date(",end_aqsn_dt,",'YYYYMM'),1)",
  "group by fnma_ln)",sep=" ")
min_fico_sql

# Create the FICO Buckets
start<-590
end<-800
step<-10
bkt<-seq(from=start,to=end,by=step)

fico_bkt<-paste(' when fico.fico<',bkt, 'then', bkt, collapse='')
fico_bkt<-paste('case when fico.fico is null or fico.fico<',start-step, 'then', start-step, fico_bkt, 'else', end+step, 'end as fico,', collapse='')
fico_bkt

# Create the LTV Buckets
start<-0.20
end<-1.25
step<-0.05
bkt<-seq(from=start,to=end,by=step)

ltv_bkt<-paste(' when ln1.ltv<',bkt, 'then', bkt*100, collapse='')
ltv_bkt<-paste('case when fico.fico is null or fico.fico<',start-step, 'then', (start-step)*100, ltv_bkt, 'else', (end+step)*100, 'end as ltv,')
ltv_bkt

sql_stmt<-paste(
    "select",
      fico_bkt,
      ltv_bkt,
      "ln1.fnma_upb",
    "from vew_ll_ln_1 ln1",
    "inner join",
    min_fico_sql, "fico on fico.fnma_ln=ln1.fnma_ln",
    "where ln1.aqsn_dt>=to_date(",start_aqsn_dt,",'YYYYMM') and ln1.aqsn_dt<add_months(to_date(",end_aqsn_dt,",'YYYYMM'),1)", sep=" ")

sql_stmt<-paste(
  "select fico, ltv, sum(fnma_upb) as fnma_upb from (",
  sql_stmt,
  ") ln group by fico, ltv order by fico desc, ltv", spe=" ")
sql_stmt

# Submits and executes the SQL statement
rs<-dbSendQuery(con,sql_stmt)

# Fetch the records
data_fl<-fetch(rs)

dbDisconnect(con)

total_upb<-sum(data_fl$FNMA_UPB)

data_fl$upb_pct<-data_fl$FNMA_UPB/total_upb*100

head(data_fl)

#data_fl.m <- melt(data_fl,id.vars=c('FICO','LTV'), measure.vars = 'upb_pct')

#head(data_fl.m)

mid<-(max(data_fl.m$value)-min(data_fl.m$value))/2
mid<-mid-mid*.25

(p <- ggplot(data_fl, aes(LTV, FICO))
  + geom_tile(aes(fill=upb_pct), color = 'grey100', size=.1) 
  + scale_fill_gradient2(name='UPB %', 
      low = 'grey100', mid = 'lightblue', high = muted('steelblue', l=30, c=60), 
      midpoint = mid, space = "rgb", na.value = 'black', guide = 'colorbar'))

base_size <- 9
p + labs(title = paste('Aqsn Date: ',start_aqsn_dt, ' - ', end_aqsn_dt)) +
  theme_grey(base_size = base_size) + 
  scale_x_continuous(expand = c(0, 0)) +
  scale_y_continuous(expand = c(0, 0)) +
  theme(
    panel.border = element_rect(linetype = 'solid', color = 'grey30', fill = NA, size = 0.1),
    plot.background = element_rect(fill="grey96"),
    # legend.position = 'none',
    legend.key.width = unit(12,'points'),
    panel.grid = element_line(size=0)
  )





