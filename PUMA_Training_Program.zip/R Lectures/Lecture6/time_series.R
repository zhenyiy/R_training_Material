# Input Parameters:

# Acqisition Period
start_aqsn_dt<-201001
end_aqsn_dt<-201003

# RDW UserId and Password
DBuserid <- 'xxxxxx'
DBPassword <- 'xxxxxx'

library(ROracle)    # Oracle database interface
library(ggplot2)    # An implementation of the Grammar of Graphics
library(reshape2)   # Flexibly reshape data
library(plyr)       # Tools for splitting, applying and combining data
library(scales)     # Scale functions for graphics
library(labeling)   # Axis Labeling
library(stringr)    # Make it easier to work with strings.

drv <- dbDriver("Oracle")
host <- "pwarehouse-rdb11lp1"
port <- "1521"
sid <- "POWH17"
connect.string <- paste(
  "(DESCRIPTION=",
  "(ADDRESS=(PROTOCOL=tcp)(HOST=", host, ")(PORT=", port, "))",
  "(CONNECT_DATA=(SID=", sid, ")))", sep = "")

#SQL Query
sql_stmt<-sprintf(
  "select
    channel,
    act_dte,
    sum(mtmltv*hfr_upb)/sum(hfr_upb) as mtmltv,
    sum(under_water_upb)/sum(hfr_upb)*100 as under_water_pct,
    sum(d180_upb)/sum(hfr_upb)*100 as d180_pct,
    sum(d90_upb)/sum(hfr_upb)*100 as d90_pct,
    sum(d60_upb)/sum(hfr_upb)*100 as d60_pct,
    sum(hfr_upb) as hfr_upb
    from
    (
      select
        case when ln1.bus_chan='2' then 'Investor Channel' when ln1.bus_chan='3' then 'Lender Channel' else 'Other Channel' end as channel,
        ln1.bus_chan, a1.act_dte, a1.mtmltv,
        case when a1.mtmltv>1 then a1.hfr_upb else 0 end under_water_upb,
        case when a1.mthsdel>=6 then a1.hfr_upb else 0 end d180_upb,
        case when a1.mthsdel>=3 then a1.hfr_upb else 0 end d90_upb,
        case when a1.mthsdel>=2 then a1.hfr_upb else 0 end d60_upb,
        a1.hfr_upb 
      from vew_ll_ln_actvy_1 a1
      inner join vew_ll_ln_1 ln1
      on ln1.fnma_ln=a1.fnma_ln
      where ln1.aqsn_dt>=to_date(%d,'YYYYMM') and ln1.aqsn_dt<add_months(to_date(%d,'YYYYMM'),1)
    ) agg
    group by channel, act_dte
    order by channel, act_dte", start_aqsn_dt, end_aqsn_dt)

sql_stmt<-str_replace_all(sql_stmt,"\n","")
sql_stmt<-str_replace_all(sql_stmt,"    "," ")
sql_stmt

con<-dbConnect(drv,username=DBuserid,password=DBPassword,dbname=connect.string)
rs<-dbSendQuery(con,sql_stmt)
ts<-fetch(rs)
dbDisconnect(con)

dim(ts)
head(ts)

#D180
g<-ggplot(ts, aes(x=ACT_DTE, y=D180_PCT))
g<-g+geom_line(aes(color=factor(CHANNEL)))
g<-g+scale_colour_manual(name='Channel', values=c(rgb(62/255,91/255,143/255),rgb(158/255,5/255,5/255),"grey100"))
g<-g+labs(title=paste('Aqsn Date: ',start_aqsn_dt, ' - ', end_aqsn_dt), x="Activity Date", y="D180 %")
g

#D90
g<-ggplot(ts, aes(x=ACT_DTE, y=D90_PCT))
g<-g+geom_line(aes(color=factor(CHANNEL)))
g<-g+scale_colour_manual(name='Channel', values=c(rgb(62/255,91/255,143/255),rgb(158/255,5/255,5/255),"grey100"))
g<-g+labs(title=paste('Aqsn Date: ',start_aqsn_dt, ' - ', end_aqsn_dt), x="Activity Date", y="D90 %")
g

#D60
g<-ggplot(ts, aes(x=ACT_DTE, y=D60_PCT))
g<-g+geom_line(aes(color=factor(CHANNEL)))
g<-g+scale_colour_manual(name='Channel', values=c(rgb(62/255,91/255,143/255),rgb(158/255,5/255,5/255),"grey100"))
g<-g+labs(title=paste('Aqsn Date: ',start_aqsn_dt, ' - ', end_aqsn_dt), x="Activity Date", y="D60 %")
g

#Under Water %
g<-ggplot(ts, aes(x=ACT_DTE, y=UNDER_WATER_PCT))
g<-g+geom_line(aes(color=factor(CHANNEL)))
g<-g+scale_colour_manual(name='Channel', values=c(rgb(62/255,91/255,143/255),rgb(158/255,5/255,5/255),"grey100"))
g<-g+labs(title=paste('Aqsn Date: ',start_aqsn_dt, ' - ', end_aqsn_dt), x="Activity Date", y="Under Water %")
g

#UPB
g<-ggplot(ts, aes(x=ACT_DTE, y=HFR_UPB))
g<-g+geom_ribbon(aes(ymin=0,ymax=HFR_UPB,color=factor(CHANNEL)),fill="grey20", alpha=0.2)
g<-g+scale_colour_manual(name='Channel', values=c("grey65","grey65","white"))
g<-g+labs(title=paste('Aqsn Date: ',start_aqsn_dt, ' - ', end_aqsn_dt), x="Activity Date", y="UPB")
g

