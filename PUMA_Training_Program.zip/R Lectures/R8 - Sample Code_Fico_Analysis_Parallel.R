#Clear the memory
rm(list=ls())

# Start the clock!
dt_op <- proc.time()


# Start the clock!
fico_analysis_start <- proc.time()

library(doParallel)

start_aqsn_window <- "01-MAR-2005"
window_dt = as.numeric(format(seq(as.Date(start_aqsn_window, "%d-%b-%Y"), by = "month", length.out = 1), format = "%Y%m"))

cl <- makeCluster(length(window_dt))
registerDoParallel(cl)


parallel_Fico_Analysis <- foreach(i=window_dt, .inorder=FALSE,
                         .packages=c("ROracle", "stringr", "data.table", "tidyr")) %dopar% {

                          #DB User/Pwd
                          DBuserid <- 'k2ujcb'
                          DBpwd = 'Jpb310_2'

                          drv = dbDriver ("Oracle")
                          host = "pwarehouse-rdb11lp1"
                          port = "1521"
                          sid = "POWH17"
                          connect.string = paste(
                          "(DESCRIPTION =",
                          "(ADDRESS = (PROTOCOL=tcp) (HOST=", host, ") (PORT=", port, "))",
                          "(CONNECT_DATA=(SID=", sid, ")))", sep = " ")

#Create SQL Statement to connect to Puma Tab Pop to get loans 
data_keeps = sprintf(
 "(select
 a.fnma_ln
 from vew_ll_ln_1 a,
 vew_ll_ln_2 b,
 vew_ll_ln_appl c
 where a.fnma_ln = b.fnma_ln and
 a.fnma_ln = c.fnma_ln and
 a.LTV <=.97 and
 c.D_RATIOB<=.5   and 
 a.aq_actdt=to_date(%d,'YYYYMM') and
 (a.P_ALTA ='0' or a.P_ALTA is NULL) and
 (a.lpp_prod <>'5' or a.lpp_prod <>'8' or a.lpp_prod <>'11' or a.lpp_prod <>'12' 
 or a.lpp_prod <>'18' or a.lpp_prod <>'24' or a.lpp_prod <>'27' or a.lpp_prod <>'28' 
 or a.lpp_prod <>'29' or a.lpp_prod <>'30') and
 (b.P_SUBPRI = '0' or b.P_SUBPRI is null) and  
 b.NEGAMORT <> 'Y' and
 (b.P_INTRF <> '1' or b.P_INTRF <> '2') and  
 (b.harp_cde not in ('1', '2') or b.harp_cde is null) and  
 (b.P_SUBPRI = '0' or b.P_SUBPRI is NULL) and  
 (a.seasoned = 'N' or a.seasoned is null) and
 (a.lpp_prod <> '1' or a.lpp_prod <>'16' or a.RSTR_FLG <> 'Y' or a.MSFT_IND <> 'Y' 
 or  b.R_REDLV <>'1' or b.R_REDLV <>'2'))",  i)

data_keeps<-str_replace_all(data_keeps,"\n","")

data_fico = sprintf(
 "select
 case when b.scoringm in (10, 11, 12)
 then 3
 when b.scoringm in (3, 9, 15)
 then 2
 else 1 end as priority,
 a.fnma_ln,
 a.casefile,
 b.crrptid,
 b.appltspo,
 b.score,
 a.cr_rptdt,
 b.scoringm,
 b.segsrcid
 from VEW_GEN_WU_CR_RPT a,
 vew_wu_cr_rpt_mtg_risk_scr b,
 %s d
 where a.casefile = b.casefile and
 b.crrptid  = a.crrptid  and
 d.fnma_ln  = a.fnma_ln  and
 b.original = 'O' and
 a.aq_actdt = to_date(%d,'YYYYMM') and
 a.aq_actdt>a.cr_rptdt and b.hitlvl = 1 and 
 (b.appltspo = '1' or b.appltspo = '2') and
 b.score between 300 and 900 and
 (b.segsrcid = 1 or b.segsrcid = 2 or b.segsrcid = 3) and
 (b.scoringm = 3 or b.scoringm = 6 or b.scoringm = 9 or
 b.scoringm = 11 or b.scoringm = 12 or b.scoringm = 13 or
 b.scoringm = 14 or b.scoringm = 15)", data_keeps, i)

data_fico<-str_replace_all(data_fico,"\n","")


                            con = dbConnect(drv, username = DBuserid, password=DBpwd, dbname = connect.string)
                            rs = dbSendQuery(con,data_fico)
                            data_fico = fetch(rs)
                            dbDisconnect(con)
                            
                            rm(list= ls()[!(ls() %in% c('data_fico'))])
                            
                            #save(data_fico, file = "data_fico.Rda")
                            
                            #DT[!duplicated(DT[, c("user1", "user2"), with = FALSE])]
                            
                            
                            data_fico = as.data.table (data_fico[!duplicated(data_fico),])
                            
                            #sort the data table ascending order
                            setorderv(data_fico, c("CASEFILE", "CRRPTID", "APPLTSPO", "SCORINGM", "SCORE"))
                            
                            #setkeyv(data_fico, c("CASEFILE", "CRRPTID", "CR_RPTDT", "APPLTSPO"))
                            
                            data_fico = unique(data_fico, by = c("CASEFILE", "CRRPTID", "APPLTSPO", "SCORINGM"))
                            
                            setorderv(data_fico, c("CASEFILE", "CRRPTID", "APPLTSPO", "SEGSRCID", "PRIORITY", "SCORE"))
                            
                            data_fico = unique(data_fico, by = c("CASEFILE", "CRRPTID", "APPLTSPO", "SEGSRCID"))
                                    
                                    
                            # count the number of scores provided:
                            data_fico[, Num_Score:= 1:.N, by = .(CASEFILE, CRRPTID, CR_RPTDT, APPLTSPO)]
                                    
                            data_fico[, Max.No.Score := max(Num_Score), by = .(CASEFILE, CRRPTID, APPLTSPO)]
                                    
                            #keep 3 scores per applicants only
                            data_fico = data_fico[Num_Score <4 ,]
                                    
                                    
                            data_fico[, Usable_Score := ifelse(Max.No.Score==3, median(SCORE), ifelse (Max.No.Score==2, min(SCORE), SCORE)), 
                                                                        by = .(CASEFILE, CRRPTID, APPLTSPO)]
                            setkeyv(data_fico, c("CASEFILE", "APPLTSPO"))
                                    
                            data_fico = unique(data_fico)
                                    
                            #drop unnecessary variables/columns:
                                    
                            #data_fico[,c("PRIORITY", "CR_RPTDT"):=NULL]
                                    
                            #or Keep some columns
                                    
                            data_fico = data_fico[, c("FNMA_LN","APPLTSPO", "Usable_Score"), with = FALSE]
                                    
                            data_fico$APPLTSPO = ifelse(data_fico$APPLTSPO == 1, "Borrower_Scr", "Co_Borrower_Scr")
                                    
                            work_table_final = spread(data_fico, APPLTSPO, Usable_Score)
                                    
                            #Calculate the Average and the Min of the Two Scores
                                    
                                    
                            work_table_final[,c("Avg.Score", "Min.Score") := list(rowMeans(work_table_final[ ,list(Borrower_Scr, Co_Borrower_Scr)], na.rm = TRUE), pmin(Borrower_Scr, Co_Borrower_Scr, na.rm=TRUE))]
                                    
                            #work_table_final$Avg.Score = rowMeans(work_table_final[ ,c("Borrower_Scr", "Co_Borrower_Scr")], na.rm = TRUE)
                                    
                            #work_table_final$Min.Score = pmin(work_table_final$Borrower_Scr, work_table_final$Co_Borrower_Scr, na.rm=TRUE)
                                    
                            as.data.frame(work_table_final)
                         }
stopCluster(cl)

#covnvert the data into a table

work_table <- do.call(rbind, parallel_Fico_Analysis)


#save(work_table, file = "work_table_dt")


# Stop the clock
proc.time() - fico_analysis_start
