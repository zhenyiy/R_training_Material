# Flow control

x <- 0
if(x > 0){
  print("Positive number")
}

# Nested flow control

x <- 0
if (x < 0) {
  print("Negative number")
} else if (x > 0) {
  print("Positive number")
} else
  print("Zero")

# ifelse

  # ifelse(test_expression,x,y)

a = c(5,7,2,9)

ifelse(a %% 2 == 0,"even","odd")




# Loops in R

# For loop

for (year in c(2010,2011,2012,2013,2014,2015)){
  print(paste("The year is", year))
}

# using : operator

for (i in 2010:2015){
  print(paste("The year is", i))
}


# While loop

i <- 1

while (i <= 5) {
  print(i)
#  i = i+1
}

# Break 

x <- 1:5

for (val in x) {
  if (val == 3){
    break
  }
  print(val)
}

# Next

x <- 1:5

for (val in x) {
  if (val == 3){
    next
  }
  print(val)
}

# using next to exit the current iteration 

for (i in 1:10) {
  if (!i %% 2){
    next
  }
  print(i)
}


# Repeat loop, this is infinite
x <- 1

repeat {
  print(x)
  x = x+1
  if (x == 6){
    break
  }
}




# switch 
#

#switch(statement,item1,item2,item3,...,itemN)

switch(2,"red","green","blue")

switch(1,"red","green","blue")



y <- rnorm(5)
y

x <- "sd"
z <- switch(x,
            "mean"=mean(y),
            "median"=median(y),
            "variance"=var(y),
            "sd"=sd(y))
z

x <- "meian"
z <- switch(x,"mean"=mean(y),"median"=median(y),"variance"=var(y),"sd"=sd(y))
z












# Program to diplay the Fibonacci sequence up to n-th tern where
# n is provided by the user

# take input from the user
nterms = as.integer(readline(prompt="How many terms? "))

# first two terms
n1 = 0
n2 = 1
count = 2

# check if the number of terms is valid
if(nterms <= 0) {
  print("Plese enter a positive integer")
} else {
  if(nterms == 1) {
    print("Fibonacci sequence:")
    print(n1)
  } else {
    print("Fibonacci sequence:")
    print(n1)
    print(n2)
    while(count < nterms) {
      nth = n1 + n2
      print(nth)
      # update values
      n1 = n2
      n2 = nth
      count = count + 1
    }
  }
}



# FUNCTIONS - provide reusable program components

func_name <- function (argument) {statement}


pow <- function(x, y) {
  # function to print x raised to the power y
  
  result <- x^y
  print(paste(x,"raised to the power",y,"is",result))
  return(result)
}

pow(8,2)
pow(2,8)

z <- pow(2,8)


# Named Arguments

pow(x=8, y=2)
pow(y=2, x=8)

pow(2, x=8)


# Default Values for Arguments

pow <- function(x, y=2) {
  # function to print x raised to the power y
  result <- x^y
  print(paste(x,"raised to the power",y,"is",result))
}

pow2 <- function(x, y=2) {
  # function to print x raised to the power y
  result <- x^y
  print(paste(x,"raised to the power",y,"is",result))
  result
}


check <- function(x) {
  if (x>0) {
    return("Positive")
  }
  else if (x<0) {
    return("Negative")
  }
  else {
    return("Zero")
  }
}


check2 <- function(x) {
  if (x>0) {
    "Positive"
  }
  else if (x<0) {
    "Negative"
  }
  else {
    "Zero"
  }
}

# Multiple Returns
#
# You can create an object with multiple components and return the whole
# object, but return from R function is a single "object"

multi_return <- function() {
  my_list <- list("color" = "red", "size" = 20, "shape" = "round")
  return(my_list) 
}

a <- multi_return()

a$color



# Recursive function to find factorial

recursive.factorial <- function(x) {
  if (x == 0)    return (1)
  else           return (x * recursive.factorial(x-1))
}



# Infix operators
# all operators in R have an underlying implementation as a function
#

# the expression a+b is actually calling the
# function `+`() with the arguments a and b, as `+`(a, b)

5 + 8

`+`(5,8)


# user-defined infix operators in R.
# --- by naming a function that starts and ends with % and named in `<>`

`%divisible%` <- function(x,y)
{
  if (x%%y == 0) return (TRUE)
  else          return (FALSE)
}

10 %divisible% 3
10 %divisible% 5

# Predefined infix operators

# %% 	  Remainder operator
# %/% 	Integer division
# %*% 	Matrix multiplication
# %o% 	Outer product
# %x% 	Kronecker product
# %in% 	Matching operator 


`%$%` <- function(x,y) {
  if (x > y) { x }
  else { y }
}









`%$%` <- function(x,y) {
# this is silly way to get the maximum of two
  if (x > y) { x }
  else {y}
}
