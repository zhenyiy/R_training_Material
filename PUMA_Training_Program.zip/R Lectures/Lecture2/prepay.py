import pandas as pd
import numpy as np
import scipy as sp
cf = pd.read_table('agg.cfo.pool',sep=" ")
cf.head()
prep = cf[['path','month','PREPAY']]
prep.head(20)
