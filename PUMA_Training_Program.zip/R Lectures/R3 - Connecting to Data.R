/export/appl/bo6_data0_r/Rtraining/Imp_Exp_Methods

#Clear the memory
rm(list=ls())

###3 types - COMMON FILE FORMAT, PROPRIETARY FILE, DBMS
###########IMPORTING COMMON FILE FORMATS####
#USING SCAN, READ.CSV, READ.TABLE, READ.XLS# 
############################################

#Importing comma delimited data files into a R Dataframe using read.csv function
#stringsAsFactors = FALSE keeps character variables as they are rather than convert to factors
#na.strings = c("") empty strings are to be treated as missing values. 
getwd()
setwd("/home/k2uahp/Imp_Exp_Methods/")
BasketData <- read.csv ("/home/k2uahp/Imp_Exp_Methods/BASKET_2015_4_1.CSV",header=TRUE, sep=",", stringsAsFactors=FALSE,
                        nrow=10,na.strings = c(""))
print(BasketData)
str (BasketData)

#Importing delimited data files into a R Dataframe using read.table function
BasketData1 <- read.table ("/home/k2uahp/Imp_Exp_Methods/BASKET_2015_4_1.TXT",header=TRUE, sep="\t", stringsAsFactors=FALSE,nrow=10,na.strings = c(""))

#Importing data files into a list using the scan function
#Scan function returns values to a list or a vector. 
#empfc <- scan ("emp_fc.txt",what = list (yearqq = "",emp = ""))


#How read large tables faster using the colClasses option ?
#To use this option, you have to know the class of each column in your data frame. If all of the columns are "numeric", then you can just set 'colClasses = "numeric"'. If the columns are all different classes then read in just a few rows of the table and set their classes appropriately.
#If your file has no comments in it (e.g. lines starting with '#'), then setting 'comment.char = ""' will sometimes make 'read.table()' run faster.

myCols <- read.table("/home/k2uahp/Imp_Exp_Methods/BASKET_2015_4_1.CSV",header=TRUE, sep=",",colClasses=c("character","integer" ,"integer","integer","numeric","numeric","numeric","numeric","numeric"))
print(myCols)
rm (BasketData1, myCols)

#Runtime performance can improve using the colClasses option
system.time (BasketData1 <- read.table ("/home/k2uahp/Imp_Exp_Methods/BASKET_2015_4_1.CSV",header=TRUE, sep=",", stringsAsFactors=FALSE))

system.time (myCols <- read.table("/home/k2uahp/Imp_Exp_Methods/BASKET_2015_4_1.CSV",header=TRUE, sep=",",colClasses=c("character","integer" ,"integer","integer","numeric","numeric","numeric","numeric","numeric")))

#Read .XLS File into a R Dataframe .gdata package will be used
library(gdata)
MFdata <- read.xls("/home/k2uahp/Imp_Exp_Methods/data.xls",header=TRUE, stringsAsFactors=FALSE)
print (MFdata)
#Load Multiple Sheets
#library(XLConnect)
#readWorksheetFromFile('test.xls', sheet=1)



########## Using fread function in data.table package#####
#                                                        #
##########################################################

library(data.table)

#using regular expressions to create iterator

# You will need the path to where you have saved the downloaded files, please copy and paste or type the path below.
fileslocation<- "/home/d1unjg/LossData"

#create an R object that contains a list the files and their path
FILE_LIST<-list.files(fileslocation, pattern = glob2rx("*txt"), full.names=TRUE)

# Check the number of files downloaded (should be even, equal number of Acquisition and Performance Files).
numberoffiles<-length(list.files(fileslocation, pattern = glob2rx("*txt"), full.names=TRUE))


# We may want specific type of files, or files with certain keywords
Acquisitions <- list.files(fileslocation, pattern = glob2rx("*Acquisition*txt"), full.names=TRUE)

# Define variable types

Acquisition_ColClasses = c("character", "character", "character", "numeric", "numeric", "integer", "character", "character", "numeric",
                           "numeric", "character", "numeric", "numeric", "character", "character", "character", "character", "character", 
                           "character", "character", "numeric", "character", "numeric")


# Read the files/a file using data.table's fread function

Data_A<- fread(Acquisitions[21], sep = "|", colClasses = Acquisition_ColClasses, showProgress=FALSE)

# Define variable names
Acquisitions_Variables = c("LOAN_ID", "ORIG_CHN", "Seller.Name", "ORIG_RT", "ORIG_AMT", "ORIG_TRM", "ORIG_DTE"
                           ,"FRST_DTE", "OLTV", "OCLTV", "NUM_BO", "DTI", "CSCORE_B", "FTHB_FLG", "PURPOSE", "PROP_TYP"
                           ,"NUM_UNIT", "OCC_STAT", "STATE", "ZIP_3", "MI_PCT", "Product.Type", "CSCORE_C")

# set column names using data.table's setnames function
setnames(Data_A, Acquisitions_Variables)


##########IMPORTING PROPRIETARY FILE FORMATS#####
#SAS FILES                                      #
#################################################

#SAS Export# 
#libname sasfile "C:\Training";  *this is where the SAS data set reside; 
#libname xptfile xport "C:\Training\basket.xpt";  *this is where the XPORT file will be created;
#proc copy in=sasfile out=xptfile memtype=data; *If you don't use the memtype=data, SAS attempts to copy the entire contents of the library (including catalogs and views) to the transport file. 
#select basket; 
#run;

#R Import - SAS to R
library(sas7bdat)
BasketSAS = read.sas7bdat ("/home/k2uahp/Imp_Exp_Methods/basket.sas7bdat")
BasketSAS

#Another method to import SAS data to R
#library(foreign)
#library(Hmisc)
#sasdata <- sasxport.get ("BASKET15.xpt")
#print(sasdata)


##########DBMS INPUT PROCEDURE###################
#ORACLE AND NETEZZA                             #
#################################################

# Via Oracle
# Connection Methods: dbConnect, dbDisconnect
# CRUD: dbWriteTable, dbReadTable
# SQL: dbSendQuery, dbFetch, then ClearResult
#library(RSQLite)
#DBUser <- 'USERID'
#DBPasswd <- 'DBPassword'

#Define username and pass in a separate file
#source ('/home/k2uahp/.Rprofile')

#OR

#DB User/Pwd
#DBuserid = 'd1uhak'
#DBpwd = 'your password'

library(ROracle)


library(stringr)    # Make it easier to work with strings.


# Acqisition Period
start_aqsn_dt<-201205
end_aqsn_dt<-201304

data_keeps = sprintf(
  "(select
  a.fnma_ln
  from vew_ll_ln_1 a,
  vew_ll_ln_2 b,
  vew_ll_ln_appl c
  where a.fnma_ln = b.fnma_ln and
  a.fnma_ln = c.fnma_ln and
  a.LTV <=.97 and
  c.D_RATIOB<=.5   and 
  a.aq_actdt=to_date(%d,'YYYYMM') and
  (a.P_ALTA ='0' or a.P_ALTA is NULL) and
  (a.lpp_prod <>'5' or a.lpp_prod <>'8' or a.lpp_prod <>'11' or a.lpp_prod <>'12' 
  or a.lpp_prod <>'18' or a.lpp_prod <>'24' or a.lpp_prod <>'27' or a.lpp_prod <>'28' 
  or a.lpp_prod <>'29' or a.lpp_prod <>'30') and
  (b.P_SUBPRI = '0' or b.P_SUBPRI is null) and  
  b.NEGAMORT <> 'Y' and
  (b.P_INTRF <> '1' or b.P_INTRF <> '2') and  
  (b.harp_cde not in ('1', '2') or b.harp_cde is null) and  
  (b.P_SUBPRI = '0' or b.P_SUBPRI is NULL) and  
  (a.seasoned = 'N' or a.seasoned is null) and
  (a.lpp_prod <> '1' or a.lpp_prod <>'16' or a.RSTR_FLG <> 'Y' or a.MSFT_IND <> 'Y' 
  or  b.R_REDLV <>'1' or b.R_REDLV <>'2'))",  start_aqsn_dt)


drv = dbDriver ("Oracle")
host = "pwarehouse-rdb11lp1"
port = "1521"
sid = "POWH17"
connect.string <- paste(
  "(DESCRIPTION=",
  "(ADDRESS=(PROTOCOL=tcp)(HOST=", host, ")(PORT=", port, "))",
  "(CONNECT_DATA=(SID=", sid, ")))", sep = "")
con <- dbConnect(drv,username=DBUser,password=DBPasswd,dbname=connect.string)

oradata <- dbGetQuery(con, "select ... from ...")
print (oradata)
dbDisconnect(con)


#Write to Oracle

con <- dbConnect(drv, username = DBuserid, password=DBpwd, dbname = connect.string)
if (dbExistsTable(con, "oradata", DBuserid))
  dbRemoveTable(con, "oradata")

dbWriteTable(con, "oradata", c, row.names = TRUE, overwrite = TRUE)

dbDisconnect(con)



#DBMS Input Procedure  - Reading data from a Netezza
library(RJDBC)      # Provides access to databases through the JDBC interface

sql_stmt<-sprintf(
  "select
  case when a.state = 'CA' then 1 else 0 end as CA,
  case when a.state = 'FL' then 1 else 0 end as FL,
  case when a.state in ('ME', 'MA', 'RI', 'CT', 'VT', 'NH') then 1 else 0 end as NewEngland,
  case when a.state in ('NY', 'PA', 'NJ') then 1 else 0 end as MidAtlantic,
  case when a.state in ('DE', 'MD', 'DC', 'VA', 'WV', 'NC', 'SC', 'GA') then 1 else 0 end as SouthAtlantic,
  case when a.state in ('WI', 'MI', 'IL', 'IN', 'OH') then 1 else 0 end as EastNorthCentral, 
  case when a.state in ('KY', 'TN', 'AL', 'MS') then 1 else 0 end as EastSouthCentral,
  case when a.state in ('ND', 'SD', 'NE', 'KS', 'MO', 'IA', 'MN') then 1 else 0 end as WestNorthCentral,
  case when a.state in ('OK', 'AR', 'TX', 'LA') then 1 else 0 end as WestSouthCentral,
  case when a.state in ('MT', 'ID', 'WY', 'CO', 'NM', 'AZ', 'UT', 'NV') then 1 else 0 end as Mountain, 
  case when a.state in ('WA', 'OR', 'AK', 'HI') then 1 else 0 end as Pacific,
  a.fnma_ln,
  a.aq_actdt,
  a.acip,
  b.cd_12
  from puma..NZ_PUMA_TAB_POP a
  left join puma..NZ_totalperformance b
  on a.fnma_ln=b.fnma_ln
  where a.aq_actdt>=to_date(%d,'YYYYMM') and a.aq_actdt <=to_date(%d,'YYYYMM')
  and a.z_conventional_acq = 1 and a.seasoned <> 'Y' and a.harp_cde NOT in ('1', '2') 
  order by a.aq_actdt, a.acip", start_aqsn_dt, end_aqsn_dt)




.jinit() #initializes the Java Virtual Machine (JVM). This function must be called before any rJava functions can be used
## other uses and example
## use "myClasses.jar" as the class path
##.jinit(classpath="myClasses.jar", parameters="-Xmx512m")

## Question: How would you access the help page for .jinit()?


.jaddClassPath("/apps/nzcli/7.0.4/lib/nzjdbc3.jar") #Any additional classes to include in the Java class paths (i.e. locations of Java classes to use)
.jclassPath()
drv <- JDBC(driverClass="org.netezza.Driver", classPath="", identifier.quote="'")
con <- dbConnect(drv, "jdbc:netezza://psysadm-unz01:5480/PUMA", DBUser, NZDBPasswd)
res <- dbSendQuery(con, "select count(*) from NZ_PUMA_TAB_POP")
res <- fetch(res, n = -1)
res
dbDisconnect(con)
